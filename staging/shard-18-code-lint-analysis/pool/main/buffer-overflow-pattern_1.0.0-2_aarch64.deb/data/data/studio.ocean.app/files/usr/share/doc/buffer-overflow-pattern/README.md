# buffer-overflow-pattern

unsafe C standard library strcpy sprintf pattern finder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

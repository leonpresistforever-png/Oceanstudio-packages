# changelog-linter-tool

Keep a Changelog standard format markdown linter

## Description
Static analysis and source code auditing utility providing Keep a Changelog standard format markdown linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# memory-leak-pattern

malloc without free paired allocation trace heuristic

## Description
Static analysis and source code auditing utility providing malloc without free paired allocation trace heuristic for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

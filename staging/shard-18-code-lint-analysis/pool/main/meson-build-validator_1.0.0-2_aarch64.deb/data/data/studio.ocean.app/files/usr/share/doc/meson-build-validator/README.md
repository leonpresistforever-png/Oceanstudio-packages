# meson-build-validator

meson.build project and dependency syntax linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dep-graph-generator

module dependency graph generator in Graphviz DOT format

## Description
Static analysis and source code auditing utility providing module dependency graph generator in Graphviz DOT format for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# license-spdx-checker

SPDX-License-Identifier expression syntax validator

## Description
Static analysis and source code auditing utility providing SPDX-License-Identifier expression syntax validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

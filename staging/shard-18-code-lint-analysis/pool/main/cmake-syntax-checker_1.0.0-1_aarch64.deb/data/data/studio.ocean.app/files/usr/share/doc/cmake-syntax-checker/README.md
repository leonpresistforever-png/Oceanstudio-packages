# cmake-syntax-checker

CMakeLists.txt command arguments and policy validator

## Description
Static analysis and source code auditing utility providing CMakeLists.txt command arguments and policy validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

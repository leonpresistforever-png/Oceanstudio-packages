# format-string-vuln-chk

printf format string vulnerability static pattern audit

## Description
Static analysis and source code auditing utility providing printf format string vulnerability static pattern audit for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# cognitive-complexity

cognitive code comprehension difficulty metric engine

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# go-ast-token-scanner

Go source file package imports and struct field check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

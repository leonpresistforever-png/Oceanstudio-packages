# header-dependency-tree

header file inclusion depth and tree visualization

## Description
Static analysis and source code auditing utility providing header file inclusion depth and tree visualization for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

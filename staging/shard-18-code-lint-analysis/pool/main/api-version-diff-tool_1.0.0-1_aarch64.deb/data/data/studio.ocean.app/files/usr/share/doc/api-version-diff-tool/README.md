# api-version-diff-tool

API public interface additions and removals differ

## Description
Static analysis and source code auditing utility providing API public interface additions and removals differ for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

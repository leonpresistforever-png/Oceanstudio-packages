# author-attribution-chk

git commit history author email format validator

## Description
Static analysis and source code auditing utility providing git commit history author email format validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# shell-posix-validator

POSIX sh compliance and non-portable bashism detector

## Description
Static analysis and source code auditing utility providing POSIX sh compliance and non-portable bashism detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

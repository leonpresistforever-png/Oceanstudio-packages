# pkgconfig-file-linter

pkg-config .pc file Libs Cflags syntax validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

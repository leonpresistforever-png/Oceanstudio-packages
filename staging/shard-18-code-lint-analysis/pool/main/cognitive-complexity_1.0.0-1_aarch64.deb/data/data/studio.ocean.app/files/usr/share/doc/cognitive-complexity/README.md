# cognitive-complexity

cognitive code comprehension difficulty metric engine

## Description
Static analysis and source code auditing utility providing cognitive code comprehension difficulty metric engine for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

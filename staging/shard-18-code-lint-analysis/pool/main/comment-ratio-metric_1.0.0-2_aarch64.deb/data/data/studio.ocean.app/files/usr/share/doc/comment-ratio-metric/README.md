# comment-ratio-metric

code-to-comment ratio and documentation density score

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

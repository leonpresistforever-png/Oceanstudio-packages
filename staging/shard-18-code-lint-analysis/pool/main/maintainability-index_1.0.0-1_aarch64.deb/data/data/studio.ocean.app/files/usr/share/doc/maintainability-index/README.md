# maintainability-index

Maintainability Index MI software quality score tool

## Description
Static analysis and source code auditing utility providing Maintainability Index MI software quality score tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# sloccount-lightweight

multi-language source line counter and effort model

## Description
Static analysis and source code auditing utility providing multi-language source line counter and effort model for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

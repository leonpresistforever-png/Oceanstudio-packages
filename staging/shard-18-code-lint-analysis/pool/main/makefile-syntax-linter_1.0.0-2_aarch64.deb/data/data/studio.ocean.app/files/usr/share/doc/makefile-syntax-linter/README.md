# makefile-syntax-linter

Makefile tab indentation and rule prerequisite linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# integer-overflow-chk

signed integer arithmetic overflow heuristic detector

## Description
Static analysis and source code auditing utility providing signed integer arithmetic overflow heuristic detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

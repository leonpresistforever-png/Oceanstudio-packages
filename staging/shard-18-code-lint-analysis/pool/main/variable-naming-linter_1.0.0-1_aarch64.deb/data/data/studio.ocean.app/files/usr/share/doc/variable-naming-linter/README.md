# variable-naming-linter

identifier naming convention consistency checker

## Description
Static analysis and source code auditing utility providing identifier naming convention consistency checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# refactoring-advisor

code smell detection and automated refactor advisor

## Description
Static analysis and source code auditing utility providing code smell detection and automated refactor advisor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# format-string-vuln-chk

printf format string vulnerability static pattern audit

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

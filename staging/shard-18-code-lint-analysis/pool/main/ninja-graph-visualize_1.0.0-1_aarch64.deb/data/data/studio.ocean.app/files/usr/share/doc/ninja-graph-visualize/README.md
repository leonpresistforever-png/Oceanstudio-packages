# ninja-graph-visualize

build.ninja dependency rule and edge DAG visualizer

## Description
Static analysis and source code auditing utility providing build.ninja dependency rule and edge DAG visualizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

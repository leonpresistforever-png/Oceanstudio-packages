# semver-bump-calculator

Semantic Versioning MAJOR MINOR PATCH bump recommender

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# unreachable-code-chk

control flow graph dead basic block and branch linter

## Description
Static analysis and source code auditing utility providing control flow graph dead basic block and branch linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

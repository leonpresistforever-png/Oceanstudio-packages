# shell-posix-validator

POSIX sh compliance and non-portable bashism detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

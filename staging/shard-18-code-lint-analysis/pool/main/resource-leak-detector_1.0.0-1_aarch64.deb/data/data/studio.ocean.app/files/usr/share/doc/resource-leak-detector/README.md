# resource-leak-detector

unclosed file descriptor and socket leak pattern linter

## Description
Static analysis and source code auditing utility providing unclosed file descriptor and socket leak pattern linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

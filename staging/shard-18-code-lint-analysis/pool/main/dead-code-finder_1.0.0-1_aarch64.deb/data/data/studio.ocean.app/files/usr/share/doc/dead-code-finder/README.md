# dead-code-finder

unused function and variable static analysis detector

## Description
Static analysis and source code auditing utility providing unused function and variable static analysis detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

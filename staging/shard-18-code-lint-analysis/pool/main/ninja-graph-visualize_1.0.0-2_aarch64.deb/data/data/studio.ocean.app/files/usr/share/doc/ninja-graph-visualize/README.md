# ninja-graph-visualize

build.ninja dependency rule and edge DAG visualizer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

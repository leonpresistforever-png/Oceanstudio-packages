# js-ast-syntax-checker

ECMAScript/JavaScript syntax and strict mode linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

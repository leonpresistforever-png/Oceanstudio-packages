# elf-hash-table-chk

ELF sysv .hash and .gnu.hash bucket chain analyzer

## Description
Binary analysis and compilation toolchain helper providing ELF sysv .hash and .gnu.hash bucket chain analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

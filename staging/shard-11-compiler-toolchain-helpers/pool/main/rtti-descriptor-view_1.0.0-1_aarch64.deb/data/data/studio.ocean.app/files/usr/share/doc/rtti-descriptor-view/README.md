# rtti-descriptor-view

C++ Run-Time Type Information type_info reader

## Description
Binary analysis and compilation toolchain helper providing C++ Run-Time Type Information type_info reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# llvm-ir-instruction-chk

LLVM IR assembly opcode and basic block validator

## Description
Binary analysis and compilation toolchain helper providing LLVM IR assembly opcode and basic block validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# gcc-spec-file-parser

GCC compiler specs file compiler driver rule parser

## Description
Binary analysis and compilation toolchain helper providing GCC compiler specs file compiler driver rule parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

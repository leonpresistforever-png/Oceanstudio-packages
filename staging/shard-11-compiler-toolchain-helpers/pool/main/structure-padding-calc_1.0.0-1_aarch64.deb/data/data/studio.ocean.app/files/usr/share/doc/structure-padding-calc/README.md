# structure-padding-calc

data structure memory layout and hole visualizer

## Description
Binary analysis and compilation toolchain helper providing data structure memory layout and hole visualizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

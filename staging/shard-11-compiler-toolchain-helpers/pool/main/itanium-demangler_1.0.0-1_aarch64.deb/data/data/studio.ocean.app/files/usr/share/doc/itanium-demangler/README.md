# itanium-demangler

Itanium ABI C++ ABI mangling parser and formatter

## Description
Binary analysis and compilation toolchain helper providing Itanium ABI C++ ABI mangling parser and formatter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

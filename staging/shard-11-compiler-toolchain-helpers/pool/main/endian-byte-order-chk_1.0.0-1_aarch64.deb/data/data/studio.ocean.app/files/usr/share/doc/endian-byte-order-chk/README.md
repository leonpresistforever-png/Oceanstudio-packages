# endian-byte-order-chk

binary integer endianness byte-swap validation tool

## Description
Binary analysis and compilation toolchain helper providing binary integer endianness byte-swap validation tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

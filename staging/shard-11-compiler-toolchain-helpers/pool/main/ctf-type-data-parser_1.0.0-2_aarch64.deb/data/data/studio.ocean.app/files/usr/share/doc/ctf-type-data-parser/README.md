# ctf-type-data-parser

Compact C Type Format header and type table viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

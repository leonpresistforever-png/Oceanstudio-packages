# wasm-section-lister

WebAssembly section IDs and payload size reporter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# cxx-symbol-demangler

Itanium and MSVC C++ mangled symbol name demangler

## Description
Binary analysis and compilation toolchain helper providing Itanium and MSVC C++ mangled symbol name demangler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# include-graph-builder

C/C++ #include preprocessor dependency graph builder

## Description
Binary analysis and compilation toolchain helper providing C/C++ #include preprocessor dependency graph builder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# macho-dylib-id-view

Mach-O LC_ID_DYLIB and LC_LOAD_DYLIB command viewer

## Description
Binary analysis and compilation toolchain helper providing Mach-O LC_ID_DYLIB and LC_LOAD_DYLIB command viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# elf-string-table-cat

ELF .strtab and .dynstr string table extractor

## Description
Binary analysis and compilation toolchain helper providing ELF .strtab and .dynstr string table extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

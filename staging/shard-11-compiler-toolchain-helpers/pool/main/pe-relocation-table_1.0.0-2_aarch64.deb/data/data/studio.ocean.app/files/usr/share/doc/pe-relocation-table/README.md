# pe-relocation-table

Portable Executable base relocation block parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

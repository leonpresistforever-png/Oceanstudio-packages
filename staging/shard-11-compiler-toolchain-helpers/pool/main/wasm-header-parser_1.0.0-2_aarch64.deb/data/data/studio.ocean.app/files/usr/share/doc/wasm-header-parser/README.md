# wasm-header-parser

WebAssembly binary magic number and version parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

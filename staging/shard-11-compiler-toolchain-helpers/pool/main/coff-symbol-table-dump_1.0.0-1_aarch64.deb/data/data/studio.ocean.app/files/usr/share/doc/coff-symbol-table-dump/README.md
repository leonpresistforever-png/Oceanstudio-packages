# coff-symbol-table-dump

COFF symbol table and auxiliary symbol dumper

## Description
Binary analysis and compilation toolchain helper providing COFF symbol table and auxiliary symbol dumper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

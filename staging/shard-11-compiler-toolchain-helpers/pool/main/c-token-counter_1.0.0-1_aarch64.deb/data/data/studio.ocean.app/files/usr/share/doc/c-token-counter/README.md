# c-token-counter

C99/C11 lexer token count and distribution profiler

## Description
Binary analysis and compilation toolchain helper providing C99/C11 lexer token count and distribution profiler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# objcopy-binary-dump

ELF section raw binary dump and payload extractor

## Description
Binary analysis and compilation toolchain helper providing ELF section raw binary dump and payload extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

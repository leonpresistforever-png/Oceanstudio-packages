# clang-ast-dump-filter

Clang AST JSON dump node filtering and search tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

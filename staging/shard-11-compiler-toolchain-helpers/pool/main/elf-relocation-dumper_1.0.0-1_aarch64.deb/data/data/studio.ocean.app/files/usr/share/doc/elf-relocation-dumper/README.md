# elf-relocation-dumper

ELF dynamic and static relocation entry dumper

## Description
Binary analysis and compilation toolchain helper providing ELF dynamic and static relocation entry dumper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

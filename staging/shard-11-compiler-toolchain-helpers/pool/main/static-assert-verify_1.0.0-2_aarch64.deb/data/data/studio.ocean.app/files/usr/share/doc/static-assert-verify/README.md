# static-assert-verify

compile-time constant expression evaluator simulator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# wasm-opcode-disasm

WebAssembly code section instruction decoder

## Description
Binary analysis and compilation toolchain helper providing WebAssembly code section instruction decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

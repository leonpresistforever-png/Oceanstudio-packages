# pe-relocation-table

Portable Executable base relocation block parser

## Description
Binary analysis and compilation toolchain helper providing Portable Executable base relocation block parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

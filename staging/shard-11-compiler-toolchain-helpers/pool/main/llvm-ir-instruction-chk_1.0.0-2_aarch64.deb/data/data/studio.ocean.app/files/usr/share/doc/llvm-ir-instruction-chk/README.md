# llvm-ir-instruction-chk

LLVM IR assembly opcode and basic block validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# nm-undefined-symbols

ELF undefined symbol resolution dependency scanner

## Description
Binary analysis and compilation toolchain helper providing ELF undefined symbol resolution dependency scanner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

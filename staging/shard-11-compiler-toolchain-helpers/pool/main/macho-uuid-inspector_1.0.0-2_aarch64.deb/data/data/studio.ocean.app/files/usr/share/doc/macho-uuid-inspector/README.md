# macho-uuid-inspector

Mach-O LC_UUID binary identifier extractor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# gomplate-substitute

Go template syntax substitution and filter processor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# statsd-packet-sender

StatsD UDP metric packet generator for testing

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

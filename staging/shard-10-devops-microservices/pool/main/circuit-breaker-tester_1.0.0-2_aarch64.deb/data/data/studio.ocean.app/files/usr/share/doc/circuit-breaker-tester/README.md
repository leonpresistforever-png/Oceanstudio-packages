# circuit-breaker-tester

service circuit breaker trip and recovery simulator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

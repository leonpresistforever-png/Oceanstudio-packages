# nats-message-pub

NATS messaging protocol text framing publisher

## Description
DevOps workflow and microservice coordination utility providing NATS messaging protocol text framing publisher for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

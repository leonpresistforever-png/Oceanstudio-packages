# etcd-kv-parser

etcd v3 key-value transaction response parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

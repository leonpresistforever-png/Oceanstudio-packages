# pubsub-topic-tester

publish-subscribe topic routing key pattern matcher

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

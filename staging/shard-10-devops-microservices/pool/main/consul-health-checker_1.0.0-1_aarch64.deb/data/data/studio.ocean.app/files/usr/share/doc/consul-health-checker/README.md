# consul-health-checker

HashiCorp Consul service health check status evaluator

## Description
DevOps workflow and microservice coordination utility providing HashiCorp Consul service health check status evaluator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# rate-limit-simulator

sliding-window rate limiter algorithm evaluator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

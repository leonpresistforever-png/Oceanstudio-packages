# avro-schema-diff

Apache Avro JSON schema evolution and compatibility check

## Description
DevOps workflow and microservice coordination utility providing Apache Avro JSON schema evolution and compatibility check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# logfmt-parser-cli

key=value structured logfmt parser and JSON converter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

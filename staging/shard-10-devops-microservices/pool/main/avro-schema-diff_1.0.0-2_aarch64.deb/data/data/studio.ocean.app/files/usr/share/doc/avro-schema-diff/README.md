# avro-schema-diff

Apache Avro JSON schema evolution and compatibility check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

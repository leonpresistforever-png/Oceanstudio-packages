# dotenv-loader-cli

.env environment variable configuration file loader

## Description
DevOps workflow and microservice coordination utility providing .env environment variable configuration file loader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

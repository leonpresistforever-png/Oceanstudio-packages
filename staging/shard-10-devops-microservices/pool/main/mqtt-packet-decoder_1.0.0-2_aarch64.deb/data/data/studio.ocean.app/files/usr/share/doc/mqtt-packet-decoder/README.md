# mqtt-packet-decoder

MQTT v3.1.1/v5.0 fixed header and packet decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

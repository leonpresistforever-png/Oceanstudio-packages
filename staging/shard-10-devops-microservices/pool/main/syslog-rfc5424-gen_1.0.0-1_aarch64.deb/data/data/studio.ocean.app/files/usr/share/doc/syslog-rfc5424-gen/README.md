# syslog-rfc5424-gen

RFC 5424 structured syslog message generator

## Description
DevOps workflow and microservice coordination utility providing RFC 5424 structured syslog message generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

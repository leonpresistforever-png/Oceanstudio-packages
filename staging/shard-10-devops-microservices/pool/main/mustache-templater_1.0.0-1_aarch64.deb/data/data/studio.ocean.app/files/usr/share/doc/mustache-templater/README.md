# mustache-templater

logic-less Mustache configuration template renderer

## Description
DevOps workflow and microservice coordination utility providing logic-less Mustache configuration template renderer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# feature-flag-eval

feature flag percentage rollout evaluation engine

## Description
DevOps workflow and microservice coordination utility providing feature flag percentage rollout evaluation engine for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

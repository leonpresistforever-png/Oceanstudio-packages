# ingress-route-checker

API gateway ingress routing rules conflict detector

## Description
DevOps workflow and microservice coordination utility providing API gateway ingress routing rules conflict detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

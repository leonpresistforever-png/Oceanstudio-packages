# containerfile-parser

Containerfile multi-stage build instruction analyzer

## Description
DevOps workflow and microservice coordination utility providing Containerfile multi-stage build instruction analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# init-script-validator

SysV init script LSB header and runlevel validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

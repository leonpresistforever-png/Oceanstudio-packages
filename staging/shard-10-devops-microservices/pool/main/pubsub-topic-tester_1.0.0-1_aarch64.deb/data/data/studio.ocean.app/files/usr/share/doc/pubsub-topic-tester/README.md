# pubsub-topic-tester

publish-subscribe topic routing key pattern matcher

## Description
DevOps workflow and microservice coordination utility providing publish-subscribe topic routing key pattern matcher for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

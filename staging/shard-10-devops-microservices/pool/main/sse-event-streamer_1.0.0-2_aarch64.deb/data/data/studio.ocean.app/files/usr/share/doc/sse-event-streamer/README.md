# sse-event-streamer

Server-Sent Events text/event-stream client parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

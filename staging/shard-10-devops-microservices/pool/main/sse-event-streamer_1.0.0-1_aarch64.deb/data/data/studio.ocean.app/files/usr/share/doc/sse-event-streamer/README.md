# sse-event-streamer

Server-Sent Events text/event-stream client parser

## Description
DevOps workflow and microservice coordination utility providing Server-Sent Events text/event-stream client parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# gomplate-substitute

Go template syntax substitution and filter processor

## Description
DevOps workflow and microservice coordination utility providing Go template syntax substitution and filter processor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

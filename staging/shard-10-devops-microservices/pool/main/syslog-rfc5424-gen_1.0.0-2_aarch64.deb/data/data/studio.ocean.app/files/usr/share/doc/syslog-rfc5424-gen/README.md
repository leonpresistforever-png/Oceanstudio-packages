# syslog-rfc5424-gen

RFC 5424 structured syslog message generator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

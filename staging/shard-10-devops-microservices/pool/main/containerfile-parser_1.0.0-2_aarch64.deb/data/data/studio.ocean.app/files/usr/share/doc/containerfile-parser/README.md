# containerfile-parser

Containerfile multi-stage build instruction analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

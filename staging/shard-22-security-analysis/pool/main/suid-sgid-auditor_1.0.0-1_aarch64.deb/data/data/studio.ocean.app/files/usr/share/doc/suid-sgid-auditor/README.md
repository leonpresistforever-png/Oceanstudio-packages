# suid-sgid-auditor

scan directory paths for insecure SUID/SGID executable bits

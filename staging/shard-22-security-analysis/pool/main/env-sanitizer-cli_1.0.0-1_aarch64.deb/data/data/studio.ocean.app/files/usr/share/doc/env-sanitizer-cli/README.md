# env-sanitizer-cli

sanitize environment variables before spawning untrusted processes

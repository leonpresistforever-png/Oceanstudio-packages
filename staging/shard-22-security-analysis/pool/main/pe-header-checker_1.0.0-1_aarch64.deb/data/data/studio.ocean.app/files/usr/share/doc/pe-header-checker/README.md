# pe-header-checker

parse and inspect Portable Executable Windows binaries safely

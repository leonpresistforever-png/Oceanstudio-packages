# dns-zone-transfer-chk

test DNS servers for insecure AXFR zone transfer allowance

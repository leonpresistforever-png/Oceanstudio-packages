# check-pie-aslr

verify Position Independent Executable status on binaries

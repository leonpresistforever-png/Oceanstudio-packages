# csr-request-builder

generate Certificate Signing Requests with custom SAN extensions

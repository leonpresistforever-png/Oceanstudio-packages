# world-writable-auditor

scan directory paths for world-writable files and directories

# entropy-scanner

scan files for high-entropy regions indicating keys or encryption

# sha256-integrity-verify

verify cryptographically signed SHA-256 integrity manifests

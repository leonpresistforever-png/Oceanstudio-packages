# elfutils-readelf-ng

enhanced ELF binary section and symbol analyzer

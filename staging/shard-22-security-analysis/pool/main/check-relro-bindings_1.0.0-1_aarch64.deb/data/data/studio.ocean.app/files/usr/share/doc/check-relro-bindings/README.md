# check-relro-bindings

verify Full RELRO vs Partial RELRO in ELF headers

# email-dmarc-verifier

query and validate DMARC rejection policy records

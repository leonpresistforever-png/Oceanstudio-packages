# git-secrets-auditor

audit git commit history for accidental credential commits

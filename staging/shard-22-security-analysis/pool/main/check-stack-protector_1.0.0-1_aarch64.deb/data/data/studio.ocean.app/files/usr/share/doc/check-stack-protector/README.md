# check-stack-protector

detect stack canary protection in compiled ELF objects

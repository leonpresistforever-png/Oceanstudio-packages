# ocsp-response-checker

query Online Certificate Status Protocol servers for certificate status

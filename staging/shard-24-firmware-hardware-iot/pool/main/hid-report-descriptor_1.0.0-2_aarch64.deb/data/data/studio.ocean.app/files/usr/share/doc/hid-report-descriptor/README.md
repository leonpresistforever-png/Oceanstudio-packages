# hid-report-descriptor

USB Human Interface Device HID report parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

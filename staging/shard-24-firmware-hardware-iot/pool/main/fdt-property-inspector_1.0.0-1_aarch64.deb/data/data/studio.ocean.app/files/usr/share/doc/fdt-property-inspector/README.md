# fdt-property-inspector

Device Tree blob DTB compatible model reg inspector

## Description
Embedded firmware and hardware diagnostics tool providing Device Tree blob DTB compatible model reg inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

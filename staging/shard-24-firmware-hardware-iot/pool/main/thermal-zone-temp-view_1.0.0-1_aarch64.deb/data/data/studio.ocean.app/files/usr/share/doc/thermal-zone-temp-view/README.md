# thermal-zone-temp-view

Linux /sys/class/thermal temperature trip points view

## Description
Embedded firmware and hardware diagnostics tool providing Linux /sys/class/thermal temperature trip points view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

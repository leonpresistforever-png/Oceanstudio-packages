# uart-baud-rate-divisor

UART clock prescaler and baud rate error calculator

## Description
Embedded firmware and hardware diagnostics tool providing UART clock prescaler and baud rate error calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# modbus-tcp-header-chk

Modbus TCP MBAP header unit ID and function check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# gpio-cdev-line-event

Linux GPIO character device v2 line event decoder

## Description
Embedded firmware and hardware diagnostics tool providing Linux GPIO character device v2 line event decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# raw-nand-ecc-calculator

NAND flash spare OOB area BCH ECC parity calculator

## Description
Embedded firmware and hardware diagnostics tool providing NAND flash spare OOB area BCH ECC parity calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

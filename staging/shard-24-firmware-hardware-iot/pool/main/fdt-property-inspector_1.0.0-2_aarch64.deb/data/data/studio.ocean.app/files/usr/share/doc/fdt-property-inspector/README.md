# fdt-property-inspector

Device Tree blob DTB compatible model reg inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# thermal-zone-temp-view

Linux /sys/class/thermal temperature trip points view

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# uart-baud-rate-divisor

UART clock prescaler and baud rate error calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# uefi-variable-dump

UEFI NVRAM non-volatile variable data parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

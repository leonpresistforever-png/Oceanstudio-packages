# spdx-sbom-firmware-chk

firmware Software Bill of Materials SBOM checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# zigbee-zcl-frame-view

Zigbee Cluster Library ZCL frame control byte view

## Description
Embedded firmware and hardware diagnostics tool providing Zigbee Cluster Library ZCL frame control byte view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

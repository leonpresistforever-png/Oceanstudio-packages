# i2c-bus-address-probe

I2C 7-bit bus address collision and reserved checker

## Description
Embedded firmware and hardware diagnostics tool providing I2C 7-bit bus address collision and reserved checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

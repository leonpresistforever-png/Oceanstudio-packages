# bluetooth-hci-cmd-dump

Bluetooth Host Controller Interface HCI packet parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

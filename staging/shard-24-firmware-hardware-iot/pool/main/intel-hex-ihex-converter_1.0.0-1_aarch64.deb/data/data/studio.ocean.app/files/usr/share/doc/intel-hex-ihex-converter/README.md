# intel-hex-ihex-converter

Intel HEX format record parser and binary converter

## Description
Embedded firmware and hardware diagnostics tool providing Intel HEX format record parser and binary converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

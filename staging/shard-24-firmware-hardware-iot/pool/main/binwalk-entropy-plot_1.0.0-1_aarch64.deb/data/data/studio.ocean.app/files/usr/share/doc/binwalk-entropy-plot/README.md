# binwalk-entropy-plot

firmware flash ROM image block entropy grapher

## Description
Embedded firmware and hardware diagnostics tool providing firmware flash ROM image block entropy grapher for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

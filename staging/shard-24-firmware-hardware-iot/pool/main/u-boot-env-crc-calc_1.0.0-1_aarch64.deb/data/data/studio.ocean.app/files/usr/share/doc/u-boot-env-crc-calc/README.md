# u-boot-env-crc-calc

U-Boot environment variables CRC32 checksum tool

## Description
Embedded firmware and hardware diagnostics tool providing U-Boot environment variables CRC32 checksum tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# i2c-smbus-block-calc

SMBus Packet Error Checking PEC CRC-8 calculator

## Description
Embedded firmware and hardware diagnostics tool providing SMBus Packet Error Checking PEC CRC-8 calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# can-j1939-pgn-parser

SAE J1939 Parameter Group Number PGN ID decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# acpi-table-parser-dsdt

ACPI Differentiated System Description Table parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# i2s-audio-clock-calc

I2S digital audio bit clock BCLK word select calc

## Description
Embedded firmware and hardware diagnostics tool providing I2S digital audio bit clock BCLK word select calc for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

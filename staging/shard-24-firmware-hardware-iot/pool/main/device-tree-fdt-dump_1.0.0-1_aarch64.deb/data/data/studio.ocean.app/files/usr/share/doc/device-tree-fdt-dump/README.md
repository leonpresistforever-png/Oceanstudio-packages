# device-tree-fdt-dump

Flattened Device Tree FDT binary header and nodes parser

## Description
Embedded firmware and hardware diagnostics tool providing Flattened Device Tree FDT binary header and nodes parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

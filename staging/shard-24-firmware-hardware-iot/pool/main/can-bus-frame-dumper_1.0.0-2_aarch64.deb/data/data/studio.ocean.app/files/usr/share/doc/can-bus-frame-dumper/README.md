# can-bus-frame-dumper

Controller Area Network CAN 2.0A/B standard frame dump

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

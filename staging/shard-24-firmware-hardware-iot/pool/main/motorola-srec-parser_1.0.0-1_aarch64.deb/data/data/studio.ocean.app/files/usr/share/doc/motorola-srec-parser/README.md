# motorola-srec-parser

Motorola S-Record S0 S1 S2 S3 S7 S8 S9 decompiler

## Description
Embedded firmware and hardware diagnostics tool providing Motorola S-Record S0 S1 S2 S3 S7 S8 S9 decompiler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

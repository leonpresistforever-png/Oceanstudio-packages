# serial-termios-config

Linux termios serial port c_cflag parity visualizer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# i2c-bus-address-probe

I2C 7-bit bus address collision and reserved checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

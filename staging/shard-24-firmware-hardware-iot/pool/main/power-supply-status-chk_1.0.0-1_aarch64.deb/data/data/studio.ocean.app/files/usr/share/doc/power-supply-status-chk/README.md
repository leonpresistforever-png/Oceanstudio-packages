# power-supply-status-chk

Linux /sys/class/power_supply battery charge health

## Description
Embedded firmware and hardware diagnostics tool providing Linux /sys/class/power_supply battery charge health for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

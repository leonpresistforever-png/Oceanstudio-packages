# edkid-uefi-capsule-chk

UEFI capsule update header and GUID authenticator

## Description
Embedded firmware and hardware diagnostics tool providing UEFI capsule update header and GUID authenticator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# rfid-mifare-block-chk

MIFARE Classic 1K sector trailer access bits decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

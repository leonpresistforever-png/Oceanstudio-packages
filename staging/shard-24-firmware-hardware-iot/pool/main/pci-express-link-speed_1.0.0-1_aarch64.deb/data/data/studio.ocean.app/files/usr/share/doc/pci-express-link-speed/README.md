# pci-express-link-speed

PCIe link capability speed GT/s and width reader

## Description
Embedded firmware and hardware diagnostics tool providing PCIe link capability speed GT/s and width reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

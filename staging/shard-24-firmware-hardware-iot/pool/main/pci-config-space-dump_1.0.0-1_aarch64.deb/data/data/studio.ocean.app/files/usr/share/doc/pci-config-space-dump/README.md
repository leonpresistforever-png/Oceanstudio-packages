# pci-config-space-dump

PCI Express 256-byte configuration space parser

## Description
Embedded firmware and hardware diagnostics tool providing PCI Express 256-byte configuration space parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

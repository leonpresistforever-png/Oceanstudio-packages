# nfc-ndef-record-parser

NFC Data Exchange Format NDEF record TNF parser

## Description
Embedded firmware and hardware diagnostics tool providing NFC Data Exchange Format NDEF record TNF parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

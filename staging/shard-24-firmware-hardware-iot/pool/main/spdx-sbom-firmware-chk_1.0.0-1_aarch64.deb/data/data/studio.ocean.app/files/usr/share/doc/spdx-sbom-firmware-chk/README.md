# spdx-sbom-firmware-chk

firmware Software Bill of Materials SBOM checker

## Description
Embedded firmware and hardware diagnostics tool providing firmware Software Bill of Materials SBOM checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

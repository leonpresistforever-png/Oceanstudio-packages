# usb-endpoint-analyzer

USB bulk interrupt isochronous endpoint packet size

## Description
Embedded firmware and hardware diagnostics tool providing USB bulk interrupt isochronous endpoint packet size for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

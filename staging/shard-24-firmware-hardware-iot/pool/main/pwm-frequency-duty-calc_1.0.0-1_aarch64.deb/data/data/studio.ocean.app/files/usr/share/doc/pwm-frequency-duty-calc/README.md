# pwm-frequency-duty-calc

Pulse Width Modulation duty cycle nanosecond helper

## Description
Embedded firmware and hardware diagnostics tool providing Pulse Width Modulation duty cycle nanosecond helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

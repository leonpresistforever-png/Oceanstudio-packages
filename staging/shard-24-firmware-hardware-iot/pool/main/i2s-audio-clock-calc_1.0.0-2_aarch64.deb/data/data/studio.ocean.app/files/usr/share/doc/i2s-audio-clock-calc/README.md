# i2s-audio-clock-calc

I2S digital audio bit clock BCLK word select calc

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# acpi-fadt-header-dump

ACPI Fixed ACPI Description Table FADT header tool

## Description
Embedded firmware and hardware diagnostics tool providing ACPI Fixed ACPI Description Table FADT header tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

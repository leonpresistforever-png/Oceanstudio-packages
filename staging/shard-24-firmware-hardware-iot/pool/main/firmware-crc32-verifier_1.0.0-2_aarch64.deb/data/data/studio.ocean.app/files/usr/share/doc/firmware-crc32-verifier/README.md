# firmware-crc32-verifier

embedded microcontroller firmware image CRC32 tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# pci-config-space-dump

PCI Express 256-byte configuration space parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

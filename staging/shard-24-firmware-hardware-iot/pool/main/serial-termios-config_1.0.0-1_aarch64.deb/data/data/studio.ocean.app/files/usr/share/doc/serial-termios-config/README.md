# serial-termios-config

Linux termios serial port c_cflag parity visualizer

## Description
Embedded firmware and hardware diagnostics tool providing Linux termios serial port c_cflag parity visualizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

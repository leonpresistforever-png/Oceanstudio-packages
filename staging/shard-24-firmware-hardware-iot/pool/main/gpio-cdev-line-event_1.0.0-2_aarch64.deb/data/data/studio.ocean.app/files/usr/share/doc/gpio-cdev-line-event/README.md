# gpio-cdev-line-event

Linux GPIO character device v2 line event decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

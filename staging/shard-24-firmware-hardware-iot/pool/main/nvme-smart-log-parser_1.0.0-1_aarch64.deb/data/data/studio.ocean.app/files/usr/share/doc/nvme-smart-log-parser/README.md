# nvme-smart-log-parser

NVMe SMART health information log page parser

## Description
Embedded firmware and hardware diagnostics tool providing NVMe SMART health information log page parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# acpi-fadt-header-dump

ACPI Fixed ACPI Description Table FADT header tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# modbus-rtu-crc16-calc

Modbus RTU transmission mode CRC-16 calculator

## Description
Embedded firmware and hardware diagnostics tool providing Modbus RTU transmission mode CRC-16 calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

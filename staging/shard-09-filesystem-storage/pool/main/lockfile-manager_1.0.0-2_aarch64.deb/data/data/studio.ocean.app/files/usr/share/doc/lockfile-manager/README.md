# lockfile-manager

atomic lockfile acquisition with timeout handling

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# lsattr-ocean

list file attributes on Linux second extended file system

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# squashfs-super-view

SquashFS superblock compression and block size viewer

## Description
Filesystem analysis and storage engineering utility providing SquashFS superblock compression and block size viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

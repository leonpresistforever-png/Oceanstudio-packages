# statvfs-free-calc

POSIX statvfs available disk space and block calculator

## Description
Filesystem analysis and storage engineering utility providing POSIX statvfs available disk space and block calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

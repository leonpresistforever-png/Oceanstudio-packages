# fifo-pipe-tester

named pipe FIFO non-blocking read/write tester

## Description
Filesystem analysis and storage engineering utility providing named pipe FIFO non-blocking read/write tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# directory-depth-calc

directory tree maximum nesting depth calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

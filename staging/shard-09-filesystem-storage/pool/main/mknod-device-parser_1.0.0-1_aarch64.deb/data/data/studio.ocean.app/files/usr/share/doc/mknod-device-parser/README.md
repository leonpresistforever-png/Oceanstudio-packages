# mknod-device-parser

character and block special device major/minor parser

## Description
Filesystem analysis and storage engineering utility providing character and block special device major/minor parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# direct-io-benchmark

O_DIRECT page-cache bypass storage benchmark

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# lsattr-ocean

list file attributes on Linux second extended file system

## Description
Filesystem analysis and storage engineering utility providing list file attributes on Linux second extended file system for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

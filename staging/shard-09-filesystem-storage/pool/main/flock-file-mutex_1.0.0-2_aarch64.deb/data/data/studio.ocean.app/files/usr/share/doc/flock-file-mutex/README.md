# flock-file-mutex

advisory file locking mutex for pipeline synchronization

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

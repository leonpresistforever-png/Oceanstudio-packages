# tmpfs-usage-tracker

virtual memory tmpfs allocation and swap usage tracker

## Description
Filesystem analysis and storage engineering utility providing virtual memory tmpfs allocation and swap usage tracker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# faccessat-tester

POSIX faccessat file existence and permission tester

## Description
Filesystem analysis and storage engineering utility providing POSIX faccessat file existence and permission tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

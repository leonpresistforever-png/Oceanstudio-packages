# blkdiscard-analyzer

block device TRIM and discard support tester

## Description
Filesystem analysis and storage engineering utility providing block device TRIM and discard support tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# bind-mount-auditor

mount namespace bind-mount source and target mapper

## Description
Filesystem analysis and storage engineering utility providing mount namespace bind-mount source and target mapper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

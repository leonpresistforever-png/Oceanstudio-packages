# f2fs-status-inspector

Flash-Friendly File System segment and checkpoint tool

## Description
Filesystem analysis and storage engineering utility providing Flash-Friendly File System segment and checkpoint tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

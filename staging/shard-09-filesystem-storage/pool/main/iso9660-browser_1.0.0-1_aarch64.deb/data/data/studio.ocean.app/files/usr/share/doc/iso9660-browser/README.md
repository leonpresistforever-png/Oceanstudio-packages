# iso9660-browser

ISO 9660 Joliet primary volume descriptor browser

## Description
Filesystem analysis and storage engineering utility providing ISO 9660 Joliet primary volume descriptor browser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

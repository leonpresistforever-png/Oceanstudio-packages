# file-descriptor-duper

file descriptor duplication and redirection helper

## Description
Filesystem analysis and storage engineering utility providing file descriptor duplication and redirection helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

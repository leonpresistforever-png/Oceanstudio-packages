# mount-options-checker

filesystem mount flags noatime nodiratime audit

## Description
Filesystem analysis and storage engineering utility providing filesystem mount flags noatime nodiratime audit for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

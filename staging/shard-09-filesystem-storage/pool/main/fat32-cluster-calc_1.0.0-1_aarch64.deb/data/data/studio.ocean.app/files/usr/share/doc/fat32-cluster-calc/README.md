# fat32-cluster-calc

FAT cluster chain size and sector offset calculator

## Description
Filesystem analysis and storage engineering utility providing FAT cluster chain size and sector offset calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

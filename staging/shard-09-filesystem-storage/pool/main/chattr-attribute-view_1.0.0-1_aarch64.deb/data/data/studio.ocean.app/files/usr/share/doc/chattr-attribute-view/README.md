# chattr-attribute-view

ext2/3/4 file system extended attribute flag viewer

## Description
Filesystem analysis and storage engineering utility providing ext2/3/4 file system extended attribute flag viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

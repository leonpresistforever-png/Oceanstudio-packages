# hole-punch-tester

fallocate FALLOC_FL_PUNCH_HOLE capability tester

## Description
Filesystem analysis and storage engineering utility providing fallocate FALLOC_FL_PUNCH_HOLE capability tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

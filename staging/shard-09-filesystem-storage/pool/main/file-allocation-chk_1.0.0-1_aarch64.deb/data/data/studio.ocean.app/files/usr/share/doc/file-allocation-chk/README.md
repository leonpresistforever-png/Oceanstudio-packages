# file-allocation-chk

file disk block preallocation and fragmentation check

## Description
Filesystem analysis and storage engineering utility providing file disk block preallocation and fragmentation check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# mount-options-checker

filesystem mount flags noatime nodiratime audit

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

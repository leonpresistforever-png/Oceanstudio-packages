# statvfs-free-calc

POSIX statvfs available disk space and block calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

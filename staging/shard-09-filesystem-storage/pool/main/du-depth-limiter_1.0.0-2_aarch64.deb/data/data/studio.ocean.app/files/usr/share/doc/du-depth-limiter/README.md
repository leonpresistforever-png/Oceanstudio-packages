# du-depth-limiter

directory disk usage reporter with configurable max-depth

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

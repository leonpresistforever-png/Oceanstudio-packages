# xattr-metadata-viewer

user and security namespace extended attribute viewer

## Description
Filesystem analysis and storage engineering utility providing user and security namespace extended attribute viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# fallocate-prealloc

fast POSIX file space allocation without zero-fill

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

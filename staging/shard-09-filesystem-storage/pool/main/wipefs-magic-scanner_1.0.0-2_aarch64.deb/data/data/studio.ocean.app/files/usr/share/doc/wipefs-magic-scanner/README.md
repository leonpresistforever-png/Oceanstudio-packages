# wipefs-magic-scanner

filesystem signature magic number scanner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

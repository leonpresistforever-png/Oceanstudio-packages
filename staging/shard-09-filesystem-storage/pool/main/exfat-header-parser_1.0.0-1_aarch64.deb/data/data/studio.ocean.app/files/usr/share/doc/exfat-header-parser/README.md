# exfat-header-parser

exFAT volume boot record and allocation bitmap tool

## Description
Filesystem analysis and storage engineering utility providing exFAT volume boot record and allocation bitmap tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

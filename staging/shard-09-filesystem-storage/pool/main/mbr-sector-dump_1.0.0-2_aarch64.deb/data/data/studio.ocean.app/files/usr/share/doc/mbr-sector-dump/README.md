# mbr-sector-dump

Master Boot Record bootcode and partition table dump

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

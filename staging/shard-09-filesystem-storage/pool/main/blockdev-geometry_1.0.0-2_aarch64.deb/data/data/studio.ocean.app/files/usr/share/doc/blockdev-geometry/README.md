# blockdev-geometry

block device logical sector size and rotational view

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# chattr-attribute-view

ext2/3/4 file system extended attribute flag viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# vfat-boot-sector-chk

FAT32/VFAT BPB BIOS parameter block inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

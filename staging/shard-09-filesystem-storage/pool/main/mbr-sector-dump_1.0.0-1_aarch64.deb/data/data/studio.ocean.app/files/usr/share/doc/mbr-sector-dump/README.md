# mbr-sector-dump

Master Boot Record bootcode and partition table dump

## Description
Filesystem analysis and storage engineering utility providing Master Boot Record bootcode and partition table dump for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

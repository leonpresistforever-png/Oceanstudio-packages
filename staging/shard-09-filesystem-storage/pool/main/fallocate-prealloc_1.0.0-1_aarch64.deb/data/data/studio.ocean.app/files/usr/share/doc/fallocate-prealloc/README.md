# fallocate-prealloc

fast POSIX file space allocation without zero-fill

## Description
Filesystem analysis and storage engineering utility providing fast POSIX file space allocation without zero-fill for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

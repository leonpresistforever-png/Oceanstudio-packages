# seccomp-bpf-generator

seccomp Berkeley Packet Filter assembly generator

## Description
Container runtime and Linux namespace management utility providing seccomp Berkeley Packet Filter assembly generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# devicemapper-thin-pool

Device Mapper thin provisioning pool metadata checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

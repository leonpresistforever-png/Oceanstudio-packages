# cgroup-v2-unified-tree

cgroup v2 unified hierarchy cgroup.procs inspector

## Description
Container runtime and Linux namespace management utility providing cgroup v2 unified hierarchy cgroup.procs inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

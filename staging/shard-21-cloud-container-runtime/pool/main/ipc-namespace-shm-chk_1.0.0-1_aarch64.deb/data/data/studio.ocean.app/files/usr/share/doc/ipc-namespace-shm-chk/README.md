# ipc-namespace-shm-chk

IPC namespace System V and POSIX shared memory view

## Description
Container runtime and Linux namespace management utility providing IPC namespace System V and POSIX shared memory view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

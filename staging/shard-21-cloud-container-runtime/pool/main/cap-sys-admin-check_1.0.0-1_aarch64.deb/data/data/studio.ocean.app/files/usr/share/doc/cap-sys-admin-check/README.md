# cap-sys-admin-check

CAP_SYS_ADMIN privilege escalation risk analyzer

## Description
Container runtime and Linux namespace management utility providing CAP_SYS_ADMIN privilege escalation risk analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

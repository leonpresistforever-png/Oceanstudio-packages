# oci-runtime-metrics

container runtime resource utilization metric gatherer

## Description
Container runtime and Linux namespace management utility providing container runtime resource utilization metric gatherer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

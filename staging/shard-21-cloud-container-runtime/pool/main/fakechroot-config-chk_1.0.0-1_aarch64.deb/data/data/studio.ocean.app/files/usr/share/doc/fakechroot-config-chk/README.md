# fakechroot-config-chk

fakechroot library interception path translator

## Description
Container runtime and Linux namespace management utility providing fakechroot library interception path translator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

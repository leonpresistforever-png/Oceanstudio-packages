# veth-pair-creator-cli

virtual ethernet veth pair link parameters calculator

## Description
Container runtime and Linux namespace management utility providing virtual ethernet veth pair link parameters calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

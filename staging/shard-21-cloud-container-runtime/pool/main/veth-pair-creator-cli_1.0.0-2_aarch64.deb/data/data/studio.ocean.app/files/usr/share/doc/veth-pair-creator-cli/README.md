# veth-pair-creator-cli

virtual ethernet veth pair link parameters calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

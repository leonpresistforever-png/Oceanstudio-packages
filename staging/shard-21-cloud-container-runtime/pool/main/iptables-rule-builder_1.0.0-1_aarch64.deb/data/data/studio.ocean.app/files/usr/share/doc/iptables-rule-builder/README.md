# iptables-rule-builder

Linux iptables container port forwarding rule builder

## Description
Container runtime and Linux namespace management utility providing Linux iptables container port forwarding rule builder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

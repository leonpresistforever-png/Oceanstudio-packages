# ebtables-bridge-rule

Ethernet bridge frame table filtering rule helper

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

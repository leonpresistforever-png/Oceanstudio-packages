# rootless-id-allocator

rootless container subuid and subgid range allocator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# runc-config-generator

OCI runc config.json container specification builder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

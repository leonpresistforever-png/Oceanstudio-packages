# cgroup-v2-pids-max

cgroup v2 fork-bomb protection pids.max calculator

## Description
Container runtime and Linux namespace management utility providing cgroup v2 fork-bomb protection pids.max calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# pid-namespace-tester

PID namespace process tree isolation and init check

## Description
Container runtime and Linux namespace management utility providing PID namespace process tree isolation and init check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

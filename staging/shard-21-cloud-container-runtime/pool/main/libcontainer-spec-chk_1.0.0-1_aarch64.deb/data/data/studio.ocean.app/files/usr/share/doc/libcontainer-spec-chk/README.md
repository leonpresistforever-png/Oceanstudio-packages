# libcontainer-spec-chk

libcontainer specification security constraint checker

## Description
Container runtime and Linux namespace management utility providing libcontainer specification security constraint checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

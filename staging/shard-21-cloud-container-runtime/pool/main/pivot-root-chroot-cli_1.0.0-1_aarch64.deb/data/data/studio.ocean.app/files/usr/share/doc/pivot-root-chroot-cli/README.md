# pivot-root-chroot-cli

atomic pivot_root root filesystem switching helper

## Description
Container runtime and Linux namespace management utility providing atomic pivot_root root filesystem switching helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

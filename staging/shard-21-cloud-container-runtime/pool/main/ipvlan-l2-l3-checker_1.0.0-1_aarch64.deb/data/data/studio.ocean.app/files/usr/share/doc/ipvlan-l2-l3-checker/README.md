# ipvlan-l2-l3-checker

IPVLAN L2 vs L3 mode routing and address checker

## Description
Container runtime and Linux namespace management utility providing IPVLAN L2 vs L3 mode routing and address checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

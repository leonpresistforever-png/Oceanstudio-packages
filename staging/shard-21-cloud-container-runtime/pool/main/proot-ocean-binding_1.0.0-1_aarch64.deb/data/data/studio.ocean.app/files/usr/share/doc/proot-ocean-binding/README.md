# proot-ocean-binding

PRoot userspace chroot path binding arguments builder

## Description
Container runtime and Linux namespace management utility providing PRoot userspace chroot path binding arguments builder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

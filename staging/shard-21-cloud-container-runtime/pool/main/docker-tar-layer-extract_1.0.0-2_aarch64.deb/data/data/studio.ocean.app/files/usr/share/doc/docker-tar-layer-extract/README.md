# docker-tar-layer-extract

Docker image save tarball manifest and layer reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

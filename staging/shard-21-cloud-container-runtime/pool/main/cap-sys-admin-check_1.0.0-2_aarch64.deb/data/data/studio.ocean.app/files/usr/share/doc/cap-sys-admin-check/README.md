# cap-sys-admin-check

CAP_SYS_ADMIN privilege escalation risk analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

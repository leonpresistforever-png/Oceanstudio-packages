# overlayfs-lower-upper

OverlayFS multi-lower layer inheritance visualizer

## Description
Container runtime and Linux namespace management utility providing OverlayFS multi-lower layer inheritance visualizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

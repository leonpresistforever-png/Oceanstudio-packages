# runc-bundle-validator

OCI container filesystem bundle layout validator

## Description
Container runtime and Linux namespace management utility providing OCI container filesystem bundle layout validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

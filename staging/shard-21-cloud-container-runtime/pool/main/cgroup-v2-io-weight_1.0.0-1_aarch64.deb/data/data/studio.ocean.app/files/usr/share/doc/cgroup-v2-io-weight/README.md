# cgroup-v2-io-weight

cgroup v2 I/O weight and io.max bandwidth controller

## Description
Container runtime and Linux namespace management utility providing cgroup v2 I/O weight and io.max bandwidth controller for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

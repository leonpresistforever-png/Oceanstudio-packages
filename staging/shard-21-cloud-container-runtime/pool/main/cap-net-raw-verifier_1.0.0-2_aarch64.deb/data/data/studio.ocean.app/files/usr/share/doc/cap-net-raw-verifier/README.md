# cap-net-raw-verifier

CAP_NET_RAW packet capture socket permission check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

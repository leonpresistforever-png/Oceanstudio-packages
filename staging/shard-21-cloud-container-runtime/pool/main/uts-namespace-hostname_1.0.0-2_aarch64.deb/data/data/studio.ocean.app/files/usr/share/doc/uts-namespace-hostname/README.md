# uts-namespace-hostname

UTS namespace hostname and domainname isolation tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# cap-dac-override-chk

CAP_DAC_OVERRIDE filesystem bypass permission check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

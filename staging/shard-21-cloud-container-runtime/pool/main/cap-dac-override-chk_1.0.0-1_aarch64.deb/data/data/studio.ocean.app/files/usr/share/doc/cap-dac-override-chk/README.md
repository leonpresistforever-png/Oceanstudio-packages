# cap-dac-override-chk

CAP_DAC_OVERRIDE filesystem bypass permission check

## Description
Container runtime and Linux namespace management utility providing CAP_DAC_OVERRIDE filesystem bypass permission check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

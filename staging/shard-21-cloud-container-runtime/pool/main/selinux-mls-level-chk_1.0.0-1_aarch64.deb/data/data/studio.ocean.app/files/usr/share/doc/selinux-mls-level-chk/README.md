# selinux-mls-level-chk

SELinux Multi-Level Security s0-s15 sensitivity check

## Description
Container runtime and Linux namespace management utility providing SELinux Multi-Level Security s0-s15 sensitivity check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# tc-filter-bpf-loader

traffic control cls_bpf packet classification helper

## Description
Container runtime and Linux namespace management utility providing traffic control cls_bpf packet classification helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

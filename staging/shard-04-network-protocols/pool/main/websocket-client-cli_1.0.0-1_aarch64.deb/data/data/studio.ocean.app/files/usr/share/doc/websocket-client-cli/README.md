# websocket-client-cli

interactive WebSocket client for sending and receiving frames

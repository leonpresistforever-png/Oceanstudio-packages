# http-header-dump

dump and inspect all HTTP/HTTPS response headers

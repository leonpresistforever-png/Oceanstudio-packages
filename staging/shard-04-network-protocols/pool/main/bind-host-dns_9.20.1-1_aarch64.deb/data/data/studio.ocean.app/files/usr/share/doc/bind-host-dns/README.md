# bind-host-dns

simple and fast DNS lookup utility

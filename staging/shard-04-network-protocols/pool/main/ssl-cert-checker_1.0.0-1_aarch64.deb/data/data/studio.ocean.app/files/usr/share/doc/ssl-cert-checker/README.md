# ssl-cert-checker

verify remote TLS certificate validity and expiry dates

# bind-dig-dns

flexible DNS query lookup tool from BIND

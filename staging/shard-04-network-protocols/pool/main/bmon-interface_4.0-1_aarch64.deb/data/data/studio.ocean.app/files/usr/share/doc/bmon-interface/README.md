# bmon-interface

bandwidth monitor and rate estimator for interfaces

# sftp-automation

scriptable SFTP automation client with batch retry

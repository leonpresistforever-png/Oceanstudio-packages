# nload-traffic

real-time network traffic and bandwidth monitor

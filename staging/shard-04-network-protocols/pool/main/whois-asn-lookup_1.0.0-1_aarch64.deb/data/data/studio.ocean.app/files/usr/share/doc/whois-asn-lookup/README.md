# whois-asn-lookup

query BGP ASN and routing prefix information

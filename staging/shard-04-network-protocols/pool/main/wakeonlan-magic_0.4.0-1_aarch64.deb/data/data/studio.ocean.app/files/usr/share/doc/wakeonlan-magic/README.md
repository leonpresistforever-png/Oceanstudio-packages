# wakeonlan-magic

send magic packets to Wake-on-LAN enabled NICs

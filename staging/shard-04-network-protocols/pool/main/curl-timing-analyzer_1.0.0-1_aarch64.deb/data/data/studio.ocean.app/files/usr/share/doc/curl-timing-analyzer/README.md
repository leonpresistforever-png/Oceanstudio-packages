# curl-timing-analyzer

extract detailed connection and DNS timing from curl

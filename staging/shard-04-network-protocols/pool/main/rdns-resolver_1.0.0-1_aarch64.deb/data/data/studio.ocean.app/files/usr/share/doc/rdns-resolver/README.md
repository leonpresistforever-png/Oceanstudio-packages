# rdns-resolver

fast batch reverse DNS IP-to-hostname resolver

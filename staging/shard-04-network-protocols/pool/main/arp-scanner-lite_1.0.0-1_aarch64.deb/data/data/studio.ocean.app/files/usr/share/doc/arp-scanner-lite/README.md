# arp-scanner-lite

discover hosts on local Ethernet broadcast domain

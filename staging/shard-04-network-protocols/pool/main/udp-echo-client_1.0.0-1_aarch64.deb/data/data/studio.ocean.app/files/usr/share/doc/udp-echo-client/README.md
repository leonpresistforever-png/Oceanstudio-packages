# udp-echo-client

send and receive UDP echo datagrams for latency tests

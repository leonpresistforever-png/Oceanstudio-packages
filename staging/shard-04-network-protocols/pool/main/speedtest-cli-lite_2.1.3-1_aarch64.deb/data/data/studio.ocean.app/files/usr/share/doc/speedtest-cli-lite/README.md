# speedtest-cli-lite

command line interface for testing internet bandwidth

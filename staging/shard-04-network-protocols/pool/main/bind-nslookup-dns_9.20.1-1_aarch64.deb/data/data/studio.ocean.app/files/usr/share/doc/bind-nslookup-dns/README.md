# bind-nslookup-dns

query Internet domain name servers interactively

# cors-header-checker

test CORS preflight and access-control headers on API

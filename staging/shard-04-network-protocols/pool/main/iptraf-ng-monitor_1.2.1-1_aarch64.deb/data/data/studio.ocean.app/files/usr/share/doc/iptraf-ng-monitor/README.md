# iptraf-ng-monitor

IP network monitor and traffic statistics CLI

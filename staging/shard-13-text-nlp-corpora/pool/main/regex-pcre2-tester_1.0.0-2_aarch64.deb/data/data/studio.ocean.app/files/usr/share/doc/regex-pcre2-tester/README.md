# regex-pcre2-tester

PCRE2 regular expression pattern test and capture cli

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

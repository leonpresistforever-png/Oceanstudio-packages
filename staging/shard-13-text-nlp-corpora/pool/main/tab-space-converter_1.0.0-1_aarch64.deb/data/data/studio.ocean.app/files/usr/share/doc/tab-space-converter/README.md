# tab-space-converter

tab-to-spaces expand and unexpand formatting filter

## Description
Text tokenization and natural language processing tool providing tab-to-spaces expand and unexpand formatting filter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

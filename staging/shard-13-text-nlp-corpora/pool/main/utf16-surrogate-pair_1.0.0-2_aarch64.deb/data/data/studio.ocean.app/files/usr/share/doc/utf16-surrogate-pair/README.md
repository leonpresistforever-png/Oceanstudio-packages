# utf16-surrogate-pair

UTF-16 high and low surrogate pair calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

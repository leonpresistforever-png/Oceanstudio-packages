# character-ngram-gen

text character and subword n-gram frequency modeler

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# soundex-phonetic-calc

Soundex phonetic indexing code calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

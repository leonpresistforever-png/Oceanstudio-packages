# text-summarizer-lex

lexical frequency extractive text summarizer

## Description
Text tokenization and natural language processing tool providing lexical frequency extractive text summarizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

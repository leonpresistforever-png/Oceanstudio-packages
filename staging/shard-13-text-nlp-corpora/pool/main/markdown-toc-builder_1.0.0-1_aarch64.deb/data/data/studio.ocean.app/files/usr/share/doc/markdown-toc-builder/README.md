# markdown-toc-builder

markdown document header table of contents generator

## Description
Text tokenization and natural language processing tool providing markdown document header table of contents generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# utf16-surrogate-pair

UTF-16 high and low surrogate pair calculator

## Description
Text tokenization and natural language processing tool providing UTF-16 high and low surrogate pair calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

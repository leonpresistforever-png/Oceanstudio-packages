# line-wrap-hyphenator

Knuth-Liang paragraph text wrapping and hyphenator

## Description
Text tokenization and natural language processing tool providing Knuth-Liang paragraph text wrapping and hyphenator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

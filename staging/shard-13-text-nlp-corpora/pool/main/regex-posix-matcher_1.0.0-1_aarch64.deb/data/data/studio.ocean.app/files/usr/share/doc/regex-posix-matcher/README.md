# regex-posix-matcher

POSIX Extended Regular Expression compliance tester

## Description
Text tokenization and natural language processing tool providing POSIX Extended Regular Expression compliance tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# syllable-counter-cli

English word syllable count heuristic estimator

## Description
Text tokenization and natural language processing tool providing English word syllable count heuristic estimator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

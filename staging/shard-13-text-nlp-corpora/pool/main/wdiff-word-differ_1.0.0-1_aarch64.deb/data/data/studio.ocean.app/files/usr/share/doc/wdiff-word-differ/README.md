# wdiff-word-differ

word-by-word diff comparison for prose and text

## Description
Text tokenization and natural language processing tool providing word-by-word diff comparison for prose and text for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

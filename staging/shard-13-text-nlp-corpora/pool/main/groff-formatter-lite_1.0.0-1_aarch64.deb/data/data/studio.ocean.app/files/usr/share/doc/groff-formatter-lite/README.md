# groff-formatter-lite

lightweight troff roff typesetting macro processor

## Description
Text tokenization and natural language processing tool providing lightweight troff roff typesetting macro processor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

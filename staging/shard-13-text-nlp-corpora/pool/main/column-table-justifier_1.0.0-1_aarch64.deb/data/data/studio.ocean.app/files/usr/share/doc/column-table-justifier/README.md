# column-table-justifier

plain text multi-column whitespace table aligner

## Description
Text tokenization and natural language processing tool providing plain text multi-column whitespace table aligner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# readability-flesch

Flesch Reading Ease and Kincaid grade level index

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

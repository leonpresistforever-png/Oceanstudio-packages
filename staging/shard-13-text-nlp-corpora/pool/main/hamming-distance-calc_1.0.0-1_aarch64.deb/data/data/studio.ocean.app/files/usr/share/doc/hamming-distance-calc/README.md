# hamming-distance-calc

Hamming distance bit-flip and character diff metric

## Description
Text tokenization and natural language processing tool providing Hamming distance bit-flip and character diff metric for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

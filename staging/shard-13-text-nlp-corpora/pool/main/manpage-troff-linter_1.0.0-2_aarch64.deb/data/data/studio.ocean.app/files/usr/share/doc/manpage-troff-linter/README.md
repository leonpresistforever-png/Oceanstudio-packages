# manpage-troff-linter

UNIX manual page groff man macro syntax validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# markdown-link-auditor

markdown internal and external URL hyperlink linter

## Description
Text tokenization and natural language processing tool providing markdown internal and external URL hyperlink linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

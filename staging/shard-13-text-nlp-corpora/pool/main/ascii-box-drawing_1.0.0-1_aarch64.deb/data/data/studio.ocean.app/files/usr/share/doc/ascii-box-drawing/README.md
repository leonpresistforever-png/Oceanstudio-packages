# ascii-box-drawing

Unicode box drawing border and panel generator

## Description
Text tokenization and natural language processing tool providing Unicode box drawing border and panel generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

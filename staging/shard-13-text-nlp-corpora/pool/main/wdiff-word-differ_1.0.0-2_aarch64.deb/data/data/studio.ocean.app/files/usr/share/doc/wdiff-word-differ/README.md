# wdiff-word-differ

word-by-word diff comparison for prose and text

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# spellcheck-hunspell

Hunspell affix and dictionary spell checking engine

## Description
Text tokenization and natural language processing tool providing Hunspell affix and dictionary spell checking engine for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# latex-math-sanitizer

LaTeX mathematical formula syntax validator

## Description
Text tokenization and natural language processing tool providing LaTeX mathematical formula syntax validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

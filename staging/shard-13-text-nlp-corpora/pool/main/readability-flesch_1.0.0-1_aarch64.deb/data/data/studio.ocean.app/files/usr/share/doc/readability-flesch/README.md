# readability-flesch

Flesch Reading Ease and Kincaid grade level index

## Description
Text tokenization and natural language processing tool providing Flesch Reading Ease and Kincaid grade level index for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

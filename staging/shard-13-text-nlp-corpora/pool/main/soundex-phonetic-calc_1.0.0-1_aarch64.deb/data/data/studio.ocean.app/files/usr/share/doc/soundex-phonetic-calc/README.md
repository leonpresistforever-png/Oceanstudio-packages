# soundex-phonetic-calc

Soundex phonetic indexing code calculator

## Description
Text tokenization and natural language processing tool providing Soundex phonetic indexing code calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

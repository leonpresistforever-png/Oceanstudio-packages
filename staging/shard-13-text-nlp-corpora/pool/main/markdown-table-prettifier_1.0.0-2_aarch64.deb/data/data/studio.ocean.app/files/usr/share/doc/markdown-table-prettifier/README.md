# markdown-table-prettifier

markdown pipe-delimited table column width aligner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

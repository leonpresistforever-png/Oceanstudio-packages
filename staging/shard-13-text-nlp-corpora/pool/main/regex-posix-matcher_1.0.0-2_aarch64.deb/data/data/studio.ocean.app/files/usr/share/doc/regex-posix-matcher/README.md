# regex-posix-matcher

POSIX Extended Regular Expression compliance tester

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

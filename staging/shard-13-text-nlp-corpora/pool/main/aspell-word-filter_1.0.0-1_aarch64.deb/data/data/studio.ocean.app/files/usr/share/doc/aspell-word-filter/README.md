# aspell-word-filter

Aspell phonetic spell checking word suggestion tool

## Description
Text tokenization and natural language processing tool providing Aspell phonetic spell checking word suggestion tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

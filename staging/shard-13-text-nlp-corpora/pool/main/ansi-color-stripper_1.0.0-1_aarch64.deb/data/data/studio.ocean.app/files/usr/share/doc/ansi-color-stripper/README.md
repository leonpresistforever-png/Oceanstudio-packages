# ansi-color-stripper

terminal ANSI escape code and color sequence remover

## Description
Text tokenization and natural language processing tool providing terminal ANSI escape code and color sequence remover for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

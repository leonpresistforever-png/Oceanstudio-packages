# unicode-codepoint-info

Unicode character property script and category lookup

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

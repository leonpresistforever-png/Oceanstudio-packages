# diskstats-parser

raw /proc/diskstats sector read/write metrics parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

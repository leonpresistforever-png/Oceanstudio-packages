# cgroup-memory-limiter

cgroup v1/v2 memory limit and usage inspector

## Description
Linux procfs and system diagnostic utility providing cgroup v1/v2 memory limit and usage inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

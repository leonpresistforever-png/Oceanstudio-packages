# iostat-collector

block device I/O throughput and queue latency analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# auxv-vector-inspector

ELF auxiliary vector AT_EXECFN and entrypoint viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

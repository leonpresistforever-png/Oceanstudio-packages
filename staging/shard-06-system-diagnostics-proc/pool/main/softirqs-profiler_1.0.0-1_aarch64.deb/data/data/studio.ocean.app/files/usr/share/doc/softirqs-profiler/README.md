# softirqs-profiler

software interrupt frequency and latency profiler

## Description
Linux procfs and system diagnostic utility providing software interrupt frequency and latency profiler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

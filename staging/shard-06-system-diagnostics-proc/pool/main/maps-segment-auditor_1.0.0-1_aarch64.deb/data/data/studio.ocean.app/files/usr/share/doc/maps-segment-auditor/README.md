# maps-segment-auditor

ELF virtual address space segment permission auditor

## Description
Linux procfs and system diagnostic utility providing ELF virtual address space segment permission auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

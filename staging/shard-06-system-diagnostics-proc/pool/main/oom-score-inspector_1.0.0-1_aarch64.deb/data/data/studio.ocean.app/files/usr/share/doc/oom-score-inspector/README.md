# oom-score-inspector

out-of-memory killer badness score calculator

## Description
Linux procfs and system diagnostic utility providing out-of-memory killer badness score calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# kernel-cmdline-parser

boot kernel parameter command line key-value parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

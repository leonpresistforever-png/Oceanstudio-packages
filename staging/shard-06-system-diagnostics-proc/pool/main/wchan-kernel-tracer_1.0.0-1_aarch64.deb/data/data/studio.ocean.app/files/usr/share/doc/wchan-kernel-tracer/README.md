# wchan-kernel-tracer

process kernel wait channel sleep state reporter

## Description
Linux procfs and system diagnostic utility providing process kernel wait channel sleep state reporter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# pstree-ocean

visual process tree hierarchy generator for Ocean

## Description
Linux procfs and system diagnostic utility providing visual process tree hierarchy generator for Ocean for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# tcp-socket-counter

TCP connection state distribution and queue counter

## Description
Linux procfs and system diagnostic utility providing TCP connection state distribution and queue counter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

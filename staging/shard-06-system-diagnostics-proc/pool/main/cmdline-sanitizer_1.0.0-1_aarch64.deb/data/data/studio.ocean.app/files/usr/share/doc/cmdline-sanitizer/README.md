# cmdline-sanitizer

process command line password and token mask tool

## Description
Linux procfs and system diagnostic utility providing process command line password and token mask tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# cgroup-tree-viewer

Linux control group hierarchy and controller viewer

## Description
Linux procfs and system diagnostic utility providing Linux control group hierarchy and controller viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

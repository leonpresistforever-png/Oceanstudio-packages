# dmesg-boot-filter

kernel ring buffer initialization and boot log filter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

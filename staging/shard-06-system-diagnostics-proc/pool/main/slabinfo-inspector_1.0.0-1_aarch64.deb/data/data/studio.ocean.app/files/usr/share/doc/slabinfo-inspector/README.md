# slabinfo-inspector

kernel slab cache object count and memory viewer

## Description
Linux procfs and system diagnostic utility providing kernel slab cache object count and memory viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

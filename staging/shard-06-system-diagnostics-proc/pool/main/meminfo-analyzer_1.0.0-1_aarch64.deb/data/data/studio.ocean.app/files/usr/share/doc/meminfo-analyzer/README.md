# meminfo-analyzer

Linux /proc/meminfo detailed breakdown and slab metrics

## Description
Linux procfs and system diagnostic utility providing Linux /proc/meminfo detailed breakdown and slab metrics for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# pagetype-fragmentation

physical memory page mobility and type analyzer

## Description
Linux procfs and system diagnostic utility providing physical memory page mobility and type analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

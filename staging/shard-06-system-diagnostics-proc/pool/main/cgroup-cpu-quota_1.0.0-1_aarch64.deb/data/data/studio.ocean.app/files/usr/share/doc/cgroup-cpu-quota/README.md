# cgroup-cpu-quota

cgroup CFS CPU quota and bandwidth auditor

## Description
Linux procfs and system diagnostic utility providing cgroup CFS CPU quota and bandwidth auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

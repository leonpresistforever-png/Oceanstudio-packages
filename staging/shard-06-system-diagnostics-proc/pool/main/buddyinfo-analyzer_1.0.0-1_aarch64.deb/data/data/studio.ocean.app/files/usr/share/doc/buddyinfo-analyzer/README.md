# buddyinfo-analyzer

buddy page allocator fragmentation order viewer

## Description
Linux procfs and system diagnostic utility providing buddy page allocator fragmentation order viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

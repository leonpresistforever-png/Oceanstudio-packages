# seccomp-filter-audit

process secure computing mode BPF filter status view

## Description
Linux procfs and system diagnostic utility providing process secure computing mode BPF filter status view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

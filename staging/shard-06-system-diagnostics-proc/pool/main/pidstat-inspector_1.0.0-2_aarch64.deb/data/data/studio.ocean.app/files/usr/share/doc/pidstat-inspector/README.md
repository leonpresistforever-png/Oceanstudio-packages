# pidstat-inspector

per-process CPU memory and thread resource monitor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

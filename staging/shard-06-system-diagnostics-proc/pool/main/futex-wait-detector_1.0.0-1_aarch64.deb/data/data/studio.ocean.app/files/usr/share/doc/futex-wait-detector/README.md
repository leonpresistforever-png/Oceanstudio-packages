# futex-wait-detector

hung thread fast userspace mutex lock detector

## Description
Linux procfs and system diagnostic utility providing hung thread fast userspace mutex lock detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

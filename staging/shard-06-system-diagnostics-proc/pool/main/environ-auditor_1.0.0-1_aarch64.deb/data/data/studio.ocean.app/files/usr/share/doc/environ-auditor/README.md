# environ-auditor

process environment variable null-byte stream decoder

## Description
Linux procfs and system diagnostic utility providing process environment variable null-byte stream decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

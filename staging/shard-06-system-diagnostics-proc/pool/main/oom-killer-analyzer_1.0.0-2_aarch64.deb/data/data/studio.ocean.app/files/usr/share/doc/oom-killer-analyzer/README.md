# oom-killer-analyzer

historical kernel OOM invocation log analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# limits-conf-checker

security limits.conf resource constraint validator

## Description
Linux procfs and system diagnostic utility providing security limits.conf resource constraint validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# zombie-process-killer

defunct zombie process parent PID tracer

## Description
Linux procfs and system diagnostic utility providing defunct zombie process parent PID tracer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

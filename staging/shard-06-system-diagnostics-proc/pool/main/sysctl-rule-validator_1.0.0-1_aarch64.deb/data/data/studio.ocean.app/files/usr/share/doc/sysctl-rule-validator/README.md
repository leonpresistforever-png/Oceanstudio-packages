# sysctl-rule-validator

Linux kernel sysctl parameters syntax and range checker

## Description
Linux procfs and system diagnostic utility providing Linux kernel sysctl parameters syntax and range checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

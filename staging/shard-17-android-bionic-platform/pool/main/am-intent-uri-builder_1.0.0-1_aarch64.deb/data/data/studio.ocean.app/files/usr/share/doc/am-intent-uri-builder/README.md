# am-intent-uri-builder

Android ActivityManager intent URI syntax generator

## Description
Android Bionic and runtime platform utility providing Android ActivityManager intent URI syntax generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

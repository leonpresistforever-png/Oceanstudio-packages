# dumpsys-battery-parse

Android dumpsys battery level voltage and temp parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

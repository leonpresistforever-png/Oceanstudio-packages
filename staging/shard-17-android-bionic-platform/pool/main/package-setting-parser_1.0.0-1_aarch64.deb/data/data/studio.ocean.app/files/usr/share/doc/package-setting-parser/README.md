# package-setting-parser

Android packages.xml permission and package parser

## Description
Android Bionic and runtime platform utility providing Android packages.xml permission and package parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

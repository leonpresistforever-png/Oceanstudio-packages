# setprop-format-checker

Android system property key name and value syntax linter

## Description
Android Bionic and runtime platform utility providing Android system property key name and value syntax linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

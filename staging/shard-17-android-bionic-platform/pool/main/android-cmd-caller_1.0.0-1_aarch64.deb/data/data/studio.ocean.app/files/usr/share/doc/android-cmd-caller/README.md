# android-cmd-caller

Android framework cmd interactive command line wrapper

## Description
Android Bionic and runtime platform utility providing Android framework cmd interactive command line wrapper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

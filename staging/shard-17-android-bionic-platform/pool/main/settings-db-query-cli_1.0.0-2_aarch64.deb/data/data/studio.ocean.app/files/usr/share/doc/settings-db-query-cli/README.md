# settings-db-query-cli

Android settings system secure global table parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# vdex-verifier-header

Android VDEX verified DEX container header inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

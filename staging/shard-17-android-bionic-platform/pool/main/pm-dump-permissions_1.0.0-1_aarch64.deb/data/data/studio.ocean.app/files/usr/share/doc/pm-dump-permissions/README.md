# pm-dump-permissions

Android PackageManager permission tree and group dump

## Description
Android Bionic and runtime platform utility providing Android PackageManager permission tree and group dump for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

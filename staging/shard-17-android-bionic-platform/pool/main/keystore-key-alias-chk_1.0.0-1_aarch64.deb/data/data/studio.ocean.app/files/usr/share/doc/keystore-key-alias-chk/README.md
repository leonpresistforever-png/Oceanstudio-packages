# keystore-key-alias-chk

Android KeyStore hardware-backed key alias checker

## Description
Android Bionic and runtime platform utility providing Android KeyStore hardware-backed key alias checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

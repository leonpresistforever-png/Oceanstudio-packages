# dex-string-id-dump

DEX string_ids and string_data_item MUTF-8 extractor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# package-signing-v2-chk

Android APK Signature Scheme v2 block 0x7109871a check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

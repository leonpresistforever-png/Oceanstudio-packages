# logcat-tag-filter

Android logcat binary logger buffer tag priority filter

## Description
Android Bionic and runtime platform utility providing Android logcat binary logger buffer tag priority filter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

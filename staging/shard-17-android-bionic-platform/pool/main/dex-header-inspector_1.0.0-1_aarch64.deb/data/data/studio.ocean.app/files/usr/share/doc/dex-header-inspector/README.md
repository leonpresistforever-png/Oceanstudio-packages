# dex-header-inspector

Dalvik Executable format 035-039 header magic analyzer

## Description
Android Bionic and runtime platform utility providing Dalvik Executable format 035-039 header magic analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

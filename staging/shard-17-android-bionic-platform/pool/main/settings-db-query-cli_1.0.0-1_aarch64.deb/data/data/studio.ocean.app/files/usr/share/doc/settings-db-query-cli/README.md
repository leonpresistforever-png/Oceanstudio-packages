# settings-db-query-cli

Android settings system secure global table parser

## Description
Android Bionic and runtime platform utility providing Android settings system secure global table parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

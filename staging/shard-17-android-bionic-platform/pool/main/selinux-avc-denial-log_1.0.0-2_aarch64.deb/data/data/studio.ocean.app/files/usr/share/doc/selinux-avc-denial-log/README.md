# selinux-avc-denial-log

SELinux Access Vector Cache denial audit parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# android-property-parser

Android __system_property_get memory structure parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dex-proto-id-view

DEX proto_ids method prototype parameter list viewer

## Description
Android Bionic and runtime platform utility providing DEX proto_ids method prototype parameter list viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

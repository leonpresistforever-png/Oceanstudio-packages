# service-list-auditor

Android ServiceManager registered IBinder service audit

## Description
Android Bionic and runtime platform utility providing Android ServiceManager registered IBinder service audit for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

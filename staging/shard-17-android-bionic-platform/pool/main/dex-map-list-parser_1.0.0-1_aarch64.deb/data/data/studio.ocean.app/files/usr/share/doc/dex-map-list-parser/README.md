# dex-map-list-parser

DEX file map_list item offset and section size tool

## Description
Android Bionic and runtime platform utility providing DEX file map_list item offset and section size tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

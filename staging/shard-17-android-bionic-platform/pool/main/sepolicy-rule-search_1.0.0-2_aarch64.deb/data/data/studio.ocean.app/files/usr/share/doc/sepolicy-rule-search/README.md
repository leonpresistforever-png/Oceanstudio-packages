# sepolicy-rule-search

Android compiled sepolicy TE allow rule search engine

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

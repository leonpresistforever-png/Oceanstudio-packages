# dex-proto-id-view

DEX proto_ids method prototype parameter list viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

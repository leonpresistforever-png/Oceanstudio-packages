# package-signing-v1-chk

Android APK Signature Scheme v1 JAR manifest check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dex-type-id-parser

DEX type_ids type descriptor table decompiler

## Description
Android Bionic and runtime platform utility providing DEX type_ids type descriptor table decompiler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

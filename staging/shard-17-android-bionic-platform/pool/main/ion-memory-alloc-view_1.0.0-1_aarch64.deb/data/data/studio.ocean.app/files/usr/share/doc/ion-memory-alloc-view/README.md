# ion-memory-alloc-view

Android ION memory allocator client heap status view

## Description
Android Bionic and runtime platform utility providing Android ION memory allocator client heap status view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# boot-image-v4-header

Android boot image v3/v4 kernel ramdisk header parser

## Description
Android Bionic and runtime platform utility providing Android boot image v3/v4 kernel ramdisk header parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

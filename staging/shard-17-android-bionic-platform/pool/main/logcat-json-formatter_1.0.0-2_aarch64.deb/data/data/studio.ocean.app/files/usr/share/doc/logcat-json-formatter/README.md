# logcat-json-formatter

Android logcat stream to NDJSON event converter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# input-event-code-view

Linux /dev/input/event EV_KEY EV_ABS event code parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

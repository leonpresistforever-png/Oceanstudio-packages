# dumpsys-window-parser

dumpsys window display orientation and bounds parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

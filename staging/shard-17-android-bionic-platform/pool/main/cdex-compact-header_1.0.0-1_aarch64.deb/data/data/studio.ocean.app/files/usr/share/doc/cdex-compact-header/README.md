# cdex-compact-header

Compact DEX CDEX header and shared data section view

## Description
Android Bionic and runtime platform utility providing Compact DEX CDEX header and shared data section view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

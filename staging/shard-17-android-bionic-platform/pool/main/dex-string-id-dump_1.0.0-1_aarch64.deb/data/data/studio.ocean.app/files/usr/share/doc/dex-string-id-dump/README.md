# dex-string-id-dump

DEX string_ids and string_data_item MUTF-8 extractor

## Description
Android Bionic and runtime platform utility providing DEX string_ids and string_data_item MUTF-8 extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

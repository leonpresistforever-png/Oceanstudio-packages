# package-signing-v4-chk

Android APK Signature Scheme v4 Merkle tree file check

## Description
Android Bionic and runtime platform utility providing Android APK Signature Scheme v4 Merkle tree file check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

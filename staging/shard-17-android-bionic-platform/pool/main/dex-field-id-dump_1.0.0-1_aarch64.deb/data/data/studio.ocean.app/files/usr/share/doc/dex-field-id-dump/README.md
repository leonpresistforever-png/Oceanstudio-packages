# dex-field-id-dump

DEX field_ids class field definition list viewer

## Description
Android Bionic and runtime platform utility providing DEX field_ids class field definition list viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

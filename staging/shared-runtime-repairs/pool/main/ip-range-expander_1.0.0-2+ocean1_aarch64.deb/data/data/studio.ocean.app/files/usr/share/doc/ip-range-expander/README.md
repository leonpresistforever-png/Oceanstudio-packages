# ip-range-expander

IP CIDR notation to sequential IP list generator
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard08_network.py
Source SHA256: f70c50f1819e12a71f3397f37abc1e8e4b068bc5c0ff28258cc6b2d02506ddd1
Shared runtime package: ocean-runtime-shard08-network

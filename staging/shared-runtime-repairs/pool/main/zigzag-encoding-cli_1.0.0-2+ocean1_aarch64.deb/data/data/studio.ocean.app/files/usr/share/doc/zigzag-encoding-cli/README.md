# zigzag-encoding-cli

signed integer ZigZag encoding for variable-byte tools
 Functional OceanStudio implementation for Android AArch64.
 This repair replaces the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard27_etl.py
Source SHA256: e8113e89c178b8f6732a695e85c0319cfc8ff876d2231495d4385cc0832bf965
Shared runtime package: ocean-runtime-shard27-etl

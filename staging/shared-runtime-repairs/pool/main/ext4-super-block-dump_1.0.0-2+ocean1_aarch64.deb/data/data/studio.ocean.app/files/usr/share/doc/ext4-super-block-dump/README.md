# ext4-super-block-dump

ext4 superblock feature flags and block group view
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard09_storage.py
Source SHA256: 7c42ad9ebb377ef6c881c61fca18134e3aabd59bfe66213c96505bfbd6721e27
Shared runtime package: ocean-runtime-shard09-storage

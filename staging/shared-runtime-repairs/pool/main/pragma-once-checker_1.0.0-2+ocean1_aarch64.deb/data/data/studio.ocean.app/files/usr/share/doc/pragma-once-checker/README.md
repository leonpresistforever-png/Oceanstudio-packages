# pragma-once-checker

source tree header #pragma once usage checker
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard11_toolchain.py
Source SHA256: 395a6cda264f9dc22bf4bba46f9f9e308bc918b8ad578bb1482eb881c2477eaf
Shared runtime package: ocean-runtime-shard11-toolchain

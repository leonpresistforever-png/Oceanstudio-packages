# motorola-srec-parser

Motorola S-Record S0 S1 S2 S3 S7 S8 S9 decompiler
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard24_firmware.py
Source SHA256: e9c15f1799a2e431ed57ff63452cc3c64aad53c92177b250d4f544aceabcb4b4
Shared runtime package: ocean-runtime-shard24-firmware

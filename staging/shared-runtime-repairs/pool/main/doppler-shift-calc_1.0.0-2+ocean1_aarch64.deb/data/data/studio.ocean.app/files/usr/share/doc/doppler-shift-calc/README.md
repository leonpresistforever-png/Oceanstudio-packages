# doppler-shift-calc

Doppler frequency shift acoustic and RF calculator
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard16_math.py
Source SHA256: b9a36130887fbfbb728b13f3950f4cbd8ba5f824d27edf8d06306e507d54364c
Shared runtime package: ocean-runtime-shard16-math

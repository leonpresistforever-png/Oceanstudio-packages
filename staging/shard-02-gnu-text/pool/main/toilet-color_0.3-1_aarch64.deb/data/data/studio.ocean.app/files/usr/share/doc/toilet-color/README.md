# toilet-color

colourful text banner generator using libcaca

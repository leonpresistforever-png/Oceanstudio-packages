# slug-generator

convert text strings into URL-safe slugs

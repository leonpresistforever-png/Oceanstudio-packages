# text-frequency

calculate n-gram and word frequency in text stream

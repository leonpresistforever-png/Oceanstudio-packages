# bsd-ul

do underline highlighting on CRT displays

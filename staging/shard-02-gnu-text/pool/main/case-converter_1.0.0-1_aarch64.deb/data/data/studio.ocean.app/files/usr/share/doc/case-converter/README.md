# case-converter

convert text streams between case formats

# diff-highlighter

syntax highlighter for unified diff streams

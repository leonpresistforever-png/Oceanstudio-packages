# moreutils-ts

timestamp standard input lines with microsecond precision

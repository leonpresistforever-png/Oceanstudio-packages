# text-trim

strip leading and trailing whitespace from lines

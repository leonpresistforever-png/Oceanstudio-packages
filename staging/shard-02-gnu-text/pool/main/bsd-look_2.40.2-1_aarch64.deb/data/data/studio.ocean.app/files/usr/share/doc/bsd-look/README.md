# bsd-look

display lines beginning with a given prefix

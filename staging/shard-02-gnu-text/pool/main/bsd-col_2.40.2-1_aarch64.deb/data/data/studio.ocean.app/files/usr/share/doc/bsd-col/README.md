# bsd-col

filter reverse line feeds and form feeds

# cowsay-collection

configurable ASCII speaking character generator

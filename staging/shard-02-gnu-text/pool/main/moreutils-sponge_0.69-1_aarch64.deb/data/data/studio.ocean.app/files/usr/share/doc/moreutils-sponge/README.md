# moreutils-sponge

soak up standard input and write to a file

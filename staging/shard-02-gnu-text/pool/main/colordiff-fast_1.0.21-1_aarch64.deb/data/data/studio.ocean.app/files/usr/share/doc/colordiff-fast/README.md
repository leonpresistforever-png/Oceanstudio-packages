# colordiff-fast

color-highlighted diff display for terminal

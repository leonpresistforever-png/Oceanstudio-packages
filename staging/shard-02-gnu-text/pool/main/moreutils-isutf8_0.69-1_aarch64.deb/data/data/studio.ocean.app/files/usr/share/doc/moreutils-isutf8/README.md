# moreutils-isutf8

check whether files or stdin are valid UTF-8

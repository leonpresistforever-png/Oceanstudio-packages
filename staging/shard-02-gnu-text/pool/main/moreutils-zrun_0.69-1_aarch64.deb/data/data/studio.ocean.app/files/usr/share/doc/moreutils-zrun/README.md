# moreutils-zrun

automatically decompress arguments to command

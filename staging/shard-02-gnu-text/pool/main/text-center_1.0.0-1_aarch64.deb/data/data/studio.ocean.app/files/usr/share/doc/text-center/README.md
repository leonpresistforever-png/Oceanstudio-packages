# text-center

center text lines horizontally in terminal

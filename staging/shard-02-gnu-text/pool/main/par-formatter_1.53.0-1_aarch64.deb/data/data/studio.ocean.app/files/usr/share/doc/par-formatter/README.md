# par-formatter

paragraph formatting filter with reflowing

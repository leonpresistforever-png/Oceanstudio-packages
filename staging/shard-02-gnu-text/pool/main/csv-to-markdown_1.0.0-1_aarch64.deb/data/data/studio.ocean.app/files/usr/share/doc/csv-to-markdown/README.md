# csv-to-markdown

convert CSV input into readable Markdown table

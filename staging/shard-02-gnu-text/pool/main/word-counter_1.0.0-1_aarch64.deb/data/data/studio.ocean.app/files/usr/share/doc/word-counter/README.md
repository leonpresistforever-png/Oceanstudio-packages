# word-counter

fast stream word character and syllable counter

# bson-json-converter

convert between MongoDB BSON and JSON format

# sqlite-to-csv

export SQLite query results directly to CSV format

# base62-encoder-tool

Base62 alphanumeric encoding and decoding CLI

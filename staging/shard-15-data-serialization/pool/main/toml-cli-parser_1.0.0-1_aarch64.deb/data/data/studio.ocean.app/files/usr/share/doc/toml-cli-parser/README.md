# toml-cli-parser

parse, query and validate TOML configuration files

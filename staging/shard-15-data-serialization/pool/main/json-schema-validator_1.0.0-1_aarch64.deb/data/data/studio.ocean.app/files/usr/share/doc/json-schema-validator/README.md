# json-schema-validator

validate JSON instances against JSON Schema Draft 7/2020-12

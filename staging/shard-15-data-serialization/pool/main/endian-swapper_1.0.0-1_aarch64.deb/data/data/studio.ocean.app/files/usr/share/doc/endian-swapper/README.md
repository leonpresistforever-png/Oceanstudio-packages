# endian-swapper

swap endianness of 16-bit, 32-bit and 64-bit words

# sqlite-to-json

export SQLite query results as structured JSON objects

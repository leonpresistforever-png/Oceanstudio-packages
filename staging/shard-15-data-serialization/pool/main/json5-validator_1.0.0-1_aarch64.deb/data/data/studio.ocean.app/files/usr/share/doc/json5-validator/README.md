# json5-validator

validate and parse JSON5 extensible format

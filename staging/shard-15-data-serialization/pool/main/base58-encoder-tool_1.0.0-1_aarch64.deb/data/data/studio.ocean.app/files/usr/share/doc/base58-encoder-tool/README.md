# base58-encoder-tool

Bitcoin/IPFS Base58 encoding and decoding CLI

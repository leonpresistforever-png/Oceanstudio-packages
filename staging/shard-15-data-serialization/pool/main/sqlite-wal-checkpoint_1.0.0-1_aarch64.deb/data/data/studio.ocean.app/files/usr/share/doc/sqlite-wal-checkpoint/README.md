# sqlite-wal-checkpoint

force checkpoint and truncate WAL logs in SQLite database

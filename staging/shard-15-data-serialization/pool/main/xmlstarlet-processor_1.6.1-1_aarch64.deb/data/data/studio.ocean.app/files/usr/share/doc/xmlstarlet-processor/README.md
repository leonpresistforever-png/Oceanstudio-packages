# xmlstarlet-processor

command line XML toolkit for query and transform

# jansson-json-tools

C JSON library encoding and validation CLI

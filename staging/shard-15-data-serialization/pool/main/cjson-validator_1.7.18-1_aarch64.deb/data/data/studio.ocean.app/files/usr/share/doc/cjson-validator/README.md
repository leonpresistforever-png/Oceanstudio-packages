# cjson-validator

ultralightweight JSON parser and syntax validator

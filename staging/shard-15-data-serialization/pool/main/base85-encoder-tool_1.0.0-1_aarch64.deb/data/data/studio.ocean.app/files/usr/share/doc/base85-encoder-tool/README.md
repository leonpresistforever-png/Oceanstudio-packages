# base85-encoder-tool

Adobe/Ascii85 and RFC 1924 Base85 encoding tool

# yq-yaml-processor

portable command-line YAML/JSON/XML processor

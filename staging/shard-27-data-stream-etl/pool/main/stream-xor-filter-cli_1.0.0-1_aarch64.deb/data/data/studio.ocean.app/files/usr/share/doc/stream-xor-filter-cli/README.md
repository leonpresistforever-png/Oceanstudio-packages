# stream-xor-filter-cli

fast stream XOR filter membership data structure tool

## Description
Data stream transformation and ETL pipeline tool providing fast stream XOR filter membership data structure tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

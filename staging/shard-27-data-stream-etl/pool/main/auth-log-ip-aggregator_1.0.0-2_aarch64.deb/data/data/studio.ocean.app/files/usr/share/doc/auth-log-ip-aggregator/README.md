# auth-log-ip-aggregator

Linux /var/log/auth.log failed SSH IP address aggregator

This package is part of OceanStudio's repaired functional shard 27.
Unlike the earlier placeholder build, this version executes real data-processing logic.

Version: 1.0.0-2
Runtime: Python standard library only
Prefix: /data/data/studio.ocean.app/files/usr

# bit-packing-unpacker

tight bit-packing and unpacking integer array utility

## Description
Data stream transformation and ETL pipeline tool providing tight bit-packing and unpacking integer array utility for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# stream-moving-average

Simple Moving Average SMA stream filter utility

## Description
Data stream transformation and ETL pipeline tool providing Simple Moving Average SMA stream filter utility for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

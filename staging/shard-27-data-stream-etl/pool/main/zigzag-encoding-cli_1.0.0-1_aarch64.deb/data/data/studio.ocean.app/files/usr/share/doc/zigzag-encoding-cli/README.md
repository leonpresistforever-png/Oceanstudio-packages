# zigzag-encoding-cli

signed integer ZigZag encoding for variable-byte tools

## Description
Data stream transformation and ETL pipeline tool providing signed integer ZigZag encoding for variable-byte tools for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# tsv-sliding-window-avg

TSV numeric column rolling sliding window average tool

## Description
Data stream transformation and ETL pipeline tool providing TSV numeric column rolling sliding window average tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

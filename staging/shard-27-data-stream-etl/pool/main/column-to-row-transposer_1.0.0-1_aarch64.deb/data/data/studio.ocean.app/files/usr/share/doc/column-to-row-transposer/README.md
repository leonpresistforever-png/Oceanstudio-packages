# column-to-row-transposer

CSV column vector to row vector conversion helper

## Description
Data stream transformation and ETL pipeline tool providing CSV column vector to row vector conversion helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

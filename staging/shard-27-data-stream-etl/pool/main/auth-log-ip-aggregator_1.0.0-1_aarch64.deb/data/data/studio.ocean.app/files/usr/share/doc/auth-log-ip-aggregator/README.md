# auth-log-ip-aggregator

Linux /var/log/auth.log failed SSH IP address aggregator

## Description
Data stream transformation and ETL pipeline tool providing Linux /var/log/auth.log failed SSH IP address aggregator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

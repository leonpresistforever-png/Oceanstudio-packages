# run-length-encoder-cli

byte-level Run-Length Encoding RLE compression tool

## Description
Data stream transformation and ETL pipeline tool providing byte-level Run-Length Encoding RLE compression tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

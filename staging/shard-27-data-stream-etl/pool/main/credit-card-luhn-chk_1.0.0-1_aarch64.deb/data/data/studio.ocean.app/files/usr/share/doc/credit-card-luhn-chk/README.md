# credit-card-luhn-chk

Luhn algorithm Mod 10 credit card number validator

## Description
Data stream transformation and ETL pipeline tool providing Luhn algorithm Mod 10 credit card number validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

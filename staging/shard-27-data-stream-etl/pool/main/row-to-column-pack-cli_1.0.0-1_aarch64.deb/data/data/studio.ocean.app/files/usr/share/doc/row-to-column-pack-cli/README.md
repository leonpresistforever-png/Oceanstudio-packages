# row-to-column-pack-cli

row-based JSON records to columnar array converter

## Description
Data stream transformation and ETL pipeline tool providing row-based JSON records to columnar array converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

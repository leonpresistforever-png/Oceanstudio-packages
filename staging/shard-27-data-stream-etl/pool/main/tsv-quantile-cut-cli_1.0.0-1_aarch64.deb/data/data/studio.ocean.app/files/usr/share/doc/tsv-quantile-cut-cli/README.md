# tsv-quantile-cut-cli

TSV numerical values into quantile bins discretization

## Description
Data stream transformation and ETL pipeline tool providing TSV numerical values into quantile bins discretization for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

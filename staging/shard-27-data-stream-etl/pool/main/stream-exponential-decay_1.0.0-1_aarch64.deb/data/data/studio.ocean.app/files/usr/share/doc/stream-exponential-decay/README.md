# stream-exponential-decay

Exponential Moving Average EMA half-life calculator

## Description
Data stream transformation and ETL pipeline tool providing Exponential Moving Average EMA half-life calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

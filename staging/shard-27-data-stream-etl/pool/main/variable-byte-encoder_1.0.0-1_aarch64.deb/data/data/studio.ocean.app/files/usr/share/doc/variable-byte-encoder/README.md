# variable-byte-encoder

LEB128 variable-length integer byte stream encoder

## Description
Data stream transformation and ETL pipeline tool providing LEB128 variable-length integer byte stream encoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

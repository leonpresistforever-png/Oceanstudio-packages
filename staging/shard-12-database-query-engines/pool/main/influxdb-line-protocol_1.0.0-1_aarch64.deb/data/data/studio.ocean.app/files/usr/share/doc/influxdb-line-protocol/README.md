# influxdb-line-protocol

InfluxDB Line Protocol point measurement validator

## Description
Embedded database and SQL processing engine providing InfluxDB Line Protocol point measurement validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

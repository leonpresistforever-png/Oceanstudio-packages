# sqlite-index-recommend

SQLite query execution plan index recommender

## Description
Embedded database and SQL processing engine providing SQLite query execution plan index recommender for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

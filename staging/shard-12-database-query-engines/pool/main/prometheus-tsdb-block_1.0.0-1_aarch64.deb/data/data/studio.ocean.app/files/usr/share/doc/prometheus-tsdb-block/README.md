# prometheus-tsdb-block

Prometheus TSDB 2-hour block meta.json inspector

## Description
Embedded database and SQL processing engine providing Prometheus TSDB 2-hour block meta.json inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

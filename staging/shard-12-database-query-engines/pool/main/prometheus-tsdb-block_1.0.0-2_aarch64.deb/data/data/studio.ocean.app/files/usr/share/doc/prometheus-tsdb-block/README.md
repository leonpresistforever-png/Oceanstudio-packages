# prometheus-tsdb-block

Prometheus TSDB 2-hour block meta.json inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

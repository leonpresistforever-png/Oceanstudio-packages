# arrow-ipc-validator

Apache Arrow IPC stream and record batch validator

## Description
Embedded database and SQL processing engine providing Apache Arrow IPC stream and record batch validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

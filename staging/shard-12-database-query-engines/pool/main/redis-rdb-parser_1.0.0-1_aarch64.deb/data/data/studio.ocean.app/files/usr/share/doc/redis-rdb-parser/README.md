# redis-rdb-parser

Redis RDB snapshot file opcode and key-value parser

## Description
Embedded database and SQL processing engine providing Redis RDB snapshot file opcode and key-value parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

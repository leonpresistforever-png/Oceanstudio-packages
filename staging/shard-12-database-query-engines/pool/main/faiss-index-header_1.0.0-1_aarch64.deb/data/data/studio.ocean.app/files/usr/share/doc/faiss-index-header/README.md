# faiss-index-header

FAISS vector index file header and dimensionality viewer

## Description
Embedded database and SQL processing engine providing FAISS vector index file header and dimensionality viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

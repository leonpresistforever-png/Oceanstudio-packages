# sql-injection-tester

SQL query literal parameterization security checker

## Description
Embedded database and SQL processing engine providing SQL query literal parameterization security checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

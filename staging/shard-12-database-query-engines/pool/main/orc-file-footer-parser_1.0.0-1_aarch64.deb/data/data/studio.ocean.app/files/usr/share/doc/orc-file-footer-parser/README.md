# orc-file-footer-parser

Apache ORC file footer and stripe metadata parser

## Description
Embedded database and SQL processing engine providing Apache ORC file footer and stripe metadata parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

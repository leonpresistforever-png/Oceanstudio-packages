# db-foreign-key-chk

relational database foreign key constraint auditor

## Description
Embedded database and SQL processing engine providing relational database foreign key constraint auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# sqlite-json-query-cli

SQLite json_extract and json_each CLI processor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

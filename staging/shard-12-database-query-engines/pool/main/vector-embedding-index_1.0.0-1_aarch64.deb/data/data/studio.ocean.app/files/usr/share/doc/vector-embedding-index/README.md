# vector-embedding-index

high-dimensional vector cosine similarity indexer

## Description
Embedded database and SQL processing engine providing high-dimensional vector cosine similarity indexer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

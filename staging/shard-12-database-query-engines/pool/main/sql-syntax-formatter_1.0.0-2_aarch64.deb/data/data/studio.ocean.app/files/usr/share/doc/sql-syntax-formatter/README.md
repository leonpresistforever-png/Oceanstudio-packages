# sql-syntax-formatter

SQL query prettifier and indentation formatter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

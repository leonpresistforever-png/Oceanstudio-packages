# duckdb-query-runner

analytical columnar SQL database CLI runner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

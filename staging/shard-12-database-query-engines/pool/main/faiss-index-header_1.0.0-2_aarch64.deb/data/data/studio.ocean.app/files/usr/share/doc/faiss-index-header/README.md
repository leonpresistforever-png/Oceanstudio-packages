# faiss-index-header

FAISS vector index file header and dimensionality viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

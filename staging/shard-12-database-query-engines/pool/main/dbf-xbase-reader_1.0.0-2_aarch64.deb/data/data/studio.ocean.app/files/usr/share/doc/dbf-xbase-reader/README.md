# dbf-xbase-reader

dBase III/IV DBF table header and record extractor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

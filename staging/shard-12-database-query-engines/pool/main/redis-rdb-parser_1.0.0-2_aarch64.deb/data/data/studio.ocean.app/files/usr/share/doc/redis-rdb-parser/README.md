# redis-rdb-parser

Redis RDB snapshot file opcode and key-value parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

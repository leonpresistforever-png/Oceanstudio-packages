# memcached-text-proto

Memcached ASCII and binary protocol command tester

## Description
Embedded database and SQL processing engine providing Memcached ASCII and binary protocol command tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

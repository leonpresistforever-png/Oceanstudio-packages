# sqlite-blob-extractor

SQLite table BLOB column raw binary stream extractor

## Description
Embedded database and SQL processing engine providing SQLite table BLOB column raw binary stream extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

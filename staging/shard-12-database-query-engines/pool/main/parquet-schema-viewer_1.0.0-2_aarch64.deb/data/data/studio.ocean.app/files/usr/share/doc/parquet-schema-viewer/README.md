# parquet-schema-viewer

Apache Parquet thrift file metadata schema viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# sqlite-rbtree-visualizer

SQLite index B-tree balancing visualizer

## Description
Embedded database and SQL processing engine providing SQLite index B-tree balancing visualizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

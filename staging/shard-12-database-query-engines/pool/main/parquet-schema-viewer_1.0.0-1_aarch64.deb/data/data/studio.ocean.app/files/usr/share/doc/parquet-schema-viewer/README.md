# parquet-schema-viewer

Apache Parquet thrift file metadata schema viewer

## Description
Embedded database and SQL processing engine providing Apache Parquet thrift file metadata schema viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dbf-xbase-reader

dBase III/IV DBF table header and record extractor

## Description
Embedded database and SQL processing engine providing dBase III/IV DBF table header and record extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# redis-resp-encoder

Redis REdis Serialization Protocol RESP2/RESP3 encoder

## Description
Embedded database and SQL processing engine providing Redis REdis Serialization Protocol RESP2/RESP3 encoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

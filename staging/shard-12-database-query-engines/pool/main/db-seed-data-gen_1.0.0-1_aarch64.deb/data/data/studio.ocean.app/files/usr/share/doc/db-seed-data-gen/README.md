# db-seed-data-gen

relational database deterministic mock row generator

## Description
Embedded database and SQL processing engine providing relational database deterministic mock row generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

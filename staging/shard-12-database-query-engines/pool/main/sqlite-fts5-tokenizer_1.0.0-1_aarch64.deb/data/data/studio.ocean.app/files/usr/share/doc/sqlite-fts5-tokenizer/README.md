# sqlite-fts5-tokenizer

SQLite Full Text Search 5 tokenizer query tool

## Description
Embedded database and SQL processing engine providing SQLite Full Text Search 5 tokenizer query tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

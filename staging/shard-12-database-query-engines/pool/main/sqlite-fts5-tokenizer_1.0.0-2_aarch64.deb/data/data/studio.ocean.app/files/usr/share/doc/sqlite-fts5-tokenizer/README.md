# sqlite-fts5-tokenizer

SQLite Full Text Search 5 tokenizer query tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

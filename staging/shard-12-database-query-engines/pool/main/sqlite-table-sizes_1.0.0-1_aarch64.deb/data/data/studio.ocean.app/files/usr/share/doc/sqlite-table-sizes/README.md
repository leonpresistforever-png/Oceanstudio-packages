# sqlite-table-sizes

SQLite database per-table disk space usage analyzer

## Description
Embedded database and SQL processing engine providing SQLite database per-table disk space usage analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

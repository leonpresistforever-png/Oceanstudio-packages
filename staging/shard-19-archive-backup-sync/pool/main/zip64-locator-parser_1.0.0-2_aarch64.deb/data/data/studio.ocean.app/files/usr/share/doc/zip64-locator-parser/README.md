# zip64-locator-parser

ZIP64 End of Central Directory record locator tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# xar-xml-toc-extractor

eXtensible ARchive XAR XML Table of Contents tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# tar-gnu-longlink-chk

tar ././@LongLink path overflow entry inspector

## Description
Archive file format and differential backup utility providing tar ././@LongLink path overflow entry inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

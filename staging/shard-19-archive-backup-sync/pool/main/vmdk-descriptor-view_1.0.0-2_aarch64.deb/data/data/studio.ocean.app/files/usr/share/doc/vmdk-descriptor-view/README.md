# vmdk-descriptor-view

VMware VMDK monolithic sparse descriptor viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

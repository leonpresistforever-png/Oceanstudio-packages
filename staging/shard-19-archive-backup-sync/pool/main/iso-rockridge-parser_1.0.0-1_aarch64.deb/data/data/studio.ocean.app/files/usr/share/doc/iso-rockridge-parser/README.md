# iso-rockridge-parser

ISO 9660 Rock Ridge interchange protocol parser

## Description
Archive file format and differential backup utility providing ISO 9660 Rock Ridge interchange protocol parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

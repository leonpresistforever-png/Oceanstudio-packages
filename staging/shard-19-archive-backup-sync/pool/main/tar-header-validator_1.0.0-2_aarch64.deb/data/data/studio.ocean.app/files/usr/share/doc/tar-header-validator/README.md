# tar-header-validator

POSIX ustar and GNU tar header block checksum tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

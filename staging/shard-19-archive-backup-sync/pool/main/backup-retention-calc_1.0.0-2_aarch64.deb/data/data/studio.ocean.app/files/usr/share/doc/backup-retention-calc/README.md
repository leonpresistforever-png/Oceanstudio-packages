# backup-retention-calc

Grandfather-Father-Son backup retention schedule tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

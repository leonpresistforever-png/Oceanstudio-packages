# deb-ar-data-splitter

Debian deb package debian-binary control data splitter

## Description
Archive file format and differential backup utility providing Debian deb package debian-binary control data splitter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

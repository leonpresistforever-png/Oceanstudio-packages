# zip-eocd-locator-cli

ZIP End of Central Directory record offset locator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

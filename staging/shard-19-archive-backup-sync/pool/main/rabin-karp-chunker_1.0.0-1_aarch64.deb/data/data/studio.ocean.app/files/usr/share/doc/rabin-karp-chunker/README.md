# rabin-karp-chunker

Rabin-Karp fingerprint rolling hash chunking tool

## Description
Archive file format and differential backup utility providing Rabin-Karp fingerprint rolling hash chunking tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

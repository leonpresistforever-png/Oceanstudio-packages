# backup-catalog-verify

backup manifest database catalog consistency checker

## Description
Archive file format and differential backup utility providing backup manifest database catalog consistency checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

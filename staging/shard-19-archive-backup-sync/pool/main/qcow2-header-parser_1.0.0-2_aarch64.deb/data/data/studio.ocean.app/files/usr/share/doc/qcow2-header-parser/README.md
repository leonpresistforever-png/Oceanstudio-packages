# qcow2-header-parser

QEMU Copy-On-Write qcow2 header and L1 table reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

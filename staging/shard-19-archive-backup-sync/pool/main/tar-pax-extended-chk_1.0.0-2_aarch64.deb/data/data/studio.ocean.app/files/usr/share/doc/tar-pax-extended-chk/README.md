# tar-pax-extended-chk

POSIX.1-2001 pax extended header attribute parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

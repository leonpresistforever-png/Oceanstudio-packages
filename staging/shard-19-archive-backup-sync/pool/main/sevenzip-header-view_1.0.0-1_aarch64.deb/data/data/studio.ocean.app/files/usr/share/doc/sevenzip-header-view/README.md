# sevenzip-header-view

7z stream folder coders and unpack sizes reader

## Description
Archive file format and differential backup utility providing 7z stream folder coders and unpack sizes reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# afio-archive-linter

afio crash-tolerant cpio archive format validator

## Description
Archive file format and differential backup utility providing afio crash-tolerant cpio archive format validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# adler32-rolling-calc

rolling Adler-32 incremental checksum calculator

## Description
Archive file format and differential backup utility providing rolling Adler-32 incremental checksum calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

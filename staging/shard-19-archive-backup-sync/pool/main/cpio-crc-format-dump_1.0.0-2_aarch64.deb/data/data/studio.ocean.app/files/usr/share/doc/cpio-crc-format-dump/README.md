# cpio-crc-format-dump

cpio CRC format file magic and inode table parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

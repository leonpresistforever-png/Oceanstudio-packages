# tar-sparse-header-chk

GNU tar sparse file map header and offset viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

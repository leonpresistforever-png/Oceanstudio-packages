# raw-disk-image-resizer

raw sector image boundary calculation and expander

## Description
Archive file format and differential backup utility providing raw sector image boundary calculation and expander for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

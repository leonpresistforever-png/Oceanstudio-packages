# ar-bsd-variant-parser

BSD ar archive #1/ extended file name parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

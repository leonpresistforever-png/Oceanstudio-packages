# vhd-footer-inspector

Virtual Hard Disk VHD fixed/dynamic footer reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

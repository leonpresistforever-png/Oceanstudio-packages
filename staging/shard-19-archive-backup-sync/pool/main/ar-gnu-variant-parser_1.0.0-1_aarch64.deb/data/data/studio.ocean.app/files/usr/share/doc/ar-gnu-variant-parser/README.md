# ar-gnu-variant-parser

GNU ar archive // long file name table parser

## Description
Archive file format and differential backup utility providing GNU ar archive // long file name table parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

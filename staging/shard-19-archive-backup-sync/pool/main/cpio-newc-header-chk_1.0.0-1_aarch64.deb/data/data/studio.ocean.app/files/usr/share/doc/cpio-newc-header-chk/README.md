# cpio-newc-header-chk

cpio SVR4 new ASCII format header validator

## Description
Archive file format and differential backup utility providing cpio SVR4 new ASCII format header validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

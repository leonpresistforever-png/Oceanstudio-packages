# ext4-dump-restore-chk

ext4 dump/restore tape archive format inspector

## Description
Archive file format and differential backup utility providing ext4 dump/restore tape archive format inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# afio-archive-linter

afio crash-tolerant cpio archive format validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

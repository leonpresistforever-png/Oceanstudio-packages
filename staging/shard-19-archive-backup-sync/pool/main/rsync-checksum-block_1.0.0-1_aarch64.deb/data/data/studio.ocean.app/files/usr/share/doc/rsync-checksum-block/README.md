# rsync-checksum-block

rsync rolling checksum and MD4/MD5 block calculator

## Description
Archive file format and differential backup utility providing rsync rolling checksum and MD4/MD5 block calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

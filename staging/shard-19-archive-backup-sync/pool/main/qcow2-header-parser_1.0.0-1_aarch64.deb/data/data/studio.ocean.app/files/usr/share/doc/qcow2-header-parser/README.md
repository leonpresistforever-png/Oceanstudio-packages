# qcow2-header-parser

QEMU Copy-On-Write qcow2 header and L1 table reader

## Description
Archive file format and differential backup utility providing QEMU Copy-On-Write qcow2 header and L1 table reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

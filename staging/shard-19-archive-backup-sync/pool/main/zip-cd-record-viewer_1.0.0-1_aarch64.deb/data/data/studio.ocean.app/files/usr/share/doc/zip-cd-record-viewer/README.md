# zip-cd-record-viewer

ZIP Central Directory file header table inspector

## Description
Archive file format and differential backup utility providing ZIP Central Directory file header table inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

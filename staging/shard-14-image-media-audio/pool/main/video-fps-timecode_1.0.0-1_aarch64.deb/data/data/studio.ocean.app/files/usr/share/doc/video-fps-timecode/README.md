# video-fps-timecode

video frame rate SMPTE drop-frame timecode converter

## Description
Media header parser and audiovisual engineering utility providing video frame rate SMPTE drop-frame timecode converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

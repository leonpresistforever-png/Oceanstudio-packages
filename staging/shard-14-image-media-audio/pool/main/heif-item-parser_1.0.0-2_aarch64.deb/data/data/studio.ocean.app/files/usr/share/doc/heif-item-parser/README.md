# heif-item-parser

High Efficiency Image File meta iref iprp box reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

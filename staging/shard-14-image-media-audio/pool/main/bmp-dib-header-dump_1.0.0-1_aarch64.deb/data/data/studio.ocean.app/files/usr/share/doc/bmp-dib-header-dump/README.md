# bmp-dib-header-dump

Windows Bitmap BITMAPINFOHEADER DIB header parser

## Description
Media header parser and audiovisual engineering utility providing Windows Bitmap BITMAPINFOHEADER DIB header parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

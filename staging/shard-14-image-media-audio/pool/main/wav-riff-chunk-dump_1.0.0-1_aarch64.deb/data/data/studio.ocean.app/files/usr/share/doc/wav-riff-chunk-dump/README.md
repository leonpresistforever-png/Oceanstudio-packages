# wav-riff-chunk-dump

WAV RIFF fmt data chunk structure analyzer

## Description
Media header parser and audiovisual engineering utility providing WAV RIFF fmt data chunk structure analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

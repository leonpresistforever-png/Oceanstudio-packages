# svg-viewbox-fixer

SVG viewBox width height coordinate space normalizer

## Description
Media header parser and audiovisual engineering utility providing SVG viewBox width height coordinate space normalizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

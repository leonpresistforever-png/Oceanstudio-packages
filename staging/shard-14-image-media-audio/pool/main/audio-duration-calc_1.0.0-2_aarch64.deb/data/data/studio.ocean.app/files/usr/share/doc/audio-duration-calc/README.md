# audio-duration-calc

uncompressed audio file duration from byte length calc

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

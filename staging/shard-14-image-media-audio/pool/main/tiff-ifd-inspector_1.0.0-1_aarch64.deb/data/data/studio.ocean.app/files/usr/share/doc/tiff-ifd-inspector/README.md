# tiff-ifd-inspector

TIFF Image File Directory tag count and offset reader

## Description
Media header parser and audiovisual engineering utility providing TIFF Image File Directory tag count and offset reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

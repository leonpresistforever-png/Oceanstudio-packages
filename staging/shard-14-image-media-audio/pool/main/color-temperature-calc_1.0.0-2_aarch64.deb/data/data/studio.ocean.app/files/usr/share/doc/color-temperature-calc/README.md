# color-temperature-calc

Kelvin color temperature to approximate RGB calc

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

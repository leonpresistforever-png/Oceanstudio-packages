# pcm-sample-rate-conv

PCM raw audio sample rate and bit depth calculator

## Description
Media header parser and audiovisual engineering utility providing PCM raw audio sample rate and bit depth calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

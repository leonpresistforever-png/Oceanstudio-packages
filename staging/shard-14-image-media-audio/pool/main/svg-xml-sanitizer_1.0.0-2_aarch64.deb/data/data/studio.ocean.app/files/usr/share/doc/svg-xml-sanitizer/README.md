# svg-xml-sanitizer

SVG XML malicious script and entity reference cleaner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# color-contrast-wcag

WCAG 2.1 accessible color luminance contrast ratio calc

## Description
Media header parser and audiovisual engineering utility providing WCAG 2.1 accessible color luminance contrast ratio calc for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

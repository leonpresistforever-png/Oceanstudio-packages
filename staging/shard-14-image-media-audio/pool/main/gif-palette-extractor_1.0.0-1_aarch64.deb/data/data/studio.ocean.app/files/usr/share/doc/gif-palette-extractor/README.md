# gif-palette-extractor

GIF global and local color table palette viewer

## Description
Media header parser and audiovisual engineering utility providing GIF global and local color table palette viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

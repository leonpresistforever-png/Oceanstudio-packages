# wav-fmt-spec-checker

WAV audio sample rate bit depth channel count inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# subtitle-srt-time-shift

SubRip SRT subtitle timestamp offset shifting tool

## Description
Media header parser and audiovisual engineering utility providing SubRip SRT subtitle timestamp offset shifting tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

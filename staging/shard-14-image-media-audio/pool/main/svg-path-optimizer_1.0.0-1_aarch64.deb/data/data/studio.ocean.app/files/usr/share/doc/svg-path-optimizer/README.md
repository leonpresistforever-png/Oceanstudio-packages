# svg-path-optimizer

SVG path data decimal precision reducer and cleaner

## Description
Media header parser and audiovisual engineering utility providing SVG path data decimal precision reducer and cleaner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# png-chunk-parser

Portable Network Graphics chunk structure and CRC validator

## Description
Media header parser and audiovisual engineering utility providing Portable Network Graphics chunk structure and CRC validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

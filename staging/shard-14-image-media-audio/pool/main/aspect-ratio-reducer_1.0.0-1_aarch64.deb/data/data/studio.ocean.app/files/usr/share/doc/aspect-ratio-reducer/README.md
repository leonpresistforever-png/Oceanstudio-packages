# aspect-ratio-reducer

screen resolution to simplified aspect ratio reducer

## Description
Media header parser and audiovisual engineering utility providing screen resolution to simplified aspect ratio reducer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# mkv-ebml-header-dump

Matroska EBML document header and track UID reader

## Description
Media header parser and audiovisual engineering utility providing Matroska EBML document header and track UID reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

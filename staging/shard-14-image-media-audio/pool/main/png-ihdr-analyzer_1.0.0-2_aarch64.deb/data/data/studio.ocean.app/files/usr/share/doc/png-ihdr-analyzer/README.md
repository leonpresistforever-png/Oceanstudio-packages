# png-ihdr-analyzer

PNG IHDR dimensions bit-depth and color type reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

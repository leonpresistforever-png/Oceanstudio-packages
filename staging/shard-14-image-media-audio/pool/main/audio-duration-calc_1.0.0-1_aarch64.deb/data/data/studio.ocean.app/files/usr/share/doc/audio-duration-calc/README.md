# audio-duration-calc

uncompressed audio file duration from byte length calc

## Description
Media header parser and audiovisual engineering utility providing uncompressed audio file duration from byte length calc for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# wav-fmt-spec-checker

WAV audio sample rate bit depth channel count inspector

## Description
Media header parser and audiovisual engineering utility providing WAV audio sample rate bit depth channel count inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# mp3-id3v2-tag-dump

MP3 ID3v2.3/ID3v2.4 frame header and text tag parser

## Description
Media header parser and audiovisual engineering utility providing MP3 ID3v2.3/ID3v2.4 frame header and text tag parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

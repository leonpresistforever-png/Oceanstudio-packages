# dpi-calculator-cli

display dots-per-inch and physical screen dimension calc

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

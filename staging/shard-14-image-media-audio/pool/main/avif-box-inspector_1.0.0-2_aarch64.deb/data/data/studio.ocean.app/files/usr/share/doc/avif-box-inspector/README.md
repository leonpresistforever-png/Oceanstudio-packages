# avif-box-inspector

AV1 Image File Format ISOBMFF box item parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

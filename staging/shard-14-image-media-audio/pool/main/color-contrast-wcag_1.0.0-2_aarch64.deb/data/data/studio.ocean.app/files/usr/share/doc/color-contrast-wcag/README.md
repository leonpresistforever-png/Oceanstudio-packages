# color-contrast-wcag

WCAG 2.1 accessible color luminance contrast ratio calc

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

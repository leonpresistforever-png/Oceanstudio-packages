# png-chunk-parser

Portable Network Graphics chunk structure and CRC validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

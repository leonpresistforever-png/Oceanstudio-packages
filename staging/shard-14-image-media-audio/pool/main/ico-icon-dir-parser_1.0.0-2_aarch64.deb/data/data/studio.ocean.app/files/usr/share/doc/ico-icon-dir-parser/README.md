# ico-icon-dir-parser

Windows Icon ICONDIR and ICONDIRENTRY image parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

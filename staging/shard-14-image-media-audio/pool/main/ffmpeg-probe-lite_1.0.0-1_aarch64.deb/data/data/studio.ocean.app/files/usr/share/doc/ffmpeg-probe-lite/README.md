# ffmpeg-probe-lite

multimedia container stream audio/video track prober

## Description
Media header parser and audiovisual engineering utility providing multimedia container stream audio/video track prober for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# vorbis-comment-reader

Ogg Vorbis user comment vendor string field extractor

## Description
Media header parser and audiovisual engineering utility providing Ogg Vorbis user comment vendor string field extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# tga-header-analyzer

Truevision TGA header color map and pixel depth tool

## Description
Media header parser and audiovisual engineering utility providing Truevision TGA header color map and pixel depth tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

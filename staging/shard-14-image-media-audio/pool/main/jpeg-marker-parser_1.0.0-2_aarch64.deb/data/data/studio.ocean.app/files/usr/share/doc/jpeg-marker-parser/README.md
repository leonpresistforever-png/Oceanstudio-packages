# jpeg-marker-parser

JPEG SOF0 SOI EOI APP0 marker segment inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

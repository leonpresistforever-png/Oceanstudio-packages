# webp-vp8-chunk-view

WebP RIFF container VP8 VP8L VP8X chunk reader

## Description
Media header parser and audiovisual engineering utility providing WebP RIFF container VP8 VP8L VP8X chunk reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

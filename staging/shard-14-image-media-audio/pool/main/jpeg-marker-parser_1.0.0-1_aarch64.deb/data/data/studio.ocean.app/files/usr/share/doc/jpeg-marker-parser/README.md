# jpeg-marker-parser

JPEG SOF0 SOI EOI APP0 marker segment inspector

## Description
Media header parser and audiovisual engineering utility providing JPEG SOF0 SOI EOI APP0 marker segment inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

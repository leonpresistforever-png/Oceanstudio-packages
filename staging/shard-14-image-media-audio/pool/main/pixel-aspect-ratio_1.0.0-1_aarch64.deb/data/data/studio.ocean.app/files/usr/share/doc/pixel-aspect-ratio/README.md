# pixel-aspect-ratio

digital video pixel aspect ratio to display aspect ratio

## Description
Media header parser and audiovisual engineering utility providing digital video pixel aspect ratio to display aspect ratio for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

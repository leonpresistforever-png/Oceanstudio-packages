# audio-bitrate-sampler

constant vs variable bitrate distribution analyzer

## Description
Media header parser and audiovisual engineering utility providing constant vs variable bitrate distribution analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

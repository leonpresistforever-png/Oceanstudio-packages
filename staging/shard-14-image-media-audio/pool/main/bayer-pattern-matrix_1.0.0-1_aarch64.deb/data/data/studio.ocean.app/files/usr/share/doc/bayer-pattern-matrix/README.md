# bayer-pattern-matrix

camera raw Bayer color filter array pattern inspector

## Description
Media header parser and audiovisual engineering utility providing camera raw Bayer color filter array pattern inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

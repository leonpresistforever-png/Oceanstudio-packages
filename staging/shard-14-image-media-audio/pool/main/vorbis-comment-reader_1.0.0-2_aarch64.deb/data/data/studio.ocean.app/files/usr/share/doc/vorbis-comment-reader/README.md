# vorbis-comment-reader

Ogg Vorbis user comment vendor string field extractor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# wav-riff-chunk-dump

WAV RIFF fmt data chunk structure analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

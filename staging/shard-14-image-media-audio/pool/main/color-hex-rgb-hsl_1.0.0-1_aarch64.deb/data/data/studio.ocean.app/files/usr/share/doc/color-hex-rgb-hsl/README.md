# color-hex-rgb-hsl

color format converter HEX RGB HSL HSV CMYK

## Description
Media header parser and audiovisual engineering utility providing color format converter HEX RGB HSL HSV CMYK for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

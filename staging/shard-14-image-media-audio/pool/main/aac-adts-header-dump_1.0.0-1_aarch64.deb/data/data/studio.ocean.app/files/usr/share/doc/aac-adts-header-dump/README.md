# aac-adts-header-dump

Advanced Audio Coding ADTS synchronization header dump

## Description
Media header parser and audiovisual engineering utility providing Advanced Audio Coding ADTS synchronization header dump for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

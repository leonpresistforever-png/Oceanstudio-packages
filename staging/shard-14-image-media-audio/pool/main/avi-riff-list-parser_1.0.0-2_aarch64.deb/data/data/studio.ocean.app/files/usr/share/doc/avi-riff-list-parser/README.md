# avi-riff-list-parser

Audio Video Interleave RIFF LIST hdrl movi parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

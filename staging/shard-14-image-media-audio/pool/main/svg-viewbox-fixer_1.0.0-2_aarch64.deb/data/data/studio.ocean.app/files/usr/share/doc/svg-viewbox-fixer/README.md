# svg-viewbox-fixer

SVG viewBox width height coordinate space normalizer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

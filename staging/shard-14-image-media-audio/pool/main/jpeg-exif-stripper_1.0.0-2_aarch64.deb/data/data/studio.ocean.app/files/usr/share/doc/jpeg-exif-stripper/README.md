# jpeg-exif-stripper

JPEG Exchangeable Image File metadata remover

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# pcm-sample-rate-conv

PCM raw audio sample rate and bit depth calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

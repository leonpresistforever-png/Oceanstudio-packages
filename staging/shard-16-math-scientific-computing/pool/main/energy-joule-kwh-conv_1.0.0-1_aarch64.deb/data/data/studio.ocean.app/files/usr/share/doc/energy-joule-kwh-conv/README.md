# energy-joule-kwh-conv

Joule Watt-hour Calorie BTU energy converter

## Description
Scientific calculation and numerical algorithm engine providing Joule Watt-hour Calorie BTU energy converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

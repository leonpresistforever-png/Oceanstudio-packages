# vector-dot-cross-prod

3D vector dot product cross product and norm calculator

## Description
Scientific calculation and numerical algorithm engine providing 3D vector dot product cross product and norm calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

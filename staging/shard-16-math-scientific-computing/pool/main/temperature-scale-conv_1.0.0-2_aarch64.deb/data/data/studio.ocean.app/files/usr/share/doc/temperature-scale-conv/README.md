# temperature-scale-conv

Celsius Fahrenheit Kelvin Rankine Delisle converter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

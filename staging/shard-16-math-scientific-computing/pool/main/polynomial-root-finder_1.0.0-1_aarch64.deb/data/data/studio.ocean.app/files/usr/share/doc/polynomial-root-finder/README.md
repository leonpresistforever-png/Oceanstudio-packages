# polynomial-root-finder

polynomial synthetic division and real root finder

## Description
Scientific calculation and numerical algorithm engine providing polynomial synthetic division and real root finder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

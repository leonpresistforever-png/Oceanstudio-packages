# bigfloat-pi-chudnovsky

Chudnovsky algorithm arbitrary precision Pi generator

## Description
Scientific calculation and numerical algorithm engine providing Chudnovsky algorithm arbitrary precision Pi generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# boolean-logic-solver

boolean logic expression truth table and SAT solver

## Description
Scientific calculation and numerical algorithm engine providing boolean logic expression truth table and SAT solver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

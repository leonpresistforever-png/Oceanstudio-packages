# a-star-path-finder

A* heuristic search 2D grid pathfinding solver

## Description
Scientific calculation and numerical algorithm engine providing A* heuristic search 2D grid pathfinding solver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

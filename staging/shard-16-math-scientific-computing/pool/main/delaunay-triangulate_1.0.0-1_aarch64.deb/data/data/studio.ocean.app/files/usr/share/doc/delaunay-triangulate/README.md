# delaunay-triangulate

Bowyer-Watson 2D Delaunay triangulation tool

## Description
Scientific calculation and numerical algorithm engine providing Bowyer-Watson 2D Delaunay triangulation tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

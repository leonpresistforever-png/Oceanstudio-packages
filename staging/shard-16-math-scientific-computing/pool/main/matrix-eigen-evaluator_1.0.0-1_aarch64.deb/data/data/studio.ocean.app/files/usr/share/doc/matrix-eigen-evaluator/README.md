# matrix-eigen-evaluator

symmetric matrix eigenvalue power iteration estimator

## Description
Scientific calculation and numerical algorithm engine providing symmetric matrix eigenvalue power iteration estimator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# convex-hull-graham

Graham scan 2D point cloud convex hull calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

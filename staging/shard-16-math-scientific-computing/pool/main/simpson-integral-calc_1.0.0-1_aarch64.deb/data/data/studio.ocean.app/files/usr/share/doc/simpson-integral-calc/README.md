# simpson-integral-calc

composite Simpson numerical definite integral solver

## Description
Scientific calculation and numerical algorithm engine providing composite Simpson numerical definite integral solver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

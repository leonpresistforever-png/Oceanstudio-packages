# a-star-path-finder

A* heuristic search 2D grid pathfinding solver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# matrix-determinant-2d

2x2 and NxN matrix determinant algebraic solver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

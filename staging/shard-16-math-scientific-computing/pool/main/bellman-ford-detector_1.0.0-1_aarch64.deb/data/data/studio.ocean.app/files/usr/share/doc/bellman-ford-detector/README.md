# bellman-ford-detector

Bellman-Ford negative weight cycle detector

## Description
Scientific calculation and numerical algorithm engine providing Bellman-Ford negative weight cycle detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

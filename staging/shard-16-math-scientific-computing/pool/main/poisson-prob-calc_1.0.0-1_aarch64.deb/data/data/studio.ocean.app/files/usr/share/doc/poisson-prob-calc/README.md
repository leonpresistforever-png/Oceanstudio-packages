# poisson-prob-calc

Poisson probability mass function and interval solver

## Description
Scientific calculation and numerical algorithm engine providing Poisson probability mass function and interval solver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

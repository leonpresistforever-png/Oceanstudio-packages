# bigint-extended-gcd

Extended Euclidean algorithm Bezout identity solver

## Description
Scientific calculation and numerical algorithm engine providing Extended Euclidean algorithm Bezout identity solver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

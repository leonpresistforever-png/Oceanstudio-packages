# vector-dot-cross-prod

3D vector dot product cross product and norm calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

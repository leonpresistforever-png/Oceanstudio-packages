# binomial-distribution

binomial coefficient and Bernoulli trial calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

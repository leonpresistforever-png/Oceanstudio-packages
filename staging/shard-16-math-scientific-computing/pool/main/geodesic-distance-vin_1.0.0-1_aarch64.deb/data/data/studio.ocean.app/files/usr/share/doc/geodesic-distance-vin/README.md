# geodesic-distance-vin

Vincenty inverse geodesic ellipsoid distance tool

## Description
Scientific calculation and numerical algorithm engine providing Vincenty inverse geodesic ellipsoid distance tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

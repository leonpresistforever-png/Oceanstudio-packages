# fft-fourier-transform

Cooley-Tukey Radix-2 Fast Fourier Transform tool

## Description
Scientific calculation and numerical algorithm engine providing Cooley-Tukey Radix-2 Fast Fourier Transform tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

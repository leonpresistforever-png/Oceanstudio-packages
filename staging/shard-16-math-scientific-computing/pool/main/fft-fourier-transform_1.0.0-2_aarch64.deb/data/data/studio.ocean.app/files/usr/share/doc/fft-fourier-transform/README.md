# fft-fourier-transform

Cooley-Tukey Radix-2 Fast Fourier Transform tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

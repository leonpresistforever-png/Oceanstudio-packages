# voronoi-diagram-cli

2D planar Voronoi partition cell vertex generator

## Description
Scientific calculation and numerical algorithm engine providing 2D planar Voronoi partition cell vertex generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# jwt-signer-tool

HMAC-SHA256/384/512 JSON Web Token (JWT) creator and signer

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# pbkdf2-keygen

password-based key derivation function 2 generator

## Description
Cryptographic engine and secret management utility providing password-based key derivation function 2 generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

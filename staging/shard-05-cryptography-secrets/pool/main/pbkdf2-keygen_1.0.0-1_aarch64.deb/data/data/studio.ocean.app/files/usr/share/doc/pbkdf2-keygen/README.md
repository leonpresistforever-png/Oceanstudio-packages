# pbkdf2-keygen

PBKDF2-HMAC cryptographic key derivation utility

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# pkcs12-exporter

PKCS#12 (.p12/.pfx) archive inspector and certificate exporter

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

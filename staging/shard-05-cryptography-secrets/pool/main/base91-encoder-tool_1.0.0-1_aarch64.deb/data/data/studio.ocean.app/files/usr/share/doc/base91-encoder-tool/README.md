# base91-encoder-tool

basE91 binary-to-text encoder and decoder utility

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

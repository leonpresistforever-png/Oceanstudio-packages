# dsa-key-auditor

DSA key security auditor and deprecation checker

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

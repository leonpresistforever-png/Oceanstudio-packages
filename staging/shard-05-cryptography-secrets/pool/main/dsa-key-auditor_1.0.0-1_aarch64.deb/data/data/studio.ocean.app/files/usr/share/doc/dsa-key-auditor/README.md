# dsa-key-auditor

Digital Signature Algorithm key parameter auditor

## Description
Cryptographic engine and secret management utility providing Digital Signature Algorithm key parameter auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

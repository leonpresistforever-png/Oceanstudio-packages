# ssl-san-inspector

SSL/TLS certificate Subject Alternative Name (SAN) inspector

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

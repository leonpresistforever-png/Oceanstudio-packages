# cert-expiration-watcher

X.509 SSL/TLS certificate expiry watcher and alert utility

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# ssh-cert-checker

OpenSSH user and host certificate validator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

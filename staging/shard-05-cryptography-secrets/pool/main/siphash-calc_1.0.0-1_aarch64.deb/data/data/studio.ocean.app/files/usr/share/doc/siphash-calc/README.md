# siphash-calc

SipHash pseudo-random function against hash flooding

## Description
Cryptographic engine and secret management utility providing SipHash pseudo-random function against hash flooding for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

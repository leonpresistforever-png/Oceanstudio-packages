# pgp-packet-dump

OpenPGP (RFC 4880) binary packet parser and inspector

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# age-encryption-tool

Simple file encryption and decryption tool

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

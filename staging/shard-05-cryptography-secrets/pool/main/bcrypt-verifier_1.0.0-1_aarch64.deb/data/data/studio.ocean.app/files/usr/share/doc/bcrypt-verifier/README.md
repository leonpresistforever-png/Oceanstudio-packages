# bcrypt-verifier

Bcrypt password hash format verifier and generator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

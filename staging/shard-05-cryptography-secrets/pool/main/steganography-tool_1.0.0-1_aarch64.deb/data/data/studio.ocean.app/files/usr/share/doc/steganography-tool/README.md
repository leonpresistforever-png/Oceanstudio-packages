# steganography-tool

Least Significant Bit (LSB) image steganography encoder/decoder

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# argon2-hasher

Argon2 password hashing and verification tool

## Description
Cryptographic engine and secret management utility providing Argon2 password hashing and verification tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

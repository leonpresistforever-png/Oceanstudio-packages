# argon2-hasher

Argon2-compatible password hashing and verification utility

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

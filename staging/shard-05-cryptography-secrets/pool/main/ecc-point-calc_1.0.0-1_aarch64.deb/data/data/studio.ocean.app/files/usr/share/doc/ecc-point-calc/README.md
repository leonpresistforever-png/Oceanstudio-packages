# ecc-point-calc

elliptic curve point multiplication and math validator

## Description
Cryptographic engine and secret management utility providing elliptic curve point multiplication and math validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

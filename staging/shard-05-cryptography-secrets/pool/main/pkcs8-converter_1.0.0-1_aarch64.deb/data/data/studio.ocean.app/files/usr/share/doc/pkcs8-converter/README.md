# pkcs8-converter

PKCS#8 private key information syntax converter

## Description
Cryptographic engine and secret management utility providing PKCS#8 private key information syntax converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

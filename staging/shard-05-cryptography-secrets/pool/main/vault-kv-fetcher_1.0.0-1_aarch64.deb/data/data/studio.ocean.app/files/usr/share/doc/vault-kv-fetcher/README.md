# vault-kv-fetcher

HashiCorp Vault key-value secrets retrieval client

## Description
Cryptographic engine and secret management utility providing HashiCorp Vault key-value secrets retrieval client for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

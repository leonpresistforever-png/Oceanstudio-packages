# vault-kv-fetcher

HashiCorp Vault KV secret retrieval client CLI

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

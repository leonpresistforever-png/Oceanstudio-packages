# paseto-token-tool

Platform-Agnostic Security Tokens (PASETO) parser and builder

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

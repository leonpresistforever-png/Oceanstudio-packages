# tls-cipher-scanner

TLS endpoint supported ciphers and protocol versions scanner

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# x509-csr-builder

X.509 Certificate Signing Request (CSR) generator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

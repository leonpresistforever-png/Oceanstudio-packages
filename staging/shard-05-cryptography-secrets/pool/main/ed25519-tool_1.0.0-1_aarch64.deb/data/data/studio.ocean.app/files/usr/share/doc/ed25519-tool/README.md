# ed25519-tool

Ed25519 elliptic curve signature key and verify tool

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

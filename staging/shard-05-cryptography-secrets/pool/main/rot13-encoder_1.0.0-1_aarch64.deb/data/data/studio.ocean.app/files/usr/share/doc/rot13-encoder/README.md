# rot13-encoder

Caesar ROT13 alphabetic transposition filter

## Description
Cryptographic engine and secret management utility providing Caesar ROT13 alphabetic transposition filter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

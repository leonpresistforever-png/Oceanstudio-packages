# rsa-key-parser

RSA public and private key structure parser and viewer

## Description
Cryptographic engine and secret management utility providing RSA public and private key structure parser and viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

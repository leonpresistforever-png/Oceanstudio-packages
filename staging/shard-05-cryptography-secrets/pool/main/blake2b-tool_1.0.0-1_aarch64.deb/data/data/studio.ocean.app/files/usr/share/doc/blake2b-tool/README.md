# blake2b-tool

BLAKE2b hasher with custom digest length and keying

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

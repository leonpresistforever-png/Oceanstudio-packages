# der-asn1-dump

DER encoded ASN.1 structure visualizer and linter

## Description
Cryptographic engine and secret management utility providing DER encoded ASN.1 structure visualizer and linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

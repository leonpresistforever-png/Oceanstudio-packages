# hotp-generator

HMAC-based one-time password generator

## Description
Cryptographic engine and secret management utility providing HMAC-based one-time password generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

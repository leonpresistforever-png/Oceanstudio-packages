# shamir-secret-sharer

Shamir Secret Sharing threshold secret splitter and reconstructor

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# aes-gcm-tool

AES Galois/Counter Mode authenticated encryptor

## Description
Cryptographic engine and secret management utility providing AES Galois/Counter Mode authenticated encryptor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

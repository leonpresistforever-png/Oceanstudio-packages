# base45-qr-decoder

Base45 barcode and health certificate data decoder

## Description
Cryptographic engine and secret management utility providing Base45 barcode and health certificate data decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# base45-qr-decoder

RFC 9285 Base45 encoder and decoder for QR codes

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

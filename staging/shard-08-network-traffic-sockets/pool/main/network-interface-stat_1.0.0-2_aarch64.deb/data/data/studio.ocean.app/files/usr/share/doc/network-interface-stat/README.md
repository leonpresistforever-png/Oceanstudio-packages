# network-interface-stat

network interface rx/tx packets and error counter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

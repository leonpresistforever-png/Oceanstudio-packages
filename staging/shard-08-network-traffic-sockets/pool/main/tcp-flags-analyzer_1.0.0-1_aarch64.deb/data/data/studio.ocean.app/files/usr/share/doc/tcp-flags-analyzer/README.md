# tcp-flags-analyzer

TCP SYN ACK FIN RST window scaling options parser

## Description
Low-level network protocol and socket diagnostics utility providing TCP SYN ACK FIN RST window scaling options parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

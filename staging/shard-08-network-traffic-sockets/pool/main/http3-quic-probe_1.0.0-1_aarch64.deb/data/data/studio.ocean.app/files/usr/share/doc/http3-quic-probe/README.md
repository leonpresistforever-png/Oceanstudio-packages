# http3-quic-probe

HTTP/3 and QUIC UDP transport handshake detector

## Description
Low-level network protocol and socket diagnostics utility providing HTTP/3 and QUIC UDP transport handshake detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

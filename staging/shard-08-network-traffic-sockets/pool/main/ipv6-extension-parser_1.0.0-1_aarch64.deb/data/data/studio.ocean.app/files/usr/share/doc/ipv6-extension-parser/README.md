# ipv6-extension-parser

IPv6 extension header chain and hop-by-hop decoder

## Description
Low-level network protocol and socket diagnostics utility providing IPv6 extension header chain and hop-by-hop decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

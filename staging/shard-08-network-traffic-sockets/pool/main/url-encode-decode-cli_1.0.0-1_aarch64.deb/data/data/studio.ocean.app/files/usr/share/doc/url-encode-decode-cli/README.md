# url-encode-decode-cli

RFC 3986 percent-encoding and decoding CLI tool

## Description
Low-level network protocol and socket diagnostics utility providing RFC 3986 percent-encoding and decoding CLI tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

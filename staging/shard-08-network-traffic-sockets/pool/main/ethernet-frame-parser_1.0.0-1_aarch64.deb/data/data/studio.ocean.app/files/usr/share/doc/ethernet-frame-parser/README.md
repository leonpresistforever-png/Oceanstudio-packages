# ethernet-frame-parser

Layer 2 Ethernet frame IEEE 802.3 and 802.1Q parser

## Description
Low-level network protocol and socket diagnostics utility providing Layer 2 Ethernet frame IEEE 802.3 and 802.1Q parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

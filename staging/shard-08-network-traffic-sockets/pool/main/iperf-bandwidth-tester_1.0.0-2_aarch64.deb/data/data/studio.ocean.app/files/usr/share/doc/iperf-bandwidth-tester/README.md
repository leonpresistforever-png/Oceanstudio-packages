# iperf-bandwidth-tester

TCP and UDP throughput and bandwidth rate benchmark

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dns-txt-record-fetcher

DNS TXT record string concatenation and parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

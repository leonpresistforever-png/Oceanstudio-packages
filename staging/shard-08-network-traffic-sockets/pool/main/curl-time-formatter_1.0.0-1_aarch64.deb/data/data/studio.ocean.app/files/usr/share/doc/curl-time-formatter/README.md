# curl-time-formatter

cURL timing breakdown DNS connect TLS and TTFB parser

## Description
Low-level network protocol and socket diagnostics utility providing cURL timing breakdown DNS connect TLS and TTFB parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# tcp-port-sweeper

fast sequential TCP port range accessibility scanner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dns-mx-priority-sorter

Mail Exchanger DNS record preference validator

## Description
Low-level network protocol and socket diagnostics utility providing Mail Exchanger DNS record preference validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

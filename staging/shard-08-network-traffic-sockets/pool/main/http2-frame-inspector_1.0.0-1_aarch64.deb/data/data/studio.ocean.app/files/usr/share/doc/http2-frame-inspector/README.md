# http2-frame-inspector

HTTP/2 binary framing layer and settings frame parser

## Description
Low-level network protocol and socket diagnostics utility providing HTTP/2 binary framing layer and settings frame parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

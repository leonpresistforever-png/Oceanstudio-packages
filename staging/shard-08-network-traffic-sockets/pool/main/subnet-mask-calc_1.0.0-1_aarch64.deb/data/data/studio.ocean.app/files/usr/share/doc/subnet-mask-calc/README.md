# subnet-mask-calc

IPv4 and IPv6 subnet mask network and broadcast calc

## Description
Low-level network protocol and socket diagnostics utility providing IPv4 and IPv6 subnet mask network and broadcast calc for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

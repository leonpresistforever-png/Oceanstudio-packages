# ping-jitter-analyzer

network packet jitter and inter-arrival variation tool

## Description
Low-level network protocol and socket diagnostics utility providing network packet jitter and inter-arrival variation tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

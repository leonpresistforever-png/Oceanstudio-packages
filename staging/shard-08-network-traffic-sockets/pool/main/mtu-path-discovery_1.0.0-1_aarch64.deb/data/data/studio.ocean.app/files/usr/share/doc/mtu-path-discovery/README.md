# mtu-path-discovery

Path MTU discovery and packet fragmentation tester

## Description
Low-level network protocol and socket diagnostics utility providing Path MTU discovery and packet fragmentation tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

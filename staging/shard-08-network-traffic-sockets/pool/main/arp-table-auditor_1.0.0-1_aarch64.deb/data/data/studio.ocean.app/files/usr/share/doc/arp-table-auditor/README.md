# arp-table-auditor

Address Resolution Protocol neighbor cache auditor

## Description
Low-level network protocol and socket diagnostics utility providing Address Resolution Protocol neighbor cache auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

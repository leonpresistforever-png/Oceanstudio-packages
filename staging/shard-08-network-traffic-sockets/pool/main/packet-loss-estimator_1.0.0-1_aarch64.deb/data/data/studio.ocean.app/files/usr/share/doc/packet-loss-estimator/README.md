# packet-loss-estimator

network transmission loss and retransmission rate

## Description
Low-level network protocol and socket diagnostics utility providing network transmission loss and retransmission rate for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

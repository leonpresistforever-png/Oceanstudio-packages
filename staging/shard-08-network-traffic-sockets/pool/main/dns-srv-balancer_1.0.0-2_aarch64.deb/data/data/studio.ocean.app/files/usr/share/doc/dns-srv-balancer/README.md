# dns-srv-balancer

DNS Service Location port weight and priority parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ping-jitter-analyzer

network packet jitter and inter-arrival variation tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# udp-port-tester

UDP service reachability and ICMP port unreachable test

## Description
Low-level network protocol and socket diagnostics utility providing UDP service reachability and ICMP port unreachable test for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# ip-range-expander

IP CIDR notation to sequential IP list generator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# bgp-asn-lookup

Autonomous System Number route prefix lookup tool

## Description
Low-level network protocol and socket diagnostics utility providing Autonomous System Number route prefix lookup tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

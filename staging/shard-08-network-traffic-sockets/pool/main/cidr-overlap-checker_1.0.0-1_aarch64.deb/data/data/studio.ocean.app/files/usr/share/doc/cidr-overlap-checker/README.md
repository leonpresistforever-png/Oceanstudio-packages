# cidr-overlap-checker

IP route CIDR prefix overlap and containment detector

## Description
Low-level network protocol and socket diagnostics utility providing IP route CIDR prefix overlap and containment detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

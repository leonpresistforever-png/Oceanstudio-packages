# dns-nsec3-walker

DNSSEC NSEC3 authenticated denial of existence auditor

## Description
Low-level network protocol and socket diagnostics utility providing DNSSEC NSEC3 authenticated denial of existence auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

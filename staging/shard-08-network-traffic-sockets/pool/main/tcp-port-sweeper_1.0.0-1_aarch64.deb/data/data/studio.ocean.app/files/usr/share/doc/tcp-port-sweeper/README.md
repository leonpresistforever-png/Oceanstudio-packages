# tcp-port-sweeper

fast sequential TCP port range accessibility scanner

## Description
Low-level network protocol and socket diagnostics utility providing fast sequential TCP port range accessibility scanner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

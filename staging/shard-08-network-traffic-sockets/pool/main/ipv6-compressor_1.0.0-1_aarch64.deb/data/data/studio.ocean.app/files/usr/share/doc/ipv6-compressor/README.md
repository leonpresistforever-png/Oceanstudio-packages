# ipv6-compressor

IPv6 zero-compression and canonical RFC 5952 formatter

## Description
Low-level network protocol and socket diagnostics utility providing IPv6 zero-compression and canonical RFC 5952 formatter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

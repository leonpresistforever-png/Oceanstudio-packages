# dns-ptr-reverse-resolver

reverse DNS in-addr.arpa pointer record resolver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# hdr-histogram-log-view

HdrHistogram encoded log file summary and quantiles

## Description
Performance profiling and microbenchmark utility providing HdrHistogram encoded log file summary and quantiles for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

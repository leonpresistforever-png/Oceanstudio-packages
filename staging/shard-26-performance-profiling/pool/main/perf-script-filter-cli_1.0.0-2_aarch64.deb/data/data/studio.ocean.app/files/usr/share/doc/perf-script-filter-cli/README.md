# perf-script-filter-cli

perf script trace output stack frame symbol filter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

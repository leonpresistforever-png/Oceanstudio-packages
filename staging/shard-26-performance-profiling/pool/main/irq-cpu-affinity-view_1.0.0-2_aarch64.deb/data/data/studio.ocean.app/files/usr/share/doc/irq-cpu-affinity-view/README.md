# irq-cpu-affinity-view

hardware interrupt CPU affinity smp_affinity viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

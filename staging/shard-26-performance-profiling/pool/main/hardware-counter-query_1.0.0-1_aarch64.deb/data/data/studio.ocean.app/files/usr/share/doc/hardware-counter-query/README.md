# hardware-counter-query

ARM64 PMU hardware performance monitor counter query

## Description
Performance profiling and microbenchmark utility providing ARM64 PMU hardware performance monitor counter query for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

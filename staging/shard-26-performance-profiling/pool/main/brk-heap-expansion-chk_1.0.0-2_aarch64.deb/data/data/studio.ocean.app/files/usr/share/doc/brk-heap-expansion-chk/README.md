# brk-heap-expansion-chk

process heap boundary sbrk expansion history monitor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

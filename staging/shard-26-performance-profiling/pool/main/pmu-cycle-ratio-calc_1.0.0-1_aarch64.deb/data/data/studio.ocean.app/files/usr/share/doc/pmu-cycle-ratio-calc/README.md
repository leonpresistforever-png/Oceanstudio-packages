# pmu-cycle-ratio-calc

CPU cycles to instructions executed ratio calculator

## Description
Performance profiling and microbenchmark utility providing CPU cycles to instructions executed ratio calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# cpu-cache-line-bouncing

false sharing cache line bounce heuristic detector

## Description
Performance profiling and microbenchmark utility providing false sharing cache line bounce heuristic detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

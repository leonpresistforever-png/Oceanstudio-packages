# percentile-p90-p99-p999

exact P50 P90 P95 P99 P99.9 percentile calculator

## Description
Performance profiling and microbenchmark utility providing exact P50 P90 P95 P99 P99.9 percentile calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

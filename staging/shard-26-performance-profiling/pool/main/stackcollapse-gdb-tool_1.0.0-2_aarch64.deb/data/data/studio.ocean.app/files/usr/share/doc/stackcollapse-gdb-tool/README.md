# stackcollapse-gdb-tool

GDB thread backtraces to collapsed call stack format

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

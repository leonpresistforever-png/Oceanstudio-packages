# simd-vector-width-probe

ARM64 NEON and SVE SIMD vector register width probe

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

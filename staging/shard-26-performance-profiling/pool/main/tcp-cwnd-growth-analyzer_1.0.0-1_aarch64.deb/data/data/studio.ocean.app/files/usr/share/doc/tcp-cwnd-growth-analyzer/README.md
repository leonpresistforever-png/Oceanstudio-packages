# tcp-cwnd-growth-analyzer

TCP congestion window slow-start threshold analyzer

## Description
Performance profiling and microbenchmark utility providing TCP congestion window slow-start threshold analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

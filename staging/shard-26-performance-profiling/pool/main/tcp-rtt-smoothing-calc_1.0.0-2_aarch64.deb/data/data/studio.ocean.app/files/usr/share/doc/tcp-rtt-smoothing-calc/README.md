# tcp-rtt-smoothing-calc

TCP Round-Trip Time SRTT variance Jacobson algorithm

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

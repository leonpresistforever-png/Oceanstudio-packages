# cpu-throttle-detector

CPU thermal and power throttling clock drops detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# thermal-governor-latency

thermal cooling device state change transition timer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

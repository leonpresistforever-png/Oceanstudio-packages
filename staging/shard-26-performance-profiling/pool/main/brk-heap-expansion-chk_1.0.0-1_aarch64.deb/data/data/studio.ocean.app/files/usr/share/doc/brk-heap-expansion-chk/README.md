# brk-heap-expansion-chk

process heap boundary sbrk expansion history monitor

## Description
Performance profiling and microbenchmark utility providing process heap boundary sbrk expansion history monitor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

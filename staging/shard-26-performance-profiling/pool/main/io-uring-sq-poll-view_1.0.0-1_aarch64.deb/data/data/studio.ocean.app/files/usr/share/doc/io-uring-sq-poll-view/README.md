# io-uring-sq-poll-view

io_uring submission queue polling kernel thread view

## Description
Performance profiling and microbenchmark utility providing io_uring submission queue polling kernel thread view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

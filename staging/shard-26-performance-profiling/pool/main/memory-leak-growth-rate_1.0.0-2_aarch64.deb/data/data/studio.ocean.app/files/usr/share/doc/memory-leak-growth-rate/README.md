# memory-leak-growth-rate

linear regression heap memory slope leak estimator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

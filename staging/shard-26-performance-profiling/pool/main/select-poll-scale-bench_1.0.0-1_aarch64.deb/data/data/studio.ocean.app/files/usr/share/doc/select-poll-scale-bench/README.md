# select-poll-scale-bench

POSIX select and poll descriptor scalability tester

## Description
Performance profiling and microbenchmark utility providing POSIX select and poll descriptor scalability tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

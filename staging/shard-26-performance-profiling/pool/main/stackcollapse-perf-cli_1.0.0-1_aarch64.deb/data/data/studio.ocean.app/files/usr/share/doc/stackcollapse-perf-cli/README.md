# stackcollapse-perf-cli

perf script output to single-line collapsed format

## Description
Performance profiling and microbenchmark utility providing perf script output to single-line collapsed format for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# buffer-copy-throughput

memcpy throughput benchmark across various buffer sizes

## Description
Performance profiling and microbenchmark utility providing memcpy throughput benchmark across various buffer sizes for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

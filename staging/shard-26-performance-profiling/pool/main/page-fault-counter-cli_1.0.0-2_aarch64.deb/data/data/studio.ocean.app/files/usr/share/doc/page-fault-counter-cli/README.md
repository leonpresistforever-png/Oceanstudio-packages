# page-fault-counter-cli

minor and major page fault occurrence rate counter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

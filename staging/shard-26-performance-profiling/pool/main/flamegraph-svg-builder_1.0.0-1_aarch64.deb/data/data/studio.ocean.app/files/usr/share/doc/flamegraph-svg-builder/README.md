# flamegraph-svg-builder

collapsed stack traces to interactive SVG Flame Graph

## Description
Performance profiling and microbenchmark utility providing collapsed stack traces to interactive SVG Flame Graph for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

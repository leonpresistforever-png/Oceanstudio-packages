# resident-set-growth-chk

process RSS resident set size growth velocity tool

## Description
Performance profiling and microbenchmark utility providing process RSS resident set size growth velocity tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

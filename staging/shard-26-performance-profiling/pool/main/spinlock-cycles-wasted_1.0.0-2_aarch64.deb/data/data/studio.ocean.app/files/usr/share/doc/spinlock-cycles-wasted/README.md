# spinlock-cycles-wasted

userspace spinlock CPU pause instruction cycles spent

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

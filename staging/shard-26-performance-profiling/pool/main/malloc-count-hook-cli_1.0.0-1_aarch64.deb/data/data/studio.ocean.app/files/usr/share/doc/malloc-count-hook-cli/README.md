# malloc-count-hook-cli

heap allocation call frequency and size distributor

## Description
Performance profiling and microbenchmark utility providing heap allocation call frequency and size distributor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

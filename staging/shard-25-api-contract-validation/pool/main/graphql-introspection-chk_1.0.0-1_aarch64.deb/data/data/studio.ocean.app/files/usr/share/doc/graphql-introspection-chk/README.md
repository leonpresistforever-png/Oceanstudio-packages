# graphql-introspection-chk

GraphQL __schema introspection query response analyzer

## Description
API schema validation and protocol contract engine providing GraphQL __schema introspection query response analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

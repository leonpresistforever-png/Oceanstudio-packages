# oauth2-token-exchange

RFC 8693 OAuth 2.0 Token Exchange request validator

## Description
API schema validation and protocol contract engine providing RFC 8693 OAuth 2.0 Token Exchange request validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# graphql-introspection-chk

GraphQL __schema introspection query response analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

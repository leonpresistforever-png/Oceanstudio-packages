# cache-control-validator

HTTP Cache-Control max-age must-revalidate analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

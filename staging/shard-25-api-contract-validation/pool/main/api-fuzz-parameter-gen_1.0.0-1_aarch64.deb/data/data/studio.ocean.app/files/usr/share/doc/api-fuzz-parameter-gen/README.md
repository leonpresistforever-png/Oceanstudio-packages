# api-fuzz-parameter-gen

API schema parameter boundary edge-case test generator

## Description
API schema validation and protocol contract engine providing API schema parameter boundary edge-case test generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

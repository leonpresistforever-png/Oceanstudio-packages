# protobuf-field-number-chk

Protobuf field tag numbers 1 to 536870911 validator

## Description
API schema validation and protocol contract engine providing Protobuf field tag numbers 1 to 536870911 validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

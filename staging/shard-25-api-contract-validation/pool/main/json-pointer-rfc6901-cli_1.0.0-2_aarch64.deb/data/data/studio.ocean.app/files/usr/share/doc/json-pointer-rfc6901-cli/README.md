# json-pointer-rfc6901-cli

RFC 6901 JSON Pointer path evaluation and lookup tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

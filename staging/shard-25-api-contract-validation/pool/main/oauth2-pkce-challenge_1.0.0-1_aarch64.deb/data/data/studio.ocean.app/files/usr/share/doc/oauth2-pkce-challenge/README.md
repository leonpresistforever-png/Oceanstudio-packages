# oauth2-pkce-challenge

RFC 7636 Proof Key for Code Exchange SHA256 builder

## Description
API schema validation and protocol contract engine providing RFC 7636 Proof Key for Code Exchange SHA256 builder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

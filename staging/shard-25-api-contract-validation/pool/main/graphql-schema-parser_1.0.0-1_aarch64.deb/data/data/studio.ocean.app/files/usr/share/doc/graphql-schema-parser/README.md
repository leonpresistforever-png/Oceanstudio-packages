# graphql-schema-parser

GraphQL Schema Definition Language SDL type parser

## Description
API schema validation and protocol contract engine providing GraphQL Schema Definition Language SDL type parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

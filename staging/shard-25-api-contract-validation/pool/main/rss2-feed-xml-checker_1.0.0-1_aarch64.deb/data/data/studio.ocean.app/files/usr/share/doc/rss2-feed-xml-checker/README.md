# rss2-feed-xml-checker

RSS 2.0 XML specification feed validator and linter

## Description
API schema validation and protocol contract engine providing RSS 2.0 XML specification feed validator and linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

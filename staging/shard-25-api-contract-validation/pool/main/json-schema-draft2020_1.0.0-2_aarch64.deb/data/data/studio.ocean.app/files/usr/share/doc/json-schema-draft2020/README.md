# json-schema-draft2020

JSON Schema Draft 2020-12 dialect validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

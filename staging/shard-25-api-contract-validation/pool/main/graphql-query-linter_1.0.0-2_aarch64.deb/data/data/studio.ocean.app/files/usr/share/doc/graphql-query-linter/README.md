# graphql-query-linter

GraphQL query operation field selection and depth linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

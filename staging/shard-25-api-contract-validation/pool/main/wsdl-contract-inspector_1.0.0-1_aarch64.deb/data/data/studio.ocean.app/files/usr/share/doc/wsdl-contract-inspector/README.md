# wsdl-contract-inspector

Web Services Description Language WSDL 1.1 inspector

## Description
API schema validation and protocol contract engine providing Web Services Description Language WSDL 1.1 inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

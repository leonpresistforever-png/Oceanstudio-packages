# permissions-policy-fmt

Permissions-Policy structured header syntax formatter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# oidc-discovery-parser

OpenID Connect .well-known/openid-configuration tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

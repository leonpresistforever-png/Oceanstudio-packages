# swagger-v2-converter

Swagger 2.0 to OpenAPI 3.0 upgrade compatibility checker

## Description
API schema validation and protocol contract engine providing Swagger 2.0 to OpenAPI 3.0 upgrade compatibility checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

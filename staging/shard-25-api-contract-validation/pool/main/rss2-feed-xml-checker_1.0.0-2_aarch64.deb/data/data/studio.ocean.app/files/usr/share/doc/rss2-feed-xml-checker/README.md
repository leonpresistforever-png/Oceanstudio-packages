# rss2-feed-xml-checker

RSS 2.0 XML specification feed validator and linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# openapi-v3-spec-linter

OpenAPI Specification 3.0/3.1 document structure linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

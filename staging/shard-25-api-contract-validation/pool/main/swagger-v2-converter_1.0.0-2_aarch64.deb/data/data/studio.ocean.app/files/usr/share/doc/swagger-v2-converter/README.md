# swagger-v2-converter

Swagger 2.0 to OpenAPI 3.0 upgrade compatibility checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# api-curl-command-gen

OpenAPI endpoint operation to executable cURL command

## Description
API schema validation and protocol contract engine providing OpenAPI endpoint operation to executable cURL command for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

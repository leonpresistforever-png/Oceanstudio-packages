# cross-origin-resource

Cross-Origin Resource Policy CORP header validator

## Description
API schema validation and protocol contract engine providing Cross-Origin Resource Policy CORP header validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

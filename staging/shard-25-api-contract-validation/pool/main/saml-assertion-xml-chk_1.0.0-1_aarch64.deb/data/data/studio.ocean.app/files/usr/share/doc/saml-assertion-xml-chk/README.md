# saml-assertion-xml-chk

Security Assertion Markup Language SAML 2.0 validator

## Description
API schema validation and protocol contract engine providing Security Assertion Markup Language SAML 2.0 validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

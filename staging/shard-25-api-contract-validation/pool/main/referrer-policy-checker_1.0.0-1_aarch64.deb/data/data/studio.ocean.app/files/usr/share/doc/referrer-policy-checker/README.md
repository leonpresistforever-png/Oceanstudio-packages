# referrer-policy-checker

Referrer-Policy header origin and privacy validator

## Description
API schema validation and protocol contract engine providing Referrer-Policy header origin and privacy validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

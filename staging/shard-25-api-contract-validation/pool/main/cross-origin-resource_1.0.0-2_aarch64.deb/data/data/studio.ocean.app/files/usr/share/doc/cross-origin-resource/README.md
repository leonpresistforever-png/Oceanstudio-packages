# cross-origin-resource

Cross-Origin Resource Policy CORP header validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

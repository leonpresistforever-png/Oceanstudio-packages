# referrer-policy-checker

Referrer-Policy header origin and privacy validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# json-feed-validator-cli

JSON Feed Version 1.1 schema and item validator

## Description
API schema validation and protocol contract engine providing JSON Feed Version 1.1 schema and item validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

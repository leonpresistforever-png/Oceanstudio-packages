# cross-origin-embedder

Cross-Origin Embedder Policy COEP header validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

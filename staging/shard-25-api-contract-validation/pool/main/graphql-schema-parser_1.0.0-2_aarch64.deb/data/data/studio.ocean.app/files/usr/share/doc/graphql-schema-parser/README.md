# graphql-schema-parser

GraphQL Schema Definition Language SDL type parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

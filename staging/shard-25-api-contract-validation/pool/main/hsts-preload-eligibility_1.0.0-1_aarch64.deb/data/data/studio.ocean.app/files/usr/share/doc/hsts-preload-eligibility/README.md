# hsts-preload-eligibility

HTTP Strict Transport Security HSTS preload criteria

## Description
API schema validation and protocol contract engine providing HTTP Strict Transport Security HSTS preload criteria for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

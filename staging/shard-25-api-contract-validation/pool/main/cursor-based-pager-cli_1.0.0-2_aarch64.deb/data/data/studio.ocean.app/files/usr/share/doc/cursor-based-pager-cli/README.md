# cursor-based-pager-cli

opaque base64 cursor pagination token generator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

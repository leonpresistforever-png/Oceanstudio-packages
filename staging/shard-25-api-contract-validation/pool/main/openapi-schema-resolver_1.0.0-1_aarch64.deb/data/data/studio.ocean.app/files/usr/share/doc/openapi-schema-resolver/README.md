# openapi-schema-resolver

OpenAPI $ref JSON pointer component schema resolver

## Description
API schema validation and protocol contract engine providing OpenAPI $ref JSON pointer component schema resolver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# atom-feed-xml-validator

RFC 4287 Atom Syndication Format XML feed validator

## Description
API schema validation and protocol contract engine providing RFC 4287 Atom Syndication Format XML feed validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

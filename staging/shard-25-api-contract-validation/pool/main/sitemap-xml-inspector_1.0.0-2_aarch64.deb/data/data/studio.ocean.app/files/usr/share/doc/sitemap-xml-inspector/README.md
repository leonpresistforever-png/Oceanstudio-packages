# sitemap-xml-inspector

XML Sitemap 0.9 urlset and sitemapindex validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

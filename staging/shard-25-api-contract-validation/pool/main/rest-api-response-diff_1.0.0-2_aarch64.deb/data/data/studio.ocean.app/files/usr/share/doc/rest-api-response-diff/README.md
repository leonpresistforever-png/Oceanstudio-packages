# rest-api-response-diff

REST API response payload breaking change detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# pagination-link-header

RFC 8288 Link header rel=next rel=prev parser

## Description
API schema validation and protocol contract engine providing RFC 8288 Link header rel=next rel=prev parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

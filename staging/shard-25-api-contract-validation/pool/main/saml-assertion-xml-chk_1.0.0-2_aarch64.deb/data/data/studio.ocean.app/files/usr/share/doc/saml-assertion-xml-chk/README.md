# saml-assertion-xml-chk

Security Assertion Markup Language SAML 2.0 validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

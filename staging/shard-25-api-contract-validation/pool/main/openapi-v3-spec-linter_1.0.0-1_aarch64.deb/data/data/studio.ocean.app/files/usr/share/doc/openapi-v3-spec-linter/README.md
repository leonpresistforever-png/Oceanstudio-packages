# openapi-v3-spec-linter

OpenAPI Specification 3.0/3.1 document structure linter

## Description
API schema validation and protocol contract engine providing OpenAPI Specification 3.0/3.1 document structure linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

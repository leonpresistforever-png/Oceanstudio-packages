# wsdl-contract-inspector

Web Services Description Language WSDL 1.1 inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

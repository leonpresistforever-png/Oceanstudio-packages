# json-pointer-rfc6901-cli

RFC 6901 JSON Pointer path evaluation and lookup tool

## Description
API schema validation and protocol contract engine providing RFC 6901 JSON Pointer path evaluation and lookup tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

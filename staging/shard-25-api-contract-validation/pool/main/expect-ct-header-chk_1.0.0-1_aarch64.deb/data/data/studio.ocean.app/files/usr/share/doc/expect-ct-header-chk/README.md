# expect-ct-header-chk

Expect-CT Certificate Transparency enforcement checker

## Description
API schema validation and protocol contract engine providing Expect-CT Certificate Transparency enforcement checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

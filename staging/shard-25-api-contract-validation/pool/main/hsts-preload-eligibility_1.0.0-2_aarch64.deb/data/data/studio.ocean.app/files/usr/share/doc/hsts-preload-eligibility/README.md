# hsts-preload-eligibility

HTTP Strict Transport Security HSTS preload criteria

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

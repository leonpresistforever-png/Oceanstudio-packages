# http-auth-bearer-token

RFC 6750 OAuth 2.0 Bearer Token authorization validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

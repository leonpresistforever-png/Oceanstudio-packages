# hmac-webhook-verifier

webhook request payload SHA256 HMAC verification cli

## Description
API schema validation and protocol contract engine providing webhook request payload SHA256 HMAC verification cli for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# protobuf-reserved-ranges

Protobuf reserved tag numbers and names conflict audit

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

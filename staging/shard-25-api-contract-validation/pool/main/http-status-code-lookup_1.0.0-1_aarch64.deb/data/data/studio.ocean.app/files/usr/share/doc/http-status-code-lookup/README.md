# http-status-code-lookup

IANA HTTP status code registry reference and semantics

## Description
API schema validation and protocol contract engine providing IANA HTTP status code registry reference and semantics for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

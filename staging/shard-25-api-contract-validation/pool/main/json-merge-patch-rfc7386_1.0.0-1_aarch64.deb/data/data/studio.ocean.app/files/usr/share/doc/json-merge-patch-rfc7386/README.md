# json-merge-patch-rfc7386

RFC 7386 JSON Merge Patch document reconciler

## Description
API schema validation and protocol contract engine providing RFC 7386 JSON Merge Patch document reconciler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

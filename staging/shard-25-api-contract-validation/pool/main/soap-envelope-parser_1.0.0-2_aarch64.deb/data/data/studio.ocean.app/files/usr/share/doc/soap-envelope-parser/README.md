# soap-envelope-parser

Simple Object Access Protocol SOAP 1.1/1.2 XML parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

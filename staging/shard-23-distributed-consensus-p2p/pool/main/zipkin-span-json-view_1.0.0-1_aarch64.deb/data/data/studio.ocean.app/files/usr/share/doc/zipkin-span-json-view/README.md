# zipkin-span-json-view

Zipkin v2 HTTP span duration and annotation reader

## Description
Distributed systems consensus and P2P protocol utility providing Zipkin v2 HTTP span duration and annotation reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

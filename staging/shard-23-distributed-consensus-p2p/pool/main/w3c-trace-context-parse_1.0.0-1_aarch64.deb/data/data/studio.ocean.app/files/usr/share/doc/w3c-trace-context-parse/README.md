# w3c-trace-context-parse

W3C traceparent and tracestate header parser

## Description
Distributed systems consensus and P2P protocol utility providing W3C traceparent and tracestate header parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# crdt-or-set-resolver

Observed-Remove Set CRDT element convergence tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dht-kademlia-routing

Kademlia Distributed Hash Table k-bucket router

## Description
Distributed systems consensus and P2P protocol utility providing Kademlia Distributed Hash Table k-bucket router for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

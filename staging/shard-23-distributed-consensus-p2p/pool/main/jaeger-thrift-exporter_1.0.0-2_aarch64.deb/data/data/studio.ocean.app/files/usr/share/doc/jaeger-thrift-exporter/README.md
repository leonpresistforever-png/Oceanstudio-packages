# jaeger-thrift-exporter

Jaeger span JSON to compact model serializer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

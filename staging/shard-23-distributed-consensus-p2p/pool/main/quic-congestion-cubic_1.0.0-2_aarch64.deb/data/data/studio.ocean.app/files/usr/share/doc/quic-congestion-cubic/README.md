# quic-congestion-cubic

TCP/QUIC CUBIC congestion window growth simulator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

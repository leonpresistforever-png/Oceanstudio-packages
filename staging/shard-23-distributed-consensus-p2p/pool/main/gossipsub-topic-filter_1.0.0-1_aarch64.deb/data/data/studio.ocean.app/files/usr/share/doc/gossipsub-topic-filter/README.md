# gossipsub-topic-filter

libp2p GossipSub v1.1 mesh topic scoring analyzer

## Description
Distributed systems consensus and P2P protocol utility providing libp2p GossipSub v1.1 mesh topic scoring analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

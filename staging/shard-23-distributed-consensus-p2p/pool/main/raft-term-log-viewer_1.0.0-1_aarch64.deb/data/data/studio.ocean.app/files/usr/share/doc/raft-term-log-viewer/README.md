# raft-term-log-viewer

Raft consensus protocol state machine log entry reader

## Description
Distributed systems consensus and P2P protocol utility providing Raft consensus protocol state machine log entry reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

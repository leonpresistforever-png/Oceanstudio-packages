# bbr-bandwidth-estimator

Bottleneck Bandwidth and RTT BBR model evaluator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

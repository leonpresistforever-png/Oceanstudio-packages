# b3-trace-header-inject

Zipkin B3 propagation traceId spanId injector

## Description
Distributed systems consensus and P2P protocol utility providing Zipkin B3 propagation traceId spanId injector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

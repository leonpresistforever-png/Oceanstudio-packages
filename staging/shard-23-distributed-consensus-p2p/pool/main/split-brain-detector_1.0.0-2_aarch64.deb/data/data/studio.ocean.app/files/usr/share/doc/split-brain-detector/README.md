# split-brain-detector

cluster network partition split-brain risk detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

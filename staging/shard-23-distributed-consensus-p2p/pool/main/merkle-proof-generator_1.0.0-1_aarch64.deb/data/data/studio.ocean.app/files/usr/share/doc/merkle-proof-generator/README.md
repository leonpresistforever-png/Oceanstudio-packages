# merkle-proof-generator

Merkle inclusion proof path generator and verifier

## Description
Distributed systems consensus and P2P protocol utility providing Merkle inclusion proof path generator and verifier for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# ipni-network-indexer

InterPlanetary Network Indexer advertisement tool

## Description
Distributed systems consensus and P2P protocol utility providing InterPlanetary Network Indexer advertisement tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# p2p-bit-torrent-bencode

BitTorrent Bencode dictionary and list decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# torrent-piece-hash-chk

BitTorrent 20-byte SHA-1 piece hash validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

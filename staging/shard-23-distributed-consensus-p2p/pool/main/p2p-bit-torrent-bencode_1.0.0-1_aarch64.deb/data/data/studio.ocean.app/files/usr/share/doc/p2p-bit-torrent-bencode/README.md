# p2p-bit-torrent-bencode

BitTorrent Bencode dictionary and list decoder

## Description
Distributed systems consensus and P2P protocol utility providing BitTorrent Bencode dictionary and list decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

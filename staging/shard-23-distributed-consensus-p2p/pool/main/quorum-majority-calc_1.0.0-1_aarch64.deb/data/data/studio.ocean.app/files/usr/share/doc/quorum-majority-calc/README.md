# quorum-majority-calc

N-node cluster Byzantine and crash fault quorums

## Description
Distributed systems consensus and P2P protocol utility providing N-node cluster Byzantine and crash fault quorums for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

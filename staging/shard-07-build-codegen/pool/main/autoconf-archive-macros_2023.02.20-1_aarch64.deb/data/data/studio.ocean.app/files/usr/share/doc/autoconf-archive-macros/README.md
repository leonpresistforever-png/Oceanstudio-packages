# autoconf-archive-macros

reusable M4 macros for GNU Autoconf

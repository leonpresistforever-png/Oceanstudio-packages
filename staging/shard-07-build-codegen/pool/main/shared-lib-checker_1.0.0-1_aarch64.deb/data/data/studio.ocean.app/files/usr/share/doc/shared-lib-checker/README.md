# shared-lib-checker

verify NEEDED libraries and soname consistency

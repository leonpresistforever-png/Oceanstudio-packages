# shellcheck-runner

shell script linter and static analysis launcher

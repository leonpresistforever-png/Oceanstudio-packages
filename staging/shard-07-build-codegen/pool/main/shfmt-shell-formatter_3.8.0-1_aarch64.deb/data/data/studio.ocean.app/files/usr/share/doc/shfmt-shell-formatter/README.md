# shfmt-shell-formatter

format shell script programs consistently

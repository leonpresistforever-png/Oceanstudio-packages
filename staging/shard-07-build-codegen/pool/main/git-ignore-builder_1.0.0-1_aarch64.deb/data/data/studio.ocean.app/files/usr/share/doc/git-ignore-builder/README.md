# git-ignore-builder

generate language-specific .gitignore rules

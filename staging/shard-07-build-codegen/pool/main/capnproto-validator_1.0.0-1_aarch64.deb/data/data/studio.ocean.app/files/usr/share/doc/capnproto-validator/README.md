# capnproto-validator

validate Cap'n Proto schema definition files

# makefile-grapher

visualize Makefile dependency targets as DAG graph

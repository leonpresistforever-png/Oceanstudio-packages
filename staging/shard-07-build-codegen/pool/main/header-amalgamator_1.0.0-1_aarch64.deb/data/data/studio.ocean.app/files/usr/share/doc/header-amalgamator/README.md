# header-amalgamator

combine internal header files into public API header

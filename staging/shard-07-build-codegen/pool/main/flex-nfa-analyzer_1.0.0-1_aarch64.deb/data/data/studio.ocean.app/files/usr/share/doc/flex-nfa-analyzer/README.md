# flex-nfa-analyzer

analyze NFA/DFA transition tables from Flex lexer

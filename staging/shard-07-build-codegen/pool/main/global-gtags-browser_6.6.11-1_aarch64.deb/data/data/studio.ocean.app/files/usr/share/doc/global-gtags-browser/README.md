# global-gtags-browser

GNU source code tag system for large projects

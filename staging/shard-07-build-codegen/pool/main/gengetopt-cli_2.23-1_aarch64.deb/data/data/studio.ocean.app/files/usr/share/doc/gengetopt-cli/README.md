# gengetopt-cli

command line option parser generator for C

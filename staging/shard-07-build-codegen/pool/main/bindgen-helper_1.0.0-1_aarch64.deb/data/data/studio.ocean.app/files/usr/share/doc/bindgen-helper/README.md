# bindgen-helper

helper utilities for C header binding generation

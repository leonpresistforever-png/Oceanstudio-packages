# gperf-hash-gen

perfect hash function generator for key sets

# source-tarball-gen

generate clean source tarballs without VCS metadata

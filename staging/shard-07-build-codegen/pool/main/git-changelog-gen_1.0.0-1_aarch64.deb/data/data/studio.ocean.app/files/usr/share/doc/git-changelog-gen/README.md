# git-changelog-gen

generate changelog from conventional git commits

# semver-tool

semantic version string comparison and bumper CLI

# elf-section-stripper

strip debug symbols and comments from ELF binaries

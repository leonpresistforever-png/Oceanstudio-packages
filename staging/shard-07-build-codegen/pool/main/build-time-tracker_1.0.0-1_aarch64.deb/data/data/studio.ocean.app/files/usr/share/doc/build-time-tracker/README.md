# build-time-tracker

track and record execution time of compilation stages

# patch-inliner

inline multi-file patches into unified distribution diff

# c-header-guard-gen

generate unique UUID-based C/C++ header guards

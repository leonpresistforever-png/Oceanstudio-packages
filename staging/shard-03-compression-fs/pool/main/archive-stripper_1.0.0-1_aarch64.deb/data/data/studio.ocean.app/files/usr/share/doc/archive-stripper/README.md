# archive-stripper

strip non-essential files from archives before storage

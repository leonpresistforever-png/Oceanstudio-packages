# lz4-extreme

LZ4 extreme compression level utility

# cpio-portable

GNU cpio archive manipulation utility

# sharutils-unshar

unpack shell archives created with shar

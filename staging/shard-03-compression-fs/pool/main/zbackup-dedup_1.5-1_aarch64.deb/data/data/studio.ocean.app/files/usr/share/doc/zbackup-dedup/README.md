# zbackup-dedup

deduplicating backup tool using rsync rolling hash

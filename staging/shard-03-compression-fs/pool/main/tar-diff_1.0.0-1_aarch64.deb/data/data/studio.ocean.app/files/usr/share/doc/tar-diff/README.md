# tar-diff

compare contents of two tar archives without extracting

# symlink-auditor

audit broken or escaping symbolic links in path

# split-merger

split and merge large files with checksum integrity

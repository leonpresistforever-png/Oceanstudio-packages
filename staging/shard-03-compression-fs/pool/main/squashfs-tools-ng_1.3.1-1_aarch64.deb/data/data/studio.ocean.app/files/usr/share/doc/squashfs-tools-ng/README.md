# squashfs-tools-ng

new generation tools for working with SquashFS

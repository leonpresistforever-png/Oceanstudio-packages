# sparse-img-tools

Android sparse image inspect and unsparse tool

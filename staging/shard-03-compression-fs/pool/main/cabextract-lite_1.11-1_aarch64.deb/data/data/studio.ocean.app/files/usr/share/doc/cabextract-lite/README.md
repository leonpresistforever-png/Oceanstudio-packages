# cabextract-lite

extract Microsoft Cabinet archives

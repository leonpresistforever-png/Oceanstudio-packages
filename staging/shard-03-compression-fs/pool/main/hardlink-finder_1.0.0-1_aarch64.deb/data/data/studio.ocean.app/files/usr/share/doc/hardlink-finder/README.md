# hardlink-finder

find and group identical files by inode hardlinks

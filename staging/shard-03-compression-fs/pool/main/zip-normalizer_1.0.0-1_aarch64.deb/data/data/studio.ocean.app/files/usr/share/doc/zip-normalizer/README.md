# zip-normalizer

repack zip files with deterministic timestamps

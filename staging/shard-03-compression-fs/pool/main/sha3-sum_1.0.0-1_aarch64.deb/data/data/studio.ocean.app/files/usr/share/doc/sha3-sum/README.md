# sha3-sum

calculate SHA3-256 and SHA3-512 hashes

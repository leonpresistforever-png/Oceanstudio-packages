# lzop-fast

extremely fast LZO compression utility

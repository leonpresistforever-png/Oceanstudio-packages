# gz-indexer

index gzip streams for random access decompression

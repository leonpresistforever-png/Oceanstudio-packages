# adler32-tool

calculate Adler32 checksums for zlib validation

# du-visualizer

visualize disk usage bar charts in terminal

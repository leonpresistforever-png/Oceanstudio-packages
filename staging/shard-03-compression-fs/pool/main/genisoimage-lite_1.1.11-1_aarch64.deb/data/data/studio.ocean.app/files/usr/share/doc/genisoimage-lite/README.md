# genisoimage-lite

generate ISO9660 CD-ROM filesystem images

# tar-normalizer

repack tar archives with root ownership and 1970 mtime

# xxhash-cli

extremely fast non-cryptographic hash algorithm CLI

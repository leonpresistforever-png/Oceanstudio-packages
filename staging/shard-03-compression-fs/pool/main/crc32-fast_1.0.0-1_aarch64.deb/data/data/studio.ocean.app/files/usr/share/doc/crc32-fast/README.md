# crc32-fast

hardware-accelerated CRC32 calculation tool

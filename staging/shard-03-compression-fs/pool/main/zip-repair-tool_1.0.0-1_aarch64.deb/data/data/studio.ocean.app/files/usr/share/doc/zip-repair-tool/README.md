# zip-repair-tool

diagnose and repair damaged ZIP archives

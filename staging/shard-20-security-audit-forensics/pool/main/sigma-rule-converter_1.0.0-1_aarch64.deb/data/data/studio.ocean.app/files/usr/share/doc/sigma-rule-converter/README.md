# sigma-rule-converter

Sigma generic log signature format syntax validator

## Description
Security forensic analysis and incident response tool providing Sigma generic log signature format syntax validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

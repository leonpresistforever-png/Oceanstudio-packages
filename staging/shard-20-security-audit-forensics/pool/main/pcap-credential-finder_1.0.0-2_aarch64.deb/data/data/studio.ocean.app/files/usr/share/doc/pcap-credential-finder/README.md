# pcap-credential-finder

cleartext credential detector in network capture files

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

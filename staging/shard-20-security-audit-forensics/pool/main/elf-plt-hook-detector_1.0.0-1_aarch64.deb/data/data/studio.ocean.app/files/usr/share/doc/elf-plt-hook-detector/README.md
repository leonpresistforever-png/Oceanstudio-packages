# elf-plt-hook-detector

Procedure Linkage Table redirection hook detector

## Description
Security forensic analysis and incident response tool providing Procedure Linkage Table redirection hook detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

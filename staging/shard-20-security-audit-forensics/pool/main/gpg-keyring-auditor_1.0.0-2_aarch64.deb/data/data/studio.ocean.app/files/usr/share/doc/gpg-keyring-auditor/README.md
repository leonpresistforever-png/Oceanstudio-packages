# gpg-keyring-auditor

GPG public keyring weak DSA/RSA-1024 key auditor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

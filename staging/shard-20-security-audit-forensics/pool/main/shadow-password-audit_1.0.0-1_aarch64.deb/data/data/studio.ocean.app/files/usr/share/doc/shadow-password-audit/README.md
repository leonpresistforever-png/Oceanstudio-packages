# shadow-password-audit

/etc/shadow weak password hash algorithm auditor

## Description
Security forensic analysis and incident response tool providing /etc/shadow weak password hash algorithm auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# fuzzy-ssdeep-hasher

Context Triggered Piecewise Hashing ssdeep fuzzy tool

## Description
Security forensic analysis and incident response tool providing Context Triggered Piecewise Hashing ssdeep fuzzy tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# pam-auth-audit-trail

Linux PAM authentication log audit sequence analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# pcap-dns-query-extract

extract DNS query questions and replies from PCAP files

## Description
Security forensic analysis and incident response tool providing extract DNS query questions and replies from PCAP files for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

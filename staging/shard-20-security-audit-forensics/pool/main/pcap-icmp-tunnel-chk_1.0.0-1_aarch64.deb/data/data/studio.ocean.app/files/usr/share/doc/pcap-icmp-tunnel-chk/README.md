# pcap-icmp-tunnel-chk

ICMP payload covert channel data exfiltration checker

## Description
Security forensic analysis and incident response tool providing ICMP payload covert channel data exfiltration checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

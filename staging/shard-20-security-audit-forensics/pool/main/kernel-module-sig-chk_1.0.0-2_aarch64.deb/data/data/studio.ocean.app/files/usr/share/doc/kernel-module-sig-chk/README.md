# kernel-module-sig-chk

Linux kernel .ko module cryptographic signature checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# rootkit-symbol-search

kernel hooking and sys_call_table address inspector

## Description
Security forensic analysis and incident response tool providing kernel hooking and sys_call_table address inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

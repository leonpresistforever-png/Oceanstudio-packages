# sandbox-detection-chk

uptime and user interaction analysis evasion detector

## Description
Security forensic analysis and incident response tool providing uptime and user interaction analysis evasion detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dirty-cow-probe-chk

Linux kernel copy-on-write race condition probe

## Description
Security forensic analysis and incident response tool providing Linux kernel copy-on-write race condition probe for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

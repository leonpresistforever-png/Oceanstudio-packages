# hidden-process-finder

cross-reference /proc PIDs with kill(0) signal checks

## Description
Security forensic analysis and incident response tool providing cross-reference /proc PIDs with kill(0) signal checks for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

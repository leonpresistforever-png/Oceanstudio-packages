# ld-preload-auditor

dynamic linker LD_PRELOAD library interception auditor

## Description
Security forensic analysis and incident response tool providing dynamic linker LD_PRELOAD library interception auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

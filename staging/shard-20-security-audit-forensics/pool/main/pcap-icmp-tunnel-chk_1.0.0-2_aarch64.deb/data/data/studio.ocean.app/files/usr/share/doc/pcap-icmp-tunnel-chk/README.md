# pcap-icmp-tunnel-chk

ICMP payload covert channel data exfiltration checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

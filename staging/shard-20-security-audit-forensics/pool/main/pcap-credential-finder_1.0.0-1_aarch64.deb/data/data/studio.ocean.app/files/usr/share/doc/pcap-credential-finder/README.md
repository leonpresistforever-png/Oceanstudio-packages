# pcap-credential-finder

cleartext credential detector in network capture files

## Description
Security forensic analysis and incident response tool providing cleartext credential detector in network capture files for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

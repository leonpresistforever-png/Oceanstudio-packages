# kernel-kptr-restrict-chk

kernel kptr_restrict and dmesg_restrict setting audit

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

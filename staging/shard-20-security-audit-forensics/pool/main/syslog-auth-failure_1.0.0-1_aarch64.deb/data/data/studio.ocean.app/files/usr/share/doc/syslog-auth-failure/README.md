# syslog-auth-failure

system authentication log brute force failure parser

## Description
Security forensic analysis and incident response tool providing system authentication log brute force failure parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

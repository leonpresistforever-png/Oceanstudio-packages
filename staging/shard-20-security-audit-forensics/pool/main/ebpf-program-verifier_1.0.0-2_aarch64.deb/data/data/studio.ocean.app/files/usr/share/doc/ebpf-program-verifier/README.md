# ebpf-program-verifier

eBPF bytecode instruction safety rule simulator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ssh-known-hosts-hash

SSH known_hosts hashed hostname lookup and verifier

## Description
Security forensic analysis and incident response tool providing SSH known_hosts hashed hostname lookup and verifier for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# suricata-rule-tester

Suricata network threat detection signature linter

## Description
Security forensic analysis and incident response tool providing Suricata network threat detection signature linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

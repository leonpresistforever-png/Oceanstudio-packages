# threat-intel-ip-parser

threat intelligence IP indicator of compromise parser

## Description
Security forensic analysis and incident response tool providing threat intelligence IP indicator of compromise parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# kernel-module-sig-chk

Linux kernel .ko module cryptographic signature checker

## Description
Security forensic analysis and incident response tool providing Linux kernel .ko module cryptographic signature checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# process-environment-diff

process environment variable deviation detector

## Description
Security forensic analysis and incident response tool providing process environment variable deviation detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

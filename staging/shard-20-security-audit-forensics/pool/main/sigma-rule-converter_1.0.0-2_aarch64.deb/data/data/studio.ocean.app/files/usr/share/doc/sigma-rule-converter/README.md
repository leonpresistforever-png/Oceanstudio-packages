# sigma-rule-converter

Sigma generic log signature format syntax validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ld-so-preload-clean

/etc/ld.so.preload malicious library injection detector

## Description
Security forensic analysis and incident response tool providing /etc/ld.so.preload malicious library injection detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

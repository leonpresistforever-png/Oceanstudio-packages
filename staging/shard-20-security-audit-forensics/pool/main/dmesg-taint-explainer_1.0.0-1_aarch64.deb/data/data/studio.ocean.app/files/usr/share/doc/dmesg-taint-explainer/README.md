# dmesg-taint-explainer

Linux kernel taint bitmask flags decoder and explainer

## Description
Security forensic analysis and incident response tool providing Linux kernel taint bitmask flags decoder and explainer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# ptrace-anti-debug-chk

ptrace PTRACE_TRACEME anti-debugging pattern detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

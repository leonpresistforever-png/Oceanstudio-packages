# dmesg-taint-explainer

Linux kernel taint bitmask flags decoder and explainer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

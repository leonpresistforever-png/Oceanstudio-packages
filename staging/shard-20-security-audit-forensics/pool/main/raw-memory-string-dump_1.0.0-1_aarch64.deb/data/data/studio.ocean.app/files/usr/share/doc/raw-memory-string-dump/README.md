# raw-memory-string-dump

raw process memory dump ASCII and UTF-16 string parser

## Description
Security forensic analysis and incident response tool providing raw process memory dump ASCII and UTF-16 string parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

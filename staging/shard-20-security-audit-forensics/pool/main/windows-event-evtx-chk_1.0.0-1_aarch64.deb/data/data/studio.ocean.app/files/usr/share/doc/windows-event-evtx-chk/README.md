# windows-event-evtx-chk

Windows Event Log .evtx file header chunk validator

## Description
Security forensic analysis and incident response tool providing Windows Event Log .evtx file header chunk validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# container-ipam-alloc

container IP Address Management subnet allocator

## Description
Container runtime and Linux namespace management utility providing container IP Address Management subnet allocator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

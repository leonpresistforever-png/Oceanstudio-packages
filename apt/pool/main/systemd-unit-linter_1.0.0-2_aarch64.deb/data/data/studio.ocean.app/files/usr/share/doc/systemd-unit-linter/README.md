# systemd-unit-linter

systemd service unit file syntax and dependency linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# pkgconf-lite

package compiler and linker metadata query tool

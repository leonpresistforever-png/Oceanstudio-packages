# ropgadget-scanner

find ROP gadgets in AArch64 and ARM binaries

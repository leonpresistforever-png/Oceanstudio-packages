# isoinfo-tools

inspect and extract files from ISO images

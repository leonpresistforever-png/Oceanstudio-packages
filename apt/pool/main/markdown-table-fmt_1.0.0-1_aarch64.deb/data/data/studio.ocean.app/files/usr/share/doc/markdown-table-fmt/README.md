# markdown-table-fmt

format and align Markdown tables in stream

# edid-monitor-data-parse

VESA Extended Display Identification Data EDID tool

## Description
Embedded firmware and hardware diagnostics tool providing VESA Extended Display Identification Data EDID tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

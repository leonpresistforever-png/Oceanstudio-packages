# scsi-inquiry-vpd-dump

SCSI Vital Product Data VPD unit serial number reader

## Description
Embedded firmware and hardware diagnostics tool providing SCSI Vital Product Data VPD unit serial number reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# touch-date-setter

RFC 3339 timestamp setter for file modifications

## Description
Filesystem analysis and storage engineering utility providing RFC 3339 timestamp setter for file modifications for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

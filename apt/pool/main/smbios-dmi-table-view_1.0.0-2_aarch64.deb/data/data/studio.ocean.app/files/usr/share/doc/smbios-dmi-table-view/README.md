# smbios-dmi-table-view

SMBIOS/DMI system bios baseboard chassis parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# containerd-shim-ping

containerd shim v2 TTRPC communication probe

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

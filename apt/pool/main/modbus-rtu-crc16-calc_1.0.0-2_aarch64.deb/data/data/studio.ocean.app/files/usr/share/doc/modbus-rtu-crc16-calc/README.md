# modbus-rtu-crc16-calc

Modbus RTU transmission mode CRC-16 calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

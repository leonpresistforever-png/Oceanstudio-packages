# hex-to-binary-tool

convert raw hex string input into binary bytes

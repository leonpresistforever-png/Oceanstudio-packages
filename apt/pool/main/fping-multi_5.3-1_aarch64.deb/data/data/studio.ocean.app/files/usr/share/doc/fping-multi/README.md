# fping-multi

high-performance multi-target parallel ping tool

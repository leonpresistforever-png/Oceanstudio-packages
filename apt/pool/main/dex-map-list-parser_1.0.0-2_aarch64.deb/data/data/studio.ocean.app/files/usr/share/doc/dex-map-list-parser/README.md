# dex-map-list-parser

DEX file map_list item offset and section size tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# protobuf-deprecated-tag

Protobuf [deprecated = true] field usage detector

## Description
API schema validation and protocol contract engine providing Protobuf [deprecated = true] field usage detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

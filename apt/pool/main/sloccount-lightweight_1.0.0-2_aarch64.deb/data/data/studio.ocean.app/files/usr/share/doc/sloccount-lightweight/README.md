# sloccount-lightweight

multi-language source line counter and effort model

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# rootfs-manifest-diff

container rootfs filesystem manifest differential tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

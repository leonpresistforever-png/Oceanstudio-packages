# parquet-metadata-dump

Parquet row group and column chunk stats analyzer

## Description
Embedded database and SQL processing engine providing Parquet row group and column chunk stats analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

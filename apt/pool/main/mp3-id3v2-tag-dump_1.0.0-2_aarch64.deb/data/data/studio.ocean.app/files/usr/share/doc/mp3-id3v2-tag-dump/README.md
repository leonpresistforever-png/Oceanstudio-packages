# mp3-id3v2-tag-dump

MP3 ID3v2.3/ID3v2.4 frame header and text tag parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

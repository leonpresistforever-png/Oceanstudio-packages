# punycode-idna-decode

RFC 3492 Punycode algorithmic decoder and renderer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# soap-envelope-parser

Simple Object Access Protocol SOAP 1.1/1.2 XML parser

## Description
API schema validation and protocol contract engine providing Simple Object Access Protocol SOAP 1.1/1.2 XML parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

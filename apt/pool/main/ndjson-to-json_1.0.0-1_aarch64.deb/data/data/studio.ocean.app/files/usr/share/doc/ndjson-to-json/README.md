# ndjson-to-json

convert newline-delimited JSON stream into JSON array

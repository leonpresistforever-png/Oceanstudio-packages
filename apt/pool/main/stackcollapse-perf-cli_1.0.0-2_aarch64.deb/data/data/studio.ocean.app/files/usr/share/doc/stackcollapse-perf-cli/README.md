# stackcollapse-perf-cli

perf script output to single-line collapsed format

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

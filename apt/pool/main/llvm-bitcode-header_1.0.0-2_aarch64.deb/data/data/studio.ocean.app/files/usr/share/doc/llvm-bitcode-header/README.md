# llvm-bitcode-header

LLVM bitcode wrapper header and block parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# line-prefixer

prepend or append text strings to stream lines

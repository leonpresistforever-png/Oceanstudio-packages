# websocket-cat

WebSocket client bidirectional text and binary framing

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

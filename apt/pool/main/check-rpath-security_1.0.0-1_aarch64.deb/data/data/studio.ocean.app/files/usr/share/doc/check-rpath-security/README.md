# check-rpath-security

audit insecure RPATH definitions like /tmp or writable dirs

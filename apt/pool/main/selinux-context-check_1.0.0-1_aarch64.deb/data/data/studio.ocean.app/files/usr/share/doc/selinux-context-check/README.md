# selinux-context-check

SELinux file security context u:r:s0 syntax checker

## Description
Android Bionic and runtime platform utility providing SELinux file security context u:r:s0 syntax checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dir-tree-hasher-fast

fast parallel directory tree deterministic Merkle hasher

## Description
Archive file format and differential backup utility providing fast parallel directory tree deterministic Merkle hasher for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

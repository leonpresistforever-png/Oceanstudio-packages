# rfid-mifare-block-chk

MIFARE Classic 1K sector trailer access bits decoder

## Description
Embedded firmware and hardware diagnostics tool providing MIFARE Classic 1K sector trailer access bits decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# lzip-decompressor

lossless data decompressor using LZMA algorithm

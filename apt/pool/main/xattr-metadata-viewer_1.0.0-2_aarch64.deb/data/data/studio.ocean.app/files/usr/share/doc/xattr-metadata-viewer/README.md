# xattr-metadata-viewer

user and security namespace extended attribute viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

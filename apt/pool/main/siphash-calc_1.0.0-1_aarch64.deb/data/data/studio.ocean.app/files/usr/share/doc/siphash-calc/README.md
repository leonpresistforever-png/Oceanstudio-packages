# siphash-calc

SipHash-2-4 fast short-input pseudo-random MAC calculator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# oauth2-token-exchange

RFC 8693 OAuth 2.0 Token Exchange request validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ranlib-index-viewer

archive symbol index table table-of-contents viewer

## Description
Binary analysis and compilation toolchain helper providing archive symbol index table table-of-contents viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# ip-range-expander

IP CIDR notation to sequential IP list generator

## Description
Low-level network protocol and socket diagnostics utility providing IP CIDR notation to sequential IP list generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# neon-fp-pipeline-bench

ARM64 NEON floating-point fused multiply-add benchmark

## Description
Performance profiling and microbenchmark utility providing ARM64 NEON floating-point fused multiply-add benchmark for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

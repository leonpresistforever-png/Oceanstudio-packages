# pii-regex-scrubber-cli

Personally Identifiable Information email phone scrubber

## Description
Data stream transformation and ETL pipeline tool providing Personally Identifiable Information email phone scrubber for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

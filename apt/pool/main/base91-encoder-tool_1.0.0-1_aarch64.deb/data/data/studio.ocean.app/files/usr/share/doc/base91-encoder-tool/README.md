# base91-encoder-tool

Base91 advanced high-density binary data encoder

## Description
Cryptographic engine and secret management utility providing Base91 advanced high-density binary data encoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# csv-row-filter

filter CSV rows based on numeric and string predicates

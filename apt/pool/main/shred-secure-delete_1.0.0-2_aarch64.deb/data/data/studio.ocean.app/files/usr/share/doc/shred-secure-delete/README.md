# shred-secure-delete

NIST 800-88 compliant multi-pass secure file shredder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# apk-dex-lister

inspect classes and method signatures in Dalvik DEX files

# diff-3way-merge-tool

three-way text file conflict merge reconciler

## Description
Text tokenization and natural language processing tool providing three-way text file conflict merge reconciler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

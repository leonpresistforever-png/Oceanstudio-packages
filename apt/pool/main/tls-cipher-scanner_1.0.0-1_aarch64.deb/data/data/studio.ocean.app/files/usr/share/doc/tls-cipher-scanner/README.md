# tls-cipher-scanner

TLS cipher suite enumerator and vulnerability checker

## Description
Cryptographic engine and secret management utility providing TLS cipher suite enumerator and vulnerability checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

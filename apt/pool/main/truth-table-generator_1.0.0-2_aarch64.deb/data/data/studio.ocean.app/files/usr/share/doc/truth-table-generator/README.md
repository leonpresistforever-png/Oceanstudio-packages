# truth-table-generator

propositional logic formula full truth table matrix

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# json-feed-validator-cli

JSON Feed Version 1.1 schema and item validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

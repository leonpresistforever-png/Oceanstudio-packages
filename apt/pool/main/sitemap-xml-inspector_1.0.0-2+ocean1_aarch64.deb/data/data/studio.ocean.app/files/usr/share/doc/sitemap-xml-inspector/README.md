# sitemap-xml-inspector

XML Sitemap 0.9 urlset and sitemapindex validator
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard25_api.py
Source SHA256: be544c4277634747755aae160881ede464497d7579696a870bcd3f99430a4cfa
Shared runtime package: ocean-runtime-shard25-api

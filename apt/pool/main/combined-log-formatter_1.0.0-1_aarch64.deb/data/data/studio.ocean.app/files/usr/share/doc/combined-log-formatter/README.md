# combined-log-formatter

NCSA Combined Log Format to structured JSON converter

## Description
Data stream transformation and ETL pipeline tool providing NCSA Combined Log Format to structured JSON converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

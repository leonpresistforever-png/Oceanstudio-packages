# kademlia-distance-xor

Kademlia 160-bit XOR metric distance calculator

## Description
Distributed systems consensus and P2P protocol utility providing Kademlia 160-bit XOR metric distance calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

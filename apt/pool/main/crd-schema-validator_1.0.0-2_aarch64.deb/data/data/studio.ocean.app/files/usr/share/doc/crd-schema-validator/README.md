# crd-schema-validator

Kubernetes CustomResourceDefinition schema linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

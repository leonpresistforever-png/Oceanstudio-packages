# cors-misconfig-chk

detect insecure CORS wildcard origin reflections

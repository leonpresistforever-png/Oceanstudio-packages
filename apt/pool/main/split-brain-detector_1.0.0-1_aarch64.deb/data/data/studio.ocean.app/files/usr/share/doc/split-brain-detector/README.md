# split-brain-detector

cluster network partition split-brain risk detector

## Description
Distributed systems consensus and P2P protocol utility providing cluster network partition split-brain risk detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

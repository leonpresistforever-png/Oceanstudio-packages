# pax-archive-validator

POSIX pax interchange archive format validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

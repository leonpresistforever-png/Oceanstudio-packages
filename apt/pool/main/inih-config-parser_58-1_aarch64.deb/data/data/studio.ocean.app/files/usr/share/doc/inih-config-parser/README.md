# inih-config-parser

simple INI configuration file reader and validator

# log-regex-named-captures

regular expression named capture group JSON extractor

## Description
Data stream transformation and ETL pipeline tool providing regular expression named capture group JSON extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dns-soa-serial-checker

DNS Start of Authority zone serial number checker

## Description
Low-level network protocol and socket diagnostics utility providing DNS Start of Authority zone serial number checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

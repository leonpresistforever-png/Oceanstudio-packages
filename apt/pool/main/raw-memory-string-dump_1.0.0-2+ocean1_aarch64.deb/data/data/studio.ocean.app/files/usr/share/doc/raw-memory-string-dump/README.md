# raw-memory-string-dump

raw process memory dump ASCII and UTF-16 string parser
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard20_forensics.py
Source SHA256: a88c3d2dd43473b39c7d84a768ddf3326c5b7cb30abdf87fffaf998f2aa90614
Shared runtime package: ocean-runtime-shard20-forensics

# spi-flash-jedec-id-chk

SPI NOR flash JEDEC RDID manufacturer ID lookup

## Description
Embedded firmware and hardware diagnostics tool providing SPI NOR flash JEDEC RDID manufacturer ID lookup for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

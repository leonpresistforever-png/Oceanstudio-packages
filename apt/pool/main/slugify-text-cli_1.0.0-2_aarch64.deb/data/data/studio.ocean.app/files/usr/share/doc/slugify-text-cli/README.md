# slugify-text-cli

URL slug generator with accent diacritic stripping

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

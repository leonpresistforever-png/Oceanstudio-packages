# convex-hull-graham

Graham scan 2D point cloud convex hull calculator

## Description
Scientific calculation and numerical algorithm engine providing Graham scan 2D point cloud convex hull calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

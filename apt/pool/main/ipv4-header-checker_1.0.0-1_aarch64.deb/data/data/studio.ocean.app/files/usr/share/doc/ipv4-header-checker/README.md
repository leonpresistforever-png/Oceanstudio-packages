# ipv4-header-checker

IPv4 header checksum TTL and fragmentation parser

## Description
Low-level network protocol and socket diagnostics utility providing IPv4 header checksum TTL and fragmentation parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# character-ngram-gen

text character and subword n-gram frequency modeler

## Description
Text tokenization and natural language processing tool providing text character and subword n-gram frequency modeler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

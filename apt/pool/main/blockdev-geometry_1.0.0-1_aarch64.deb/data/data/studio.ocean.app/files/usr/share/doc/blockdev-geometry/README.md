# blockdev-geometry

block device logical sector size and rotational view

## Description
Filesystem analysis and storage engineering utility providing block device logical sector size and rotational view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

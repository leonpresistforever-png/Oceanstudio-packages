#!/data/data/studio.ocean.app/files/usr/bin/sh

. "${OCEAN_PREFIX:-"${PREFIX}"}"/libexec/source-ssh-agent.sh
"${wrapped_cmd}" "$@"

# ar-bsd-variant-parser

BSD ar archive #1/ extended file name parser

## Description
Archive file format and differential backup utility providing BSD ar archive #1/ extended file name parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# suid-binary-matrix

setuid and setgid binary GTFOBins capability matrix

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

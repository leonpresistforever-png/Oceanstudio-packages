# deadlock-cycle-checker

resource allocation graph deadlock cycle detector

## Description
Static analysis and source code auditing utility providing resource allocation graph deadlock cycle detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

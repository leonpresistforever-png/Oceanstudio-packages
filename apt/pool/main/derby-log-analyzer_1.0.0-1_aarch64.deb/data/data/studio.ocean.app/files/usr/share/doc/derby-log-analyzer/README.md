# derby-log-analyzer

Apache Derby database transaction log analyzer

## Description
Embedded database and SQL processing engine providing Apache Derby database transaction log analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

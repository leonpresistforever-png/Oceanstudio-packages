# mp3-id3v2-tag-dump

MP3 ID3v2.3/ID3v2.4 frame header and text tag parser
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard14_media.py
Source SHA256: da4b8287d4826545ebe609aaf32fa0cc257fb4aa69ba13917832e73c42e74d23
Shared runtime package: ocean-runtime-shard14-media

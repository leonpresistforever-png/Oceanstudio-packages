# groff-formatter-lite

lightweight troff roff typesetting macro processor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# percentile-calc

calculate p50, p90, p99 percentiles from stream of values

# crun-lightweight-exec

lightweight fast OCI container runtime runner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# jitter-interarrival-chk

execution interval jitter and timing variance meter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

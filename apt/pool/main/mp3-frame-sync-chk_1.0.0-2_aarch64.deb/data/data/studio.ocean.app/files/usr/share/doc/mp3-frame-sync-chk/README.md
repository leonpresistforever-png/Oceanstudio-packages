# mp3-frame-sync-chk

MPEG audio frame synchronization word and bitrate tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ar-archive-extractor

UNIX ar static library member extractor and indexer

## Description
Binary analysis and compilation toolchain helper providing UNIX ar static library member extractor and indexer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# jaeger-thrift-exporter

Jaeger span JSON to compact model serializer

## Description
Distributed systems consensus and P2P protocol utility providing Jaeger span JSON to compact model serializer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

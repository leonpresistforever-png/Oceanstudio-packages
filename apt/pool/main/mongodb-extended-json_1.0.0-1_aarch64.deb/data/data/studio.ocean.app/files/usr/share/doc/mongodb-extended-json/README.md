# mongodb-extended-json

MongoDB Extended JSON v2 format to standard JSON tool

## Description
Embedded database and SQL processing engine providing MongoDB Extended JSON v2 format to standard JSON tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

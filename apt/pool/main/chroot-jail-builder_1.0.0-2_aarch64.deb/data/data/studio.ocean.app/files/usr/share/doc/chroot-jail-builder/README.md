# chroot-jail-builder

minimalist chroot directory hierarchy staging tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

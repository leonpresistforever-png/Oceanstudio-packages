# diff-side-by-side

side-by-side two-column terminal text differential

## Description
Text tokenization and natural language processing tool providing side-by-side two-column terminal text differential for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

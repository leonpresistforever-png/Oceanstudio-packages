# unicode-normalization

Unicode NFC NFD NFKC NFKD canonical normalizer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# tiff-ifd-inspector

TIFF Image File Directory tag count and offset reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# protobuf-proto3-linter

Protocol Buffers proto3 syntax and conventions linter

## Description
API schema validation and protocol contract engine providing Protocol Buffers proto3 syntax and conventions linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

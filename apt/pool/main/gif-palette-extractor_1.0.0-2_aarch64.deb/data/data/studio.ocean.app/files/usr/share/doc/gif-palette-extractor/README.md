# gif-palette-extractor

GIF global and local color table palette viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

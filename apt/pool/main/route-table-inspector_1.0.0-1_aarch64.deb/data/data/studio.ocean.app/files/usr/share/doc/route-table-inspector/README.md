# route-table-inspector

Linux kernel IP routing table metric and gateway viewer

## Description
Low-level network protocol and socket diagnostics utility providing Linux kernel IP routing table metric and gateway viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

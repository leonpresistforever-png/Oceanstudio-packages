# switch-fallthrough-chk

switch statement missing break fallthrough auditor

## Description
Static analysis and source code auditing utility providing switch statement missing break fallthrough auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

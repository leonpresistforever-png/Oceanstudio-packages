# png-ihdr-analyzer

PNG IHDR dimensions bit-depth and color type reader

## Description
Media header parser and audiovisual engineering utility providing PNG IHDR dimensions bit-depth and color type reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# thermal-governor-latency

thermal cooling device state change transition timer

## Description
Performance profiling and microbenchmark utility providing thermal cooling device state change transition timer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

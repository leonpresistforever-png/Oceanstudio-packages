# sqlite-vacuum-analyze

SQLite fragmented free page percentage calculator

## Description
Embedded database and SQL processing engine providing SQLite fragmented free page percentage calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

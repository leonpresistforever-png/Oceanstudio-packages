# cpufreq-scaling-gov

CPU frequency scaling governors and transition table

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

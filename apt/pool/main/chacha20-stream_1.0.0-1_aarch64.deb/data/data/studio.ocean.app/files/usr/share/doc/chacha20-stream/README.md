# chacha20-stream

ChaCha20 symmetric stream cipher encryption/decryption

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

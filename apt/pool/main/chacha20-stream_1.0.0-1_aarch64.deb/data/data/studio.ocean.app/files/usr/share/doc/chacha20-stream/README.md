# chacha20-stream

ChaCha20 stream cipher file encryptor and decryptor

## Description
Cryptographic engine and secret management utility providing ChaCha20 stream cipher file encryptor and decryptor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

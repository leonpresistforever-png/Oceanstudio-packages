# zopfli-zlib

Zopfli deflate algorithm compressor

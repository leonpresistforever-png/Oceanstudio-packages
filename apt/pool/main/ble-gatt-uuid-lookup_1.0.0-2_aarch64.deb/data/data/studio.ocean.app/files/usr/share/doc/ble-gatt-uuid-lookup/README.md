# ble-gatt-uuid-lookup

Bluetooth Low Energy 16-bit and 128-bit UUID database

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

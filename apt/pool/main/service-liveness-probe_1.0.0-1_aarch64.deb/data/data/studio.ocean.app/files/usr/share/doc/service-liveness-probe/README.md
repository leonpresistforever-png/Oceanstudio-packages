# service-liveness-probe

container HTTP and TCP liveness probe simulator

## Description
DevOps workflow and microservice coordination utility providing container HTTP and TCP liveness probe simulator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

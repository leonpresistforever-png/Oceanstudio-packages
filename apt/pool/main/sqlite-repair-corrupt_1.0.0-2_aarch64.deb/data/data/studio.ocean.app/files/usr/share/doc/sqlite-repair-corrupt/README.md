# sqlite-repair-corrupt

corrupt SQLite database raw text and row recovery

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

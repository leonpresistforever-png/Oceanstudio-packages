# k8s-pod-yaml-linter

Kubernetes Pod and Deployment YAML schema validator

## Description
DevOps workflow and microservice coordination utility providing Kubernetes Pod and Deployment YAML schema validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# astronomical-julian

Julian Day and Modified Julian Date astronomical calc

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

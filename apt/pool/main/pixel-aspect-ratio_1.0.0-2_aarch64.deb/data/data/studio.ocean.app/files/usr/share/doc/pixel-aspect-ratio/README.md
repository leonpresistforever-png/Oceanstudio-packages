# pixel-aspect-ratio

digital video pixel aspect ratio to display aspect ratio

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ssh-key-fingerprinter

SSH public key MD5 and SHA-256 fingerprinter

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

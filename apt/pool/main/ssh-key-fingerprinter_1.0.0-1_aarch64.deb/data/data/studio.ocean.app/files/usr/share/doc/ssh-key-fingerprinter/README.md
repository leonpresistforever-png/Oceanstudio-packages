# ssh-key-fingerprinter

SSH public key SHA256 and MD5 fingerprint scanner

## Description
Cryptographic engine and secret management utility providing SSH public key SHA256 and MD5 fingerprint scanner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# pearson-correlation

Pearson product-moment correlation coefficient tool

## Description
Scientific calculation and numerical algorithm engine providing Pearson product-moment correlation coefficient tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# strace-frequency-analyzer

analyze system call frequency distributions from strace

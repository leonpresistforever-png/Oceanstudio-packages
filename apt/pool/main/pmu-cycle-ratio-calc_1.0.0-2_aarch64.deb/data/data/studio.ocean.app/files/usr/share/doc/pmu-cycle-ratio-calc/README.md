# pmu-cycle-ratio-calc

CPU cycles to instructions executed ratio calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# h2-database-export

H2 embedded SQL database script backup reader

## Description
Embedded database and SQL processing engine providing H2 embedded SQL database script backup reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# asyncapi-spec-validator

AsyncAPI 2.x event-driven API specification validator

## Description
API schema validation and protocol contract engine providing AsyncAPI 2.x event-driven API specification validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

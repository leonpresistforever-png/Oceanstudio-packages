# par2cmdline-lite

PAR 2.0 parity archive generator and repair tool

# packed-executable-chk

software packer and crypter heuristic detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# oat-runtime-header

Android OAT ahead-of-time compiled ELF header parser

## Description
Android Bionic and runtime platform utility providing Android OAT ahead-of-time compiled ELF header parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

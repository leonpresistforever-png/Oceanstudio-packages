# sql-dialect-converter

SQL dialect transpile helper Postgres SQLite MySQL

## Description
Embedded database and SQL processing engine providing SQL dialect transpile helper Postgres SQLite MySQL for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

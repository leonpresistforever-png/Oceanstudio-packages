# power-consumption-model

ARM big.LITTLE core energy consumption model tool

## Description
Performance profiling and microbenchmark utility providing ARM big.LITTLE core energy consumption model tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

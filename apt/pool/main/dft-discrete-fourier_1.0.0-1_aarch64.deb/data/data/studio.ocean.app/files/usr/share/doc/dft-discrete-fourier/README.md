# dft-discrete-fourier

Discrete Fourier Transform discrete frequency analyzer

## Description
Scientific calculation and numerical algorithm engine providing Discrete Fourier Transform discrete frequency analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

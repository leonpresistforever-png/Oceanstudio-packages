# syllable-counter-cli

English word syllable count heuristic estimator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

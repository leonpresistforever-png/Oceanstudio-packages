# vector-embedding-index

high-dimensional vector cosine similarity indexer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

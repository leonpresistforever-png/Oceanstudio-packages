# wget-recursive-lister

HTTP directory listing link recursion analyzer

## Description
Low-level network protocol and socket diagnostics utility providing HTTP directory listing link recursion analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# cyclomatic-complexity

McCabe cyclomatic complexity metric calculator for code

## Description
Static analysis and source code auditing utility providing McCabe cyclomatic complexity metric calculator for code for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# simd-vector-width-probe

ARM64 NEON and SVE SIMD vector register width probe

## Description
Performance profiling and microbenchmark utility providing ARM64 NEON and SVE SIMD vector register width probe for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# kernel-cmdline-parser

boot kernel parameter command line key-value parser

## Description
Linux procfs and system diagnostic utility providing boot kernel parameter command line key-value parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

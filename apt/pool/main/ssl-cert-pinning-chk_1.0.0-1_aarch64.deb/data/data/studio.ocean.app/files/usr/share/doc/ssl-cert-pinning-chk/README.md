# ssl-cert-pinning-chk

calculate SPKI SHA-256 fingerprint for certificate pinning

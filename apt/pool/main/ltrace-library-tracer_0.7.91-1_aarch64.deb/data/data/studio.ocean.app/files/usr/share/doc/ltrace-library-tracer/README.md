# ltrace-library-tracer

intercept and record dynamic library calls in processes

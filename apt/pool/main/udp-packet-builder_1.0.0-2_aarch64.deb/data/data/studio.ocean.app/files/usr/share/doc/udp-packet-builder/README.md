# udp-packet-builder

UDP datagram length and checksum verification tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

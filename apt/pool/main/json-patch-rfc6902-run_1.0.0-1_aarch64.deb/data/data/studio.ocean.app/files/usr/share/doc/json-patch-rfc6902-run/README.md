# json-patch-rfc6902-run

RFC 6902 JavaScript Object Notation Patch evaluator

## Description
API schema validation and protocol contract engine providing RFC 6902 JavaScript Object Notation Patch evaluator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

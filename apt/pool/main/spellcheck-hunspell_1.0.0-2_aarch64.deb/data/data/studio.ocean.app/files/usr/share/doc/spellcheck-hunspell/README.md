# spellcheck-hunspell

Hunspell affix and dictionary spell checking engine

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

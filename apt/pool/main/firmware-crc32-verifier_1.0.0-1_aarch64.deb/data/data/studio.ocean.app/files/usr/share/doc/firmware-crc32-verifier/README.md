# firmware-crc32-verifier

embedded microcontroller firmware image CRC32 tool

## Description
Embedded firmware and hardware diagnostics tool providing embedded microcontroller firmware image CRC32 tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

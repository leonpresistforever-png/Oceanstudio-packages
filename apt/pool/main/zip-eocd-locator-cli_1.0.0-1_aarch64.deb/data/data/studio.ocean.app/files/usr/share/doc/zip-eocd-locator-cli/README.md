# zip-eocd-locator-cli

ZIP End of Central Directory record offset locator

## Description
Archive file format and differential backup utility providing ZIP End of Central Directory record offset locator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

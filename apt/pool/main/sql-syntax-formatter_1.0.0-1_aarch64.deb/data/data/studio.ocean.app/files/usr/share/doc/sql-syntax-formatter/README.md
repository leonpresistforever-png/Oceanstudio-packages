# sql-syntax-formatter

SQL query prettifier and indentation formatter

## Description
Embedded database and SQL processing engine providing SQL query prettifier and indentation formatter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# sqlite-json-query-cli

SQLite json_extract and json_each CLI processor

## Description
Embedded database and SQL processing engine providing SQLite json_extract and json_each CLI processor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# matrix-inverse-3d

matrix Gauss-Jordan elimination inversion tool

## Description
Scientific calculation and numerical algorithm engine providing matrix Gauss-Jordan elimination inversion tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

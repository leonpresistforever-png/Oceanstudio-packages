# macho-uuid-inspector

Mach-O LC_UUID binary identifier extractor

## Description
Binary analysis and compilation toolchain helper providing Mach-O LC_UUID binary identifier extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

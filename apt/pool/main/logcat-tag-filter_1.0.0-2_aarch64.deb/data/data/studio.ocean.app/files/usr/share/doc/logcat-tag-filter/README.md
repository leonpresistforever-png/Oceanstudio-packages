# logcat-tag-filter

Android logcat binary logger buffer tag priority filter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

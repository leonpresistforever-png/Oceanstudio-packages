# cache-control-validator

HTTP Cache-Control max-age must-revalidate analyzer

## Description
API schema validation and protocol contract engine providing HTTP Cache-Control max-age must-revalidate analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# envsubst-lite

lightweight shell variable environment substitution tool

## Description
DevOps workflow and microservice coordination utility providing lightweight shell variable environment substitution tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

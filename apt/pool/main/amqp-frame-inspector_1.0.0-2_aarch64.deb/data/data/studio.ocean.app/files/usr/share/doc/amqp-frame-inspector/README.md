# amqp-frame-inspector

RabbitMQ AMQP 0-9-1 framing and channel inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ssl-tls-poodle-tester

TLS CBC mode padding oracle POODLE vulnerability test

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# http-basic-auth-encoder

RFC 7617 HTTP Basic authentication header generator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

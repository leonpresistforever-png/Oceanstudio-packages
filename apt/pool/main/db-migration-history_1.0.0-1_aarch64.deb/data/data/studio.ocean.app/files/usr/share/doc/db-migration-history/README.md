# db-migration-history

database migration version sequence gap detector

## Description
Embedded database and SQL processing engine providing database migration version sequence gap detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

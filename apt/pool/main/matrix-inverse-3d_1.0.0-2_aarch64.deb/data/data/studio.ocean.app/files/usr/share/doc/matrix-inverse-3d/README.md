# matrix-inverse-3d

matrix Gauss-Jordan elimination inversion tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

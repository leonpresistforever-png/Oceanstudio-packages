# power-supply-status-chk

Linux /sys/class/power_supply battery charge health

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

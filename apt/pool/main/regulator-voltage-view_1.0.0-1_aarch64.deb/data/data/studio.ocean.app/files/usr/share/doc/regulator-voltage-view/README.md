# regulator-voltage-view

Linux voltage regulator microvolt constraints viewer

## Description
Embedded firmware and hardware diagnostics tool providing Linux voltage regulator microvolt constraints viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dc-reverse-polish

GNU reverse-polish arbitrary precision calculator

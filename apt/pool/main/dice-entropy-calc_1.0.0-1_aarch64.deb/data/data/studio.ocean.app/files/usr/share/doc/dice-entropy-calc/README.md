# dice-entropy-calc

Shannon entropy and bit-level distribution calculator

## Description
Cryptographic engine and secret management utility providing Shannon entropy and bit-level distribution calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dice-entropy-calc

Dice roll entropy and Diceware passphrase strength calculator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

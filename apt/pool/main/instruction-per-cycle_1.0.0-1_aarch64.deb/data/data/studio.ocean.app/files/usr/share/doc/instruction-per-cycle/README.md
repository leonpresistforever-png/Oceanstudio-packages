# instruction-per-cycle

Instructions Per Cycle IPC throughput metric calculator

## Description
Performance profiling and microbenchmark utility providing Instructions Per Cycle IPC throughput metric calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

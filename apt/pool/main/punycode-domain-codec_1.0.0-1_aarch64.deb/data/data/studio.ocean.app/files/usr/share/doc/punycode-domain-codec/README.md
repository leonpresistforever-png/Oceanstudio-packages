# punycode-domain-codec

internationalized domain name IDNA Punycode encoder and decoder

## Description
Low-level network protocol and socket diagnostics utility providing internationalized domain name IDNA Punycode encoder and decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

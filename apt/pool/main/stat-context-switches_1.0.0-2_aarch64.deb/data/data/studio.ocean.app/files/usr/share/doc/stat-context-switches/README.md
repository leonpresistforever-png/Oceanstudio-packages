# stat-context-switches

system voluntary and involuntary context switch rate

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

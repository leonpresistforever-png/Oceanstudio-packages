# sched-latency-tracker

task scheduler scheduling delay and run delay probe

## Description
Linux procfs and system diagnostic utility providing task scheduler scheduling delay and run delay probe for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

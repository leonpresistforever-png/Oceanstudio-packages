# apex-manifest-parser

Android APEX container apex_manifest.json/pb parser

## Description
Android Bionic and runtime platform utility providing Android APEX container apex_manifest.json/pb parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

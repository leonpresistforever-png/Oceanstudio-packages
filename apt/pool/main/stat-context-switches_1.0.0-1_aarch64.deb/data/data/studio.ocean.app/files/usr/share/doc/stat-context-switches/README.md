# stat-context-switches

system voluntary and involuntary context switch rate

## Description
Linux procfs and system diagnostic utility providing system voluntary and involuntary context switch rate for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# sql-ast-visualizer

SQL query abstract syntax tree treeview generator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

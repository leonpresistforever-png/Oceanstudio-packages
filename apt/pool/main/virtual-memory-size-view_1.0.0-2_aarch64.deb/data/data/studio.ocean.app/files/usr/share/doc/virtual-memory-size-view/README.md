# virtual-memory-size-view

virtual memory size VmSize vs resident ratio checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

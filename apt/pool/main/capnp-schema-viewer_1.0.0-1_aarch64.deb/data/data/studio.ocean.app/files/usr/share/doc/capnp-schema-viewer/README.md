# capnp-schema-viewer

Cap'n Proto schema field offset and type inspector

## Description
DevOps workflow and microservice coordination utility providing Cap'n Proto schema field offset and type inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

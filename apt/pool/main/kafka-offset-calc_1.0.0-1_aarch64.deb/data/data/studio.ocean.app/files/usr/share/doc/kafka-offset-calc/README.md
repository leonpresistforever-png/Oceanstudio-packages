# kafka-offset-calc

Apache Kafka partition consumer group lag calculator

## Description
DevOps workflow and microservice coordination utility providing Apache Kafka partition consumer group lag calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

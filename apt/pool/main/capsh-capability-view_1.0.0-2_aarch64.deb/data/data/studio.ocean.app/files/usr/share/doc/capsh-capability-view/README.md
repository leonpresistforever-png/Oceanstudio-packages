# capsh-capability-view

process POSIX capabilities bounding set reporter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

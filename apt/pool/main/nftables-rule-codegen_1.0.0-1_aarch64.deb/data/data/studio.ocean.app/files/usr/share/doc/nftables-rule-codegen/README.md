# nftables-rule-codegen

nftables table chain rule syntax generator

## Description
Container runtime and Linux namespace management utility providing nftables table chain rule syntax generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

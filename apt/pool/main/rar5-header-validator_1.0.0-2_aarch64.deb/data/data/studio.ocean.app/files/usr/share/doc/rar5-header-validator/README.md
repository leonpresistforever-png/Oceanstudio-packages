# rar5-header-validator

RAR 5.0 archive signature and block header parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# package-signing-v3-chk

Android APK Signature Scheme v3 key rotation checker

## Description
Android Bionic and runtime platform utility providing Android APK Signature Scheme v3 key rotation checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

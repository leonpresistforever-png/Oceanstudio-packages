# cgroup-memory-limiter

cgroup v1/v2 memory limit and usage inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# socat-multipurpose

multipurpose bidirectional data relay

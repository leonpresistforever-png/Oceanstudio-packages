# ed25519-tool

Edwards-curve Ed25519 key generator and verifier

## Description
Cryptographic engine and secret management utility providing Edwards-curve Ed25519 key generator and verifier for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# rust-symbol-demangle

Rust v0 and legacy mangled symbol demangler

## Description
Binary analysis and compilation toolchain helper providing Rust v0 and legacy mangled symbol demangler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

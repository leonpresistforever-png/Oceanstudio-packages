# rdiff-patch-applier

binary differential delta patch application tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# package-signing-v2-chk

Android APK Signature Scheme v2 block 0x7109871a check

## Description
Android Bionic and runtime platform utility providing Android APK Signature Scheme v2 block 0x7109871a check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

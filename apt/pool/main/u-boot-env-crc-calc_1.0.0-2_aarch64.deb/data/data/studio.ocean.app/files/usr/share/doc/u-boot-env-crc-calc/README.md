# u-boot-env-crc-calc

U-Boot environment variables CRC32 checksum tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# orc-file-footer-parser

Apache ORC file footer and stripe metadata parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

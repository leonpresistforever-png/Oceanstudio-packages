# topological-sorter

Directed Acyclic Graph Kahn topological sort engine

## Description
Scientific calculation and numerical algorithm engine providing Directed Acyclic Graph Kahn topological sort engine for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# csv-quoting-fixer

malformed CSV unescaped quotes RFC 4180 repair tool

## Description
Data stream transformation and ETL pipeline tool providing malformed CSV unescaped quotes RFC 4180 repair tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# call-graph-dot-generator

profiler function call graph Graphviz DOT generator

## Description
Performance profiling and microbenchmark utility providing profiler function call graph Graphviz DOT generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# getprop-filter-tool

Android system properties key filtering and JSON dump

## Description
Android Bionic and runtime platform utility providing Android system properties key filtering and JSON dump for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# w3c-trace-context-parse

W3C traceparent and tracestate header parser
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard23_distributed.py
Source SHA256: 6ec8fbd810547bd6a9777b87427578170e414e36bb5cbf8d8129f1a344522010
Shared runtime package: ocean-runtime-shard23-distributed

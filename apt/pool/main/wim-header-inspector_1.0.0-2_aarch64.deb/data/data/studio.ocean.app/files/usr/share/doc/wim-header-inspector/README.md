# wim-header-inspector

Windows Imaging Format WIMHEADER and XML data reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

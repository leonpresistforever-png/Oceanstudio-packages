# temperature-scale-conv

Celsius Fahrenheit Kelvin Rankine Delisle converter

## Description
Scientific calculation and numerical algorithm engine providing Celsius Fahrenheit Kelvin Rankine Delisle converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

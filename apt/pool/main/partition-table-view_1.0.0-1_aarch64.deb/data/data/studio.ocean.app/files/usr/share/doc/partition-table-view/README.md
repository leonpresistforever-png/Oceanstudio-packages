# partition-table-view

disk partition layout and sector boundary reporter

## Description
Filesystem analysis and storage engineering utility providing disk partition layout and sector boundary reporter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

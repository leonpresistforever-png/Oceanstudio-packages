# modbus-tcp-header-chk

Modbus TCP MBAP header unit ID and function check

## Description
Embedded firmware and hardware diagnostics tool providing Modbus TCP MBAP header unit ID and function check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

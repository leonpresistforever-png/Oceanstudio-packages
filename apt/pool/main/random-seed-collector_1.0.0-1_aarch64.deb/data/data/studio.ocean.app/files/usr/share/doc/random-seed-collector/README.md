# random-seed-collector

High-entropy random seed collector from system CSPRNG

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

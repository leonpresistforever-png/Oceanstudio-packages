# random-seed-collector

high-entropy system randomness pool sampler

## Description
Cryptographic engine and secret management utility providing high-entropy system randomness pool sampler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

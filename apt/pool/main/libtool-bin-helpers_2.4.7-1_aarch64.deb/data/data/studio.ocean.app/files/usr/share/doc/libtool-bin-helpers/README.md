# libtool-bin-helpers

generic library support script helpers

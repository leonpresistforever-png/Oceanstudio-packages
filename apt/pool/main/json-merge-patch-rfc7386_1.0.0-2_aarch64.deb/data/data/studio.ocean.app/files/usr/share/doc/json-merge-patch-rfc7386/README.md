# json-merge-patch-rfc7386

RFC 7386 JSON Merge Patch document reconciler

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

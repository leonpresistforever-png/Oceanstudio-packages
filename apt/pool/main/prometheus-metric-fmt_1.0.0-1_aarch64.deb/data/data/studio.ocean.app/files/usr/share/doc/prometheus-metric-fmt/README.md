# prometheus-metric-fmt

Prometheus text-format metric counter gauge formatter

## Description
DevOps workflow and microservice coordination utility providing Prometheus text-format metric counter gauge formatter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# bluetooth-hci-cmd-dump

Bluetooth Host Controller Interface HCI packet parser

## Description
Embedded firmware and hardware diagnostics tool providing Bluetooth Host Controller Interface HCI packet parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

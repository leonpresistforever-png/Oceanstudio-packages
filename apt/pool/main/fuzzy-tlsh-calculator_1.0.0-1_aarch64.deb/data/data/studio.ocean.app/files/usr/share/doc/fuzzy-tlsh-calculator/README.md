# fuzzy-tlsh-calculator

Trend Micro Locality Sensitive Hash TLSH similarity tool

## Description
Security forensic analysis and incident response tool providing Trend Micro Locality Sensitive Hash TLSH similarity tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

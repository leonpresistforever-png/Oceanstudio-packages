# zero-copy-splice-bench

Linux splice vmsplice zero-copy pipe benchmark tool

## Description
Performance profiling and microbenchmark utility providing Linux splice vmsplice zero-copy pipe benchmark tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# subdomain-takeover-chk

detect dangling CNAME pointers to decommissioned services

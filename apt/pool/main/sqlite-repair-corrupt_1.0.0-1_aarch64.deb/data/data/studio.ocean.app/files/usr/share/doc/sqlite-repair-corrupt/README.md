# sqlite-repair-corrupt

corrupt SQLite database raw text and row recovery

## Description
Embedded database and SQL processing engine providing corrupt SQLite database raw text and row recovery for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# symlink-target-auditor

audit symbolic links for dangling or relative escape targets

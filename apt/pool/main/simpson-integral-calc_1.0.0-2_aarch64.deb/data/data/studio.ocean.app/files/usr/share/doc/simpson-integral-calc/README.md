# simpson-integral-calc

composite Simpson numerical definite integral solver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

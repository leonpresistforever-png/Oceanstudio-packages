# berkeleydb-hash-chk

Berkeley DB Hash and Btree file header parser

## Description
Embedded database and SQL processing engine providing Berkeley DB Hash and Btree file header parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# utm-lat-long-converter

Universal Transverse Mercator GPS coordinate converter

## Description
Scientific calculation and numerical algorithm engine providing Universal Transverse Mercator GPS coordinate converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

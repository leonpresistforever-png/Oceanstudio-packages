# postgresql-copy-stream

PostgreSQL COPY protocol text/binary stream formatter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

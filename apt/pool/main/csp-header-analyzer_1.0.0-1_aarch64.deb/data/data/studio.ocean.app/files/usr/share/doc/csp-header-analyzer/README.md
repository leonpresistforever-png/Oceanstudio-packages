# csp-header-analyzer

analyze Content-Security-Policy rules for unsafe-inline or wildcards

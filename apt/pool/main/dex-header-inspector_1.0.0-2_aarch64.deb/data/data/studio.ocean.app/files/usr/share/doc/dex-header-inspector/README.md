# dex-header-inspector

Dalvik Executable format 035-039 header magic analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

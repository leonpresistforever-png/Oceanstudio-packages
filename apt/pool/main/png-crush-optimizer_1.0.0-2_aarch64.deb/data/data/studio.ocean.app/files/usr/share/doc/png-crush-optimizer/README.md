# png-crush-optimizer

lossless PNG deflation filter strategy evaluator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# avif-box-inspector

AV1 Image File Format ISOBMFF box item parser

## Description
Media header parser and audiovisual engineering utility providing AV1 Image File Format ISOBMFF box item parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

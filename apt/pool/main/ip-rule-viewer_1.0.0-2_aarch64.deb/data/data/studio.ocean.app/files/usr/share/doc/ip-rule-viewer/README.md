# ip-rule-viewer

policy routing rules and lookup table priorities viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

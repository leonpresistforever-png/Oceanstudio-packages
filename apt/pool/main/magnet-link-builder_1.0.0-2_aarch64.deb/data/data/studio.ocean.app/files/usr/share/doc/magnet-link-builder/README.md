# magnet-link-builder

BTIH magnet URI builder with tracker parameters

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# rust-syntax-validator

Rust language tokens and macro bracket matching linter

## Description
Static analysis and source code auditing utility providing Rust language tokens and macro bracket matching linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

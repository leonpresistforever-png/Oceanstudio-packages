# text-justify

justify text lines to specified terminal width

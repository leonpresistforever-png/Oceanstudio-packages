# flatbuffers-validator

validate FlatBuffers schema definition files

# cassandra-cql-parser

Cassandra CQL schema and keyspace syntax validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

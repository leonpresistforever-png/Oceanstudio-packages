# statm-resident-calc

process memory pages resident shared text breakdown

## Description
Linux procfs and system diagnostic utility providing process memory pages resident shared text breakdown for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# plist-xml-converter

convert Apple Property List files between binary and XML

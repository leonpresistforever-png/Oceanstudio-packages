# neon-fp-pipeline-bench

ARM64 NEON floating-point fused multiply-add benchmark

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

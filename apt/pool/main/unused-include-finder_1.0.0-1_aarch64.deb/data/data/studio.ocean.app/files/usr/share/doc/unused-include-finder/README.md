# unused-include-finder

C/C++ redundant #include header directive detector

## Description
Static analysis and source code auditing utility providing C/C++ redundant #include header directive detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

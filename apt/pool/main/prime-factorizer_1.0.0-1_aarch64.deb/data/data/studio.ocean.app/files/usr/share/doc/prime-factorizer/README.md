# prime-factorizer

compute prime factorization of arbitrary integers

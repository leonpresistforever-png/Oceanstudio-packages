# json-lines-unflatten

dot-notation key-value JSON records unflattening tool

## Description
Data stream transformation and ETL pipeline tool providing dot-notation key-value JSON records unflattening tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

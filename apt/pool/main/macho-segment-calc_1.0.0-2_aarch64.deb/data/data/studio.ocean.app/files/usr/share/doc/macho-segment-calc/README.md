# macho-segment-calc

Mach-O __TEXT and __DATA segment size analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

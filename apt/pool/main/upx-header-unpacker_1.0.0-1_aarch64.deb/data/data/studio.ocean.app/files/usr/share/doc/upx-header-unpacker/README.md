# upx-header-unpacker

UPX compressed executable header and magic inspector

## Description
Security forensic analysis and incident response tool providing UPX compressed executable header and magic inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

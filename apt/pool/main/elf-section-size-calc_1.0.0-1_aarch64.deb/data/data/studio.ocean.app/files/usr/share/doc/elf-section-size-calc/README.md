# elf-section-size-calc

ELF section header table size and alignment auditor

## Description
Binary analysis and compilation toolchain helper providing ELF section header table size and alignment auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# sockstat-analyzer

kernel socket allocation statistics summarizer
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard06_proc.py
Source SHA256: dbc1713112663558b0709613cb5f58fbcb145a43ecdbe3101bc202b8175c3419
Shared runtime package: ocean-runtime-shard06-proc

# cgroup-v2-rdma-limit

cgroup v2 Remote Direct Memory Access limit view

## Description
Container runtime and Linux namespace management utility providing cgroup v2 Remote Direct Memory Access limit view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

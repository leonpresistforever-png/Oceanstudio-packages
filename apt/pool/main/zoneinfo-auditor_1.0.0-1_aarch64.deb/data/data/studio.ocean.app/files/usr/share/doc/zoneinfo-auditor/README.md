# zoneinfo-auditor

NUMA node memory zone watermark and protection auditor

## Description
Linux procfs and system diagnostic utility providing NUMA node memory zone watermark and protection auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# pcap-header-analyzer

PCAP global and packet header format validator

## Description
Low-level network protocol and socket diagnostics utility providing PCAP global and packet header format validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# whois-client-rfc

RFC-compliant WHOIS client with referral following

# cpio-odc-format-dump

cpio portable old ASCII format header decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# key-pair-generator-cli

generate RSA and Ed25519 key pairs for application signing

# nfc-ndef-record-parser

NFC Data Exchange Format NDEF record TNF parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# regex-filter

regular expression filter with capture replacement

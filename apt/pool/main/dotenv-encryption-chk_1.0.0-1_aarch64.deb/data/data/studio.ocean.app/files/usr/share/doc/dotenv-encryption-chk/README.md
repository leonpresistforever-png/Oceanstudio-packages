# dotenv-encryption-chk

.env file secret exposure and encryption status check

## Description
DevOps workflow and microservice coordination utility providing .env file secret exposure and encryption status check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

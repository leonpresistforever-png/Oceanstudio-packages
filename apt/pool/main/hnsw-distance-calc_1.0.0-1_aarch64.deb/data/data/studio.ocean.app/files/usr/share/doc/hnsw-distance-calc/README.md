# hnsw-distance-calc

Hierarchical Navigable Small World vector search tool

## Description
Embedded database and SQL processing engine providing Hierarchical Navigable Small World vector search tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

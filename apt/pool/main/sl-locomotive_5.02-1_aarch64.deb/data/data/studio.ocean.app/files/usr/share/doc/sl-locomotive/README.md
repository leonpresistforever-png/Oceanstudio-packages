# sl-locomotive

steam locomotive terminal animation for ls typos

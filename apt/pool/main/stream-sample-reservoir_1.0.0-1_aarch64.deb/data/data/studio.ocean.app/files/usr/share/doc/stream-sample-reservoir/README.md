# stream-sample-reservoir

Reservoir Sampling Algorithm R streaming uniform sample

## Description
Data stream transformation and ETL pipeline tool providing Reservoir Sampling Algorithm R streaming uniform sample for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# rootkit-symbol-search

kernel hooking and sys_call_table address inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

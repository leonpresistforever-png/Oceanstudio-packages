# iperf-bandwidth-tester

TCP and UDP throughput and bandwidth rate benchmark

## Description
Low-level network protocol and socket diagnostics utility providing TCP and UDP throughput and bandwidth rate benchmark for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

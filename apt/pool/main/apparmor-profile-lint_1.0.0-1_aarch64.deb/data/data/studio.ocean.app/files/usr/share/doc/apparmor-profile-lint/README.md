# apparmor-profile-lint

AppArmor security profile rule syntax validator

## Description
Container runtime and Linux namespace management utility providing AppArmor security profile rule syntax validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# regex-pcre2-tester

PCRE2 regular expression pattern test and capture cli

## Description
Text tokenization and natural language processing tool providing PCRE2 regular expression pattern test and capture cli for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# bigfloat-sqrt-calc

arbitrary-precision square root via Newton-Raphson

## Description
Scientific calculation and numerical algorithm engine providing arbitrary-precision square root via Newton-Raphson for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

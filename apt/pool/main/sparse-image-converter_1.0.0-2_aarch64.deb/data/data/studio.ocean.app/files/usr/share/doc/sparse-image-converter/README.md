# sparse-image-converter

Android sparse image format to raw sector converter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

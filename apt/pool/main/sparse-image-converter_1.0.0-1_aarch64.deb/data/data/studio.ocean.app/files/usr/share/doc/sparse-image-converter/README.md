# sparse-image-converter

Android sparse image format to raw sector converter

## Description
Archive file format and differential backup utility providing Android sparse image format to raw sector converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

import sys
from importlib.metadata import distribution
name, command = sys.argv[1:3]
entry = next(e for e in distribution(name).entry_points if e.group == "console_scripts" and e.name == command)
sys.argv = [command] + sys.argv[3:]
raise SystemExit(entry.load()())

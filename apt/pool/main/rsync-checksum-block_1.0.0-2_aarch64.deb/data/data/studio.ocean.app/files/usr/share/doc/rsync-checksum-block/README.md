# rsync-checksum-block

rsync rolling checksum and MD4/MD5 block calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

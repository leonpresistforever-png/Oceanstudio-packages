# image-dimension-probe

fast zero-decode image dimension and format detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

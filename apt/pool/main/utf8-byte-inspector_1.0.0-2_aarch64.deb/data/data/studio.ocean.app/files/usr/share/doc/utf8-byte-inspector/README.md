# utf8-byte-inspector

UTF-8 multi-byte encoding sequence boundary validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# keymaster-tag-parser

Android KeyMaster/KeyMint authorization tag decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

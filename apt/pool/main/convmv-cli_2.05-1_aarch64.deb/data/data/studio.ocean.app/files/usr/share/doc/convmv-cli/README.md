# convmv-cli

convert filenames between diverse character encodings

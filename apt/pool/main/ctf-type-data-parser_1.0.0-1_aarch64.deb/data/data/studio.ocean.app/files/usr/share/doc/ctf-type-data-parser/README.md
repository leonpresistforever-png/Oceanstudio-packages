# ctf-type-data-parser

Compact C Type Format header and type table viewer

## Description
Binary analysis and compilation toolchain helper providing Compact C Type Format header and type table viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

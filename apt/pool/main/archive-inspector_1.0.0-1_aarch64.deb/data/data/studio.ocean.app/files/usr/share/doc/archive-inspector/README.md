# archive-inspector

detect archive types and inspect contents safely

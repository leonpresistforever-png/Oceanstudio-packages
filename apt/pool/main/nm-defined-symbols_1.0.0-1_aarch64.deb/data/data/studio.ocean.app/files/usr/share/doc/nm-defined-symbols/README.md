# nm-defined-symbols

ELF exported symbol definitions and binding viewer

## Description
Binary analysis and compilation toolchain helper providing ELF exported symbol definitions and binding viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

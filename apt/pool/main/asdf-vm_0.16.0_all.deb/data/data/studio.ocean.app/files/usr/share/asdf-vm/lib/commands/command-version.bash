# -*- sh -*-
asdf_version

#!/data/data/studio.ocean.app/files/usr/bin/sh
export LD_PRELOAD=/data/data/studio.ocean.app/files/usr/lib/libocean-exec.so:$LD_PRELOAD

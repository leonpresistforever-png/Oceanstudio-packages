# jpeg-progressive-chk

progressive vs baseline JPEG scan order detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

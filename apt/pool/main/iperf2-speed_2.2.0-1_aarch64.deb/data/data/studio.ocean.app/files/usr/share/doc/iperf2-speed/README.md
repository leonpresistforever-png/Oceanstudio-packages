# iperf2-speed

maximum TCP/UDP bandwidth performance tester

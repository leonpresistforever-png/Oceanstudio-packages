# redis-resp-decoder

Redis RESP protocol parser and JSON translator

## Description
Embedded database and SQL processing engine providing Redis RESP protocol parser and JSON translator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

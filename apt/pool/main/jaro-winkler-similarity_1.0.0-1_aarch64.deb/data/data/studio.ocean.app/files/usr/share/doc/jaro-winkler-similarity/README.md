# jaro-winkler-similarity

Jaro-Winkler string similarity distance metric tool

## Description
Text tokenization and natural language processing tool providing Jaro-Winkler string similarity distance metric tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# ble-gatt-uuid-lookup

Bluetooth Low Energy 16-bit and 128-bit UUID database

## Description
Embedded firmware and hardware diagnostics tool providing Bluetooth Low Energy 16-bit and 128-bit UUID database for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

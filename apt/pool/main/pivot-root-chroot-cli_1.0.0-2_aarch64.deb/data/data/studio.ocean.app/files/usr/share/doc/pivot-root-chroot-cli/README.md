# pivot-root-chroot-cli

atomic pivot_root root filesystem switching helper

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

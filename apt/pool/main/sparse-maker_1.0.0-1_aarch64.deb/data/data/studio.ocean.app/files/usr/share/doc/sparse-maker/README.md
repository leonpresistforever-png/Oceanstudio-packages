# sparse-maker

convert files with zero runs to sparse files

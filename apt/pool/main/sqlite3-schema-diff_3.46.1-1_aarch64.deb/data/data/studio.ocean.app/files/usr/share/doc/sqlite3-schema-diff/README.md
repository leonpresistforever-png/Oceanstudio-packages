# sqlite3-schema-diff

compare database schemas of two SQLite databases

# todo-fixme-collector

TODO FIXME HACK XXX code annotation parser and reporter

## Description
Static analysis and source code auditing utility providing TODO FIXME HACK XXX code annotation parser and reporter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

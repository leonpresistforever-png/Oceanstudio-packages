# steganography-tool

carrier file LSB payload detection and extractor

## Description
Cryptographic engine and secret management utility providing carrier file LSB payload detection and extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

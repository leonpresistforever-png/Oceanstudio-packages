# frontmatter-extractor

YAML TOML JSON document frontmatter header extractor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# bidi-text-reverser

bidirectional Unicode text ordering visualizer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

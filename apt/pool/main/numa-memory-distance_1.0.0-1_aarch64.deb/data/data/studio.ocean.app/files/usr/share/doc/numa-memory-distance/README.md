# numa-memory-distance

NUMA node relative access distance matrix calculator

## Description
Performance profiling and microbenchmark utility providing NUMA node relative access distance matrix calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# usb-descriptor-parser

USB 2.0/3.0 device configuration interface descriptor

## Description
Embedded firmware and hardware diagnostics tool providing USB 2.0/3.0 device configuration interface descriptor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

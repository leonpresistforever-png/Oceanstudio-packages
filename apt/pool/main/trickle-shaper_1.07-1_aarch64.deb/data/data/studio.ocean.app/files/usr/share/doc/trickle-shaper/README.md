# trickle-shaper

portable lightweight userspace bandwidth shaper

# x509-cert-inspector

decode and inspect X.509 certificate fields and extensions

# bionic-pthread-key-chk

Bionic C library pthread_key_create limit analyzer

## Description
Android Bionic and runtime platform utility providing Bionic C library pthread_key_create limit analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

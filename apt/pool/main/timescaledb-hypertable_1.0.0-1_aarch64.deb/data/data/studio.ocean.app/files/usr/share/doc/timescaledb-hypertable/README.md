# timescaledb-hypertable

time-series database hypertable chunk size calculator

## Description
Embedded database and SQL processing engine providing time-series database hypertable chunk size calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

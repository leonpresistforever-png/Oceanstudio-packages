# curl-time-formatter

cURL timing breakdown DNS connect TLS and TTFB parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# regex-pcre2-tester

PCRE2 regular expression pattern test and capture cli
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard13_text.py
Source SHA256: 2bd0ab93bcb787675068bb64980f78f0f8fc01aa479f77f8d9edc9874076ce70
Shared runtime package: ocean-runtime-shard13-text

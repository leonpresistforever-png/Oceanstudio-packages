set(RESOLV_WRAPPER_LIBRARY /data/data/studio.ocean.app/files/usr/lib/libresolv_wrapper.so)

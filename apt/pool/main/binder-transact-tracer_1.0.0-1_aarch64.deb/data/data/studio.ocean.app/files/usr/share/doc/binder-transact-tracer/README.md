# binder-transact-tracer

Android Binder IPC transaction code and interface view

## Description
Android Bionic and runtime platform utility providing Android Binder IPC transaction code and interface view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

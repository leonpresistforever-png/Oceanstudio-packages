# epoll-latency-bench

Linux epoll_wait event readiness turnaround benchmark

## Description
Performance profiling and microbenchmark utility providing Linux epoll_wait event readiness turnaround benchmark for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

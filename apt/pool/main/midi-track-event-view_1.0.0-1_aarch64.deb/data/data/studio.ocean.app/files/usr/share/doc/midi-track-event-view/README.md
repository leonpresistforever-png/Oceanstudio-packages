# midi-track-event-view

Standard MIDI File MThd MTrk delta time event parser

## Description
Media header parser and audiovisual engineering utility providing Standard MIDI File MThd MTrk delta time event parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# xar-xml-toc-extractor

eXtensible ARchive XAR XML Table of Contents tool

## Description
Archive file format and differential backup utility providing eXtensible ARchive XAR XML Table of Contents tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# check-nx-stack

verify non-executable stack GNU_STACK segment in ELF

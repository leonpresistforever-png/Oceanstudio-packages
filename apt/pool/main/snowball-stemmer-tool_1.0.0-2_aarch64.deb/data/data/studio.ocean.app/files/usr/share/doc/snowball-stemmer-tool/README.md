# snowball-stemmer-tool

Snowball multilingual algorithmic word stemmer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

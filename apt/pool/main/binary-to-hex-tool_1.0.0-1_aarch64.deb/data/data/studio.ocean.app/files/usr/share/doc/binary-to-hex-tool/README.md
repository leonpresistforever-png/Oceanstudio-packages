# binary-to-hex-tool

convert binary byte stream into formatted hex string

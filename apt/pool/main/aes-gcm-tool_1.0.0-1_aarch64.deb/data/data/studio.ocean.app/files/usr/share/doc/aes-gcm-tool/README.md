# aes-gcm-tool

AES-256 authenticated encryption utility

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

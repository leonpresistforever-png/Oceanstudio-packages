# js-ast-syntax-checker

ECMAScript/JavaScript syntax and strict mode linter

## Description
Static analysis and source code auditing utility providing ECMAScript/JavaScript syntax and strict mode linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

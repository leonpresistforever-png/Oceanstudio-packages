# student-t-distribution

Student t-distribution two-tailed p-value evaluator

## Description
Scientific calculation and numerical algorithm engine providing Student t-distribution two-tailed p-value evaluator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

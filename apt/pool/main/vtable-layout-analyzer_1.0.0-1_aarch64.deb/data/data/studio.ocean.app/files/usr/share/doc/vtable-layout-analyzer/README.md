# vtable-layout-analyzer

C++ virtual method table pointer layout analyzer

## Description
Binary analysis and compilation toolchain helper providing C++ virtual method table pointer layout analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# http-headers-security-audit

HTTP response headers comprehensive security policy auditor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

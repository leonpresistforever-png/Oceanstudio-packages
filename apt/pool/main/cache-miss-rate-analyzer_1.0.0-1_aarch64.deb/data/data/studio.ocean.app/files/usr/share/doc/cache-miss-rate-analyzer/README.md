# cache-miss-rate-analyzer

L1 L2 L3 data cache miss rate percentage calculator

## Description
Performance profiling and microbenchmark utility providing L1 L2 L3 data cache miss rate percentage calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

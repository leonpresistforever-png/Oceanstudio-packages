# code-cave-finder-elf

ELF executable section padding code cave detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

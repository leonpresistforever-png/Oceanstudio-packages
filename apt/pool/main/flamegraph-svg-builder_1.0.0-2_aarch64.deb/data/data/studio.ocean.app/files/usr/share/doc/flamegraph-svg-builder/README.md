# flamegraph-svg-builder

collapsed stack traces to interactive SVG Flame Graph

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

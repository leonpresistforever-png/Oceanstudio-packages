# thread-pool-saturation

thread pool queue length and worker utilization meter

## Description
Performance profiling and microbenchmark utility providing thread pool queue length and worker utilization meter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

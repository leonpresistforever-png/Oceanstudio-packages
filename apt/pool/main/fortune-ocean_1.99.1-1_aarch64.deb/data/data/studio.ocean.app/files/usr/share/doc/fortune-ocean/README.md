# fortune-ocean

fortune cookie quotes database and reader

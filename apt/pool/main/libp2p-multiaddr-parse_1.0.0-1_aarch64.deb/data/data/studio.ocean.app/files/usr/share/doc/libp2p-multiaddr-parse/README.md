# libp2p-multiaddr-parse

libp2p multiaddr protocol stack string parser

## Description
Distributed systems consensus and P2P protocol utility providing libp2p multiaddr protocol stack string parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

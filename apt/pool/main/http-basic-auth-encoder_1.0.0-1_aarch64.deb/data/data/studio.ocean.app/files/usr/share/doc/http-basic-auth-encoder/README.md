# http-basic-auth-encoder

RFC 7617 HTTP Basic authentication header generator

## Description
API schema validation and protocol contract engine providing RFC 7617 HTTP Basic authentication header generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

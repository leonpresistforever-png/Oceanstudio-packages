# file-entropy

calculate Shannon entropy of file contents

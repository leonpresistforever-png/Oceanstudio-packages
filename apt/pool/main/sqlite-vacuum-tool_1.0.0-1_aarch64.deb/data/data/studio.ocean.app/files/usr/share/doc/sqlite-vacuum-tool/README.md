# sqlite-vacuum-tool

vacuum, optimize and defragment SQLite database files

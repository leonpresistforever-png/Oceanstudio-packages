# apk-asset-auditor

audit uncompressed vs compressed assets in Android packages

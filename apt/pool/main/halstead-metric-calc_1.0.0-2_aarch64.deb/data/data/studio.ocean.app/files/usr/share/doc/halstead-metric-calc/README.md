# halstead-metric-calc

Halstead software science vocabulary and volume metric

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

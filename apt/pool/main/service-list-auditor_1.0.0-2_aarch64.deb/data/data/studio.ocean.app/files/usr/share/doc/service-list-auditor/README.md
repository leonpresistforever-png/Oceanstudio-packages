# service-list-auditor

Android ServiceManager registered IBinder service audit

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# rsync-rolling-hash

Adler-32 inspired rsync fast sliding window hash

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

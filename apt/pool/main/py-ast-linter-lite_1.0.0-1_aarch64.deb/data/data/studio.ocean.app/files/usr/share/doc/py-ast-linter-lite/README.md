# py-ast-linter-lite

Python abstract syntax tree syntax and safety checker

## Description
Static analysis and source code auditing utility providing Python abstract syntax tree syntax and safety checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# shadow-password-audit

/etc/shadow weak password hash algorithm auditor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

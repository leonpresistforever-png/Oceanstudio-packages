# sevenzip-signature-chk

7z archive 7z\xBC\xAF\x27\x1C signature and version tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

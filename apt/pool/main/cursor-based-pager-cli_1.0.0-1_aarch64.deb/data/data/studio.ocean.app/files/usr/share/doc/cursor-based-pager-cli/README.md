# cursor-based-pager-cli

opaque base64 cursor pagination token generator

## Description
API schema validation and protocol contract engine providing opaque base64 cursor pagination token generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

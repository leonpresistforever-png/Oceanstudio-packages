# cpio-newc-header-chk

cpio SVR4 new ASCII format header validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

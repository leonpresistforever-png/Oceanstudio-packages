# dir-checksum

recursive directory tree content hash generator

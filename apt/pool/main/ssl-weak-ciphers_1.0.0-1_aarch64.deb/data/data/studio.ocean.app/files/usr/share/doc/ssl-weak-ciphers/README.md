# ssl-weak-ciphers

detect weak SSL/TLS ciphers like RC4, DES and export ciphers

# dns-mx-priority-sorter

Mail Exchanger DNS record preference validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# perf-script-filter-cli

perf script trace output stack frame symbol filter

## Description
Performance profiling and microbenchmark utility providing perf script trace output stack frame symbol filter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

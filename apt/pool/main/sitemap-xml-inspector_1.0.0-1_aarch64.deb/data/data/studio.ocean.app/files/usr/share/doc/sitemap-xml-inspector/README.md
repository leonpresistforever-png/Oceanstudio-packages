# sitemap-xml-inspector

XML Sitemap 0.9 urlset and sitemapindex validator

## Description
API schema validation and protocol contract engine providing XML Sitemap 0.9 urlset and sitemapindex validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# moreutils-mispipe

pipe two commands together returning exit code of first

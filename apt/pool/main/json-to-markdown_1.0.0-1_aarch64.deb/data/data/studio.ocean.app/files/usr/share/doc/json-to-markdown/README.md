# json-to-markdown

convert JSON arrays of objects into Markdown tables

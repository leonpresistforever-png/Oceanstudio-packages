# recovery-fstab-parser

Android recovery.fstab block device mount points view

## Description
Android Bionic and runtime platform utility providing Android recovery.fstab block device mount points view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# process-fd-auditor

audit open file descriptors and socket handles for local processes

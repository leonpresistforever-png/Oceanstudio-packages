# age-encryption-tool

simple modern and secure file encryption tool

## Description
Cryptographic engine and secret management utility providing simple modern and secure file encryption tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

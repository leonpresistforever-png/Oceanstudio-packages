# broken-symlink-clean

dangling and broken symbolic link locator

## Description
Filesystem analysis and storage engineering utility providing dangling and broken symbolic link locator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

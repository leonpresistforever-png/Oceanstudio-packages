# json-schema-draft2020

JSON Schema Draft 2020-12 dialect validator

## Description
API schema validation and protocol contract engine providing JSON Schema Draft 2020-12 dialect validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

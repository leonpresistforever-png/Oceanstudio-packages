# fdt-node-path-search

Device Tree node search by phandle and alias path

## Description
Embedded firmware and hardware diagnostics tool providing Device Tree node search by phandle and alias path for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# license-spdx-checker

SPDX-License-Identifier expression syntax validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

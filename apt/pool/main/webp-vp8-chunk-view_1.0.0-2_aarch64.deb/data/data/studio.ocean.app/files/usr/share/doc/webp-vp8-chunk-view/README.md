# webp-vp8-chunk-view

WebP RIFF container VP8 VP8L VP8X chunk reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

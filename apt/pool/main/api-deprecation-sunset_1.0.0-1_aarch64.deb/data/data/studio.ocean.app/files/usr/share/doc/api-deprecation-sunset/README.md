# api-deprecation-sunset

RFC 8594 Sunset and Deprecation HTTP header validator

## Description
API schema validation and protocol contract engine providing RFC 8594 Sunset and Deprecation HTTP header validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

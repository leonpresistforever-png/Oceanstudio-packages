# license-compatibility

open-source software license compatibility matrix tool

## Description
Static analysis and source code auditing utility providing open-source software license compatibility matrix tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# hex-dump-formatter

format binary files into canonical hex dump representation

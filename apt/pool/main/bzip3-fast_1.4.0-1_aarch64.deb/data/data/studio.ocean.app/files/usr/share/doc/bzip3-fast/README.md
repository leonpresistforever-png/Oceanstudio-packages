# bzip3-fast

better and faster alternative to bzip2

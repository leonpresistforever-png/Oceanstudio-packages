# subuid-subgid-parser

/etc/subuid and /etc/subgid range collision detector

## Description
Container runtime and Linux namespace management utility providing /etc/subuid and /etc/subgid range collision detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

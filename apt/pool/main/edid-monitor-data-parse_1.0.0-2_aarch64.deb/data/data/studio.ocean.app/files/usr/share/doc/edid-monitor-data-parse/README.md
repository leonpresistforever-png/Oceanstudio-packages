# edid-monitor-data-parse

VESA Extended Display Identification Data EDID tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

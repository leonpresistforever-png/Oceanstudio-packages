# fluentd-event-builder

Fluentd forward protocol event message builder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

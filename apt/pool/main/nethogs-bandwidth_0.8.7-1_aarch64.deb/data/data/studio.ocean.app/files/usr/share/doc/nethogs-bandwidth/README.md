# nethogs-bandwidth

group bandwidth by process on local interface

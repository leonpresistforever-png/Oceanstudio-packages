# crl-revocation-checker

download and check Certificate Revocation Lists for revoked serials

# fail2ban-regex-tester

fail2ban jail failregex regular expression test tool

This package is part of OceanStudio's repaired functional shard 27.
Unlike the earlier placeholder build, this version executes real data-processing logic.

Version: 1.0.0-2
Runtime: Python standard library only
Prefix: /data/data/studio.ocean.app/files/usr

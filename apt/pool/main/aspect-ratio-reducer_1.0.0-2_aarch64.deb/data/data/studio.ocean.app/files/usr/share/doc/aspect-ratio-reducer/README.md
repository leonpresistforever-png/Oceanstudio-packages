# aspect-ratio-reducer

screen resolution to simplified aspect ratio reducer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

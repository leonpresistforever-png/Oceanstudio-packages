# uninitialized-var-chk

uninitialized stack variable read heuristic scanner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

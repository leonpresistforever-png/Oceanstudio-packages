# jwt-decoder-cli

JSON Web Token (JWT) inspection and payload decoder CLI

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# jwt-decoder-cli

JSON Web Token header payload and claims decoder

## Description
Cryptographic engine and secret management utility providing JSON Web Token header payload and claims decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# manpage-troff-linter

UNIX manual page groff man macro syntax validator

## Description
Text tokenization and natural language processing tool providing UNIX manual page groff man macro syntax validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

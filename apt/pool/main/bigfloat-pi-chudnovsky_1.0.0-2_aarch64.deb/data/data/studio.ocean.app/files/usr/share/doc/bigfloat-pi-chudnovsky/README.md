# bigfloat-pi-chudnovsky

Chudnovsky algorithm arbitrary precision Pi generator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

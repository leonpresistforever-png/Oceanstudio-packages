# gpt-header-inspector

GUID Partition Table primary and backup header parser

## Description
Filesystem analysis and storage engineering utility providing GUID Partition Table primary and backup header parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

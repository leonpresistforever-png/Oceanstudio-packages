# png-crush-optimizer

lossless PNG deflation filter strategy evaluator

## Description
Media header parser and audiovisual engineering utility providing lossless PNG deflation filter strategy evaluator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dnstracer-path

trace DNS queries to authoritative root nameservers

# chi-square-statistic

Chi-square goodness-of-fit contingency test tool

## Description
Scientific calculation and numerical algorithm engine providing Chi-square goodness-of-fit contingency test tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# spinlock-cycles-wasted

userspace spinlock CPU pause instruction cycles spent

## Description
Performance profiling and microbenchmark utility providing userspace spinlock CPU pause instruction cycles spent for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

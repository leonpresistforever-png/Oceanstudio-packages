# dumpsys-meminfo-parse

dumpsys meminfo native dalvik graphics heap analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

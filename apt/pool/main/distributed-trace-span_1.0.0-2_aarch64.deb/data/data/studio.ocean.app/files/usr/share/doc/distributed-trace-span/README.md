# distributed-trace-span

OpenTelemetry distributed trace span ID validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

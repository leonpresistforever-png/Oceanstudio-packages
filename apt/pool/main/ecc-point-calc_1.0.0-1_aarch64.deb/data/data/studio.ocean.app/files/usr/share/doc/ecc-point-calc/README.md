# ecc-point-calc

Elliptic Curve Cryptography point arithmetic calculator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

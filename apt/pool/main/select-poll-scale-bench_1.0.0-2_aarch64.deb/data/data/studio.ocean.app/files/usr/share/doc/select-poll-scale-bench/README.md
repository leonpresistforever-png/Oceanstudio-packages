# select-poll-scale-bench

POSIX select and poll descriptor scalability tester

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

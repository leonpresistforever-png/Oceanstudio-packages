# email-spf-verifier

query and validate Sender Policy Framework DNS records

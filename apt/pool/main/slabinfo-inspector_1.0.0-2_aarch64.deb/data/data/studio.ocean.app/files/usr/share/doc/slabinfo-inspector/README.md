# slabinfo-inspector

kernel slab cache object count and memory viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# itanium-demangler

Itanium ABI C++ ABI mangling parser and formatter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

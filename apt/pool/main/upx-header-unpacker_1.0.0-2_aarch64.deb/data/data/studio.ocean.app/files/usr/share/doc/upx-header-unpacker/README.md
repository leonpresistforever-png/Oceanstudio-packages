# upx-header-unpacker

UPX compressed executable header and magic inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

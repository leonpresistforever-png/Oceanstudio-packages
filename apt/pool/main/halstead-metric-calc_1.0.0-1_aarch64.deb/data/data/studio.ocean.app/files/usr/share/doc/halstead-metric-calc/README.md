# halstead-metric-calc

Halstead software science vocabulary and volume metric

## Description
Static analysis and source code auditing utility providing Halstead software science vocabulary and volume metric for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# http-bench-fast

lightweight HTTP benchmark and throughput measuring tool

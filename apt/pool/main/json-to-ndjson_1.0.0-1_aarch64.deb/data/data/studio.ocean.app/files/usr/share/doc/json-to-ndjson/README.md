# json-to-ndjson

convert JSON array into newline-delimited JSON stream

# dns-record-lookup

DNS A AAAA CNAME query client and resolver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

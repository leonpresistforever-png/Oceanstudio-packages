# poly1305-auth

Poly1305 one-time authenticator message authentication

## Description
Cryptographic engine and secret management utility providing Poly1305 one-time authenticator message authentication for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

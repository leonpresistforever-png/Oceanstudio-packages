# poly1305-auth

Poly1305 one-time authenticator MAC generator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

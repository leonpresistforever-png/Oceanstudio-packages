# mongodb-extended-json

MongoDB Extended JSON v2 format to standard JSON tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

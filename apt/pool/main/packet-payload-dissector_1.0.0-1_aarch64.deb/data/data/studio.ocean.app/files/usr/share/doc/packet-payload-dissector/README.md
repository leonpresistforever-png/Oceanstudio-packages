# packet-payload-dissector

network packet hexadecimal payload dissector and analyzer

## Description
Low-level network protocol and socket diagnostics utility providing network packet hexadecimal payload dissector and analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

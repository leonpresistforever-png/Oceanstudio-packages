# mqtt-packet-decoder

MQTT v3.1.1/v5.0 fixed header and packet decoder

## Description
DevOps workflow and microservice coordination utility providing MQTT v3.1.1/v5.0 fixed header and packet decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

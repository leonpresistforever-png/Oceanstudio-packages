# sqlite-table-sizes

SQLite database per-table disk space usage analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

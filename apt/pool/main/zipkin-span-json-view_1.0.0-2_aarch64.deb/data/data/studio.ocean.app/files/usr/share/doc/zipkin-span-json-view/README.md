# zipkin-span-json-view

Zipkin v2 HTTP span duration and annotation reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

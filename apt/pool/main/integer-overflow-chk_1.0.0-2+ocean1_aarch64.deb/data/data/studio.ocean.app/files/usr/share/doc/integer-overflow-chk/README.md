# integer-overflow-chk

signed integer arithmetic overflow heuristic detector
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard18_analysis.py
Source SHA256: ae3c220d00fc983b9a6a4b488103b9ca4b768885c9fa650e633e807bdd7499a7
Shared runtime package: ocean-runtime-shard18-analysis

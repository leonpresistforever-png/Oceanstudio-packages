# dpi-calculator-cli

display dots-per-inch and physical screen dimension calc

## Description
Media header parser and audiovisual engineering utility providing display dots-per-inch and physical screen dimension calc for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

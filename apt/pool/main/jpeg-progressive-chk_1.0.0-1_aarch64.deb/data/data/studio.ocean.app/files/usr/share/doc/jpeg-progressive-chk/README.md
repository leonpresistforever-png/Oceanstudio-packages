# jpeg-progressive-chk

progressive vs baseline JPEG scan order detector

## Description
Media header parser and audiovisual engineering utility providing progressive vs baseline JPEG scan order detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

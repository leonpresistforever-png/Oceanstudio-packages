# crdt-lww-register

Last-Write-Wins CRDT Register timestamp reconciler

## Description
Distributed systems consensus and P2P protocol utility providing Last-Write-Wins CRDT Register timestamp reconciler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

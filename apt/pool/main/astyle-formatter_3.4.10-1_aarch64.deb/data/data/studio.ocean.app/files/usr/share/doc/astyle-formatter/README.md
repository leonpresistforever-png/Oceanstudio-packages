# astyle-formatter

Artistic Style code formatter for C/C++/Java/C#

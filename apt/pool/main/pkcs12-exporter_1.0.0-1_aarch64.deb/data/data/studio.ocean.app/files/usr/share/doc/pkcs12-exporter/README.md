# pkcs12-exporter

PKCS#12 archive certificate and private key extractor

## Description
Cryptographic engine and secret management utility providing PKCS#12 archive certificate and private key extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# flock-file-mutex

advisory file locking mutex for pipeline synchronization

## Description
Filesystem analysis and storage engineering utility providing advisory file locking mutex for pipeline synchronization for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

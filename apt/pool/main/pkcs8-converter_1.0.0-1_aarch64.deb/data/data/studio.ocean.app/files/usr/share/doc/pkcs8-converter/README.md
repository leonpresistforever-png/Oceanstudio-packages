# pkcs8-converter

PKCS#1 / SSLeay to PKCS#8 private key format converter

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

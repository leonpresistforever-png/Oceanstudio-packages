# fuse-overlayfs-helper

unprivileged userspace FUSE OverlayFS helper tool

## Description
Container runtime and Linux namespace management utility providing unprivileged userspace FUSE OverlayFS helper tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

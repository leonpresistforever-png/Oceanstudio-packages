# nor-flash-sector-align

NOR flash sector erase boundary alignment validator

## Description
Embedded firmware and hardware diagnostics tool providing NOR flash sector erase boundary alignment validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

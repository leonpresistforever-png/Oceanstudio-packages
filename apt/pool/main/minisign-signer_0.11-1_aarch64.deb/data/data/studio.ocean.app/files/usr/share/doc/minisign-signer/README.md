# minisign-signer

Lightweight Ed25519 signature generator and verifier

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# structure-padding-calc

data structure memory layout and hole visualizer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

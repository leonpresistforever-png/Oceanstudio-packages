# btf-kernel-type-dump

BPF Type Format v1 header and type record analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

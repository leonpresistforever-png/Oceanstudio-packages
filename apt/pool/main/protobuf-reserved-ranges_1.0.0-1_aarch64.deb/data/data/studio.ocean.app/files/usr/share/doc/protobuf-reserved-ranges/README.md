# protobuf-reserved-ranges

Protobuf reserved tag numbers and names conflict audit

## Description
API schema validation and protocol contract engine providing Protobuf reserved tag numbers and names conflict audit for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# tar-pax-extended-chk

POSIX.1-2001 pax extended header attribute parser

## Description
Archive file format and differential backup utility providing POSIX.1-2001 pax extended header attribute parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

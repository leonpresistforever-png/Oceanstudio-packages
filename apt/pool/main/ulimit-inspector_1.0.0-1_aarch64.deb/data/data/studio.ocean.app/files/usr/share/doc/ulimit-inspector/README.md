# ulimit-inspector

POSIX shell process resource limits reporter

## Description
Linux procfs and system diagnostic utility providing POSIX shell process resource limits reporter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

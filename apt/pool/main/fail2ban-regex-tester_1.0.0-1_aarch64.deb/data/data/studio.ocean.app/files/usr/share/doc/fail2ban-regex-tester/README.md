# fail2ban-regex-tester

fail2ban jail failregex regular expression test tool

## Description
Data stream transformation and ETL pipeline tool providing fail2ban jail failregex regular expression test tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

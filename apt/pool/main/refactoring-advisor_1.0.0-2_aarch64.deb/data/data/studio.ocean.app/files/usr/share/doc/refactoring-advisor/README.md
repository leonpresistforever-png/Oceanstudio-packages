# refactoring-advisor

code smell detection and automated refactor advisor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

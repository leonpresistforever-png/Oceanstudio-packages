# ssl-tls-poodle-tester

TLS CBC mode padding oracle POODLE vulnerability test

## Description
Security forensic analysis and incident response tool providing TLS CBC mode padding oracle POODLE vulnerability test for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

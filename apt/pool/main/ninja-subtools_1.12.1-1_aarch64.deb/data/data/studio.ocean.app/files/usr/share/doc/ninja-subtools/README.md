# ninja-subtools

helper utilities for Ninja build graph inspection

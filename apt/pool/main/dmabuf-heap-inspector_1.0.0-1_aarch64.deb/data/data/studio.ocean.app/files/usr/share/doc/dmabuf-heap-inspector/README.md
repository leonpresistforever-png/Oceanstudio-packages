# dmabuf-heap-inspector

Linux dma-buf heap allocations and buffer sharing tool

## Description
Android Bionic and runtime platform utility providing Linux dma-buf heap allocations and buffer sharing tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# statm-resident-calc

process memory pages resident shared text breakdown

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# chi-square-statistic

Chi-square goodness-of-fit contingency test tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# gpio-sysfs-pin-export

Linux legacy GPIO sysfs pin direction value helper

## Description
Embedded firmware and hardware diagnostics tool providing Linux legacy GPIO sysfs pin direction value helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

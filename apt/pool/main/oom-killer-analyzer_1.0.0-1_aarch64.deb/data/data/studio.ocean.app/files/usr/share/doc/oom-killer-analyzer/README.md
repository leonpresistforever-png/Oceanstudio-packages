# oom-killer-analyzer

historical kernel OOM invocation log analyzer

## Description
Linux procfs and system diagnostic utility providing historical kernel OOM invocation log analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# canary-traffic-calc

canary release traffic splitting percentage calculator

## Description
DevOps workflow and microservice coordination utility providing canary release traffic splitting percentage calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

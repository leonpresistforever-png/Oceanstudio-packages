# duckdb-query-runner

analytical columnar SQL database CLI runner

## Description
Embedded database and SQL processing engine providing analytical columnar SQL database CLI runner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

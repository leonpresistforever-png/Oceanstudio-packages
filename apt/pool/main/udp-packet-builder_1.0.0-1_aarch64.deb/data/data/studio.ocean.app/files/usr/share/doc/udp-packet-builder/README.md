# udp-packet-builder

UDP datagram length and checksum verification tool

## Description
Low-level network protocol and socket diagnostics utility providing UDP datagram length and checksum verification tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

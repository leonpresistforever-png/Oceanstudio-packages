# http-ping-bench

HTTP/1.1 endpoint round-trip latency benchmark

## Description
Low-level network protocol and socket diagnostics utility providing HTTP/1.1 endpoint round-trip latency benchmark for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

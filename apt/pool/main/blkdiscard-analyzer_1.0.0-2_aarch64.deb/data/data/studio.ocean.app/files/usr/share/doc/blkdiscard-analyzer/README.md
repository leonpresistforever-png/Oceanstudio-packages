# blkdiscard-analyzer

block device TRIM and discard support tester

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

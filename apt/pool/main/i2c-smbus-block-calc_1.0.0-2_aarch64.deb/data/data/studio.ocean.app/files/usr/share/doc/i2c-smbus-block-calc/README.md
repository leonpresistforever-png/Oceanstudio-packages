# i2c-smbus-block-calc

SMBus Packet Error Checking PEC CRC-8 calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

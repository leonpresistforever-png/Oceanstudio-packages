# covariance-matrix-cli

multivariate dataset covariance matrix calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

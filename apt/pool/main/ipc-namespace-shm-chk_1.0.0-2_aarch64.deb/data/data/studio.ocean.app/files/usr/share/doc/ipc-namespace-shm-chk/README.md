# ipc-namespace-shm-chk

IPC namespace System V and POSIX shared memory view

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

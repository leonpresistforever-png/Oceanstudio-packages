# curve25519-keygen

X25519 Diffie-Hellman key exchange utility

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

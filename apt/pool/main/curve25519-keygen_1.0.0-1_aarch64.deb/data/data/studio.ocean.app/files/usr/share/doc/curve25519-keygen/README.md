# curve25519-keygen

Montgomery curve Curve25519 key exchange helper

## Description
Cryptographic engine and secret management utility providing Montgomery curve Curve25519 key exchange helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

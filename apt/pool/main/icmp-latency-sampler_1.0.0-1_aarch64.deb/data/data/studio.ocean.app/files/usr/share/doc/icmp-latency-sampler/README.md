# icmp-latency-sampler

ICMP echo request round-trip latency sampler

## Description
Low-level network protocol and socket diagnostics utility providing ICMP echo request round-trip latency sampler for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

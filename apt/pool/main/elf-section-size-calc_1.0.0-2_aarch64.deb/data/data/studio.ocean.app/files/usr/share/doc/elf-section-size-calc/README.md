# elf-section-size-calc

ELF section header table size and alignment auditor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# bit-manipulator-cli

perform bitwise AND, OR, XOR and NOT operations on streams

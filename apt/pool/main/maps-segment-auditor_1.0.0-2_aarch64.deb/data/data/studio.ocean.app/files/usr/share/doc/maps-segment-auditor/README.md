# maps-segment-auditor

ELF virtual address space segment permission auditor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# shake256-tool

extendable-output function SHAKE256 hasher

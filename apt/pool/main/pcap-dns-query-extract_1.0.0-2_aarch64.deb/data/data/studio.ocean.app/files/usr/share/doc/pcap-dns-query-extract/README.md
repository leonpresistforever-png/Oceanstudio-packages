# pcap-dns-query-extract

extract DNS query questions and replies from PCAP files

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# signal-to-noise-ratio

Signal-to-Noise Ratio and decibel power calculator

## Description
Scientific calculation and numerical algorithm engine providing Signal-to-Noise Ratio and decibel power calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

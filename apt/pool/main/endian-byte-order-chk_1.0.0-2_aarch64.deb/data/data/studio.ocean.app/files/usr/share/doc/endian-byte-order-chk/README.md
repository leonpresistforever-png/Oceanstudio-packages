# endian-byte-order-chk

binary integer endianness byte-swap validation tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

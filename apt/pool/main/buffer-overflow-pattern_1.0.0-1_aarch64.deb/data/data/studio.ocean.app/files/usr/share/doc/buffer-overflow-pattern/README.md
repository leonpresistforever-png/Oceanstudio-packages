# buffer-overflow-pattern

unsafe C standard library strcpy sprintf pattern finder

## Description
Static analysis and source code auditing utility providing unsafe C standard library strcpy sprintf pattern finder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

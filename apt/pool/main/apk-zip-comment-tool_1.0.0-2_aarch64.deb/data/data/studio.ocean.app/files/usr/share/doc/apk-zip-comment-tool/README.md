# apk-zip-comment-tool

Android APK End of Central Directory comment reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

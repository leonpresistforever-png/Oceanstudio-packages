# fd-leak-detector

process open file descriptor growth rate analyzer

## Description
Linux procfs and system diagnostic utility providing process open file descriptor growth rate analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

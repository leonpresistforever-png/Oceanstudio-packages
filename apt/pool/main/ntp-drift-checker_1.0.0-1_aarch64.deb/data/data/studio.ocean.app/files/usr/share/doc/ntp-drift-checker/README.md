# ntp-drift-checker

query NTP servers to calculate local clock offset

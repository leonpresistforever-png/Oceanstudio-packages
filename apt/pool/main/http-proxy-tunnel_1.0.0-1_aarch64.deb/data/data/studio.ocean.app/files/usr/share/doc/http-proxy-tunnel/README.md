# http-proxy-tunnel

HTTP CONNECT tunneling proxy test utility

## Description
Low-level network protocol and socket diagnostics utility providing HTTP CONNECT tunneling proxy test utility for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

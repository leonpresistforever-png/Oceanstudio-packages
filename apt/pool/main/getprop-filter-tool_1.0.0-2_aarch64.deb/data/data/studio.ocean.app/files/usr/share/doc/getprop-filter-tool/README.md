# getprop-filter-tool

Android system properties key filtering and JSON dump

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

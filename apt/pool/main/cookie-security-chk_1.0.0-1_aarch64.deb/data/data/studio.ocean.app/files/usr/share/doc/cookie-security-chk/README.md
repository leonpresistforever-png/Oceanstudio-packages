# cookie-security-chk

verify Secure, HttpOnly, and SameSite flags on HTTP cookies

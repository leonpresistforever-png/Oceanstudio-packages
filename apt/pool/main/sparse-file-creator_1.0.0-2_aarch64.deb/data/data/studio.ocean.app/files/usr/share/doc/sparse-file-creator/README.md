# sparse-file-creator

POSIX sparse file generator with arbitrary hole sizes

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

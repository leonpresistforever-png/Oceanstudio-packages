# ashmem-region-auditor

Android Anonymous Shared Memory ashmem size inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

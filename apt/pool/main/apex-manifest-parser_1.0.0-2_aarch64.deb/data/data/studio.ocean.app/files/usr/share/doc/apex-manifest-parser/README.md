# apex-manifest-parser

Android APEX container apex_manifest.json/pb parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# moreutils-combine

combine sets of lines from two files using boolean operations

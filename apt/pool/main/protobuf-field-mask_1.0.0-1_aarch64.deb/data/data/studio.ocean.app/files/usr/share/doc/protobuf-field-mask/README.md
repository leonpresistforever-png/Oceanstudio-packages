# protobuf-field-mask

Protocol Buffers FieldMask path validator

## Description
DevOps workflow and microservice coordination utility providing Protocol Buffers FieldMask path validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

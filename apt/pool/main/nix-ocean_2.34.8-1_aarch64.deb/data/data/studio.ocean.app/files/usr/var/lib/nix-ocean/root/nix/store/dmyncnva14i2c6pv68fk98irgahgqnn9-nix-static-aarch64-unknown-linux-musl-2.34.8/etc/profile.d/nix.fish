# Only execute this file once per shell.
if test -z "$HOME" || test -n "$__ETC_PROFILE_NIX_SOURCED"
    exit
end

set --global --export __ETC_PROFILE_NIX_SOURCED 1

# Local helpers

function add_path --argument-names new_path
    if type -q fish_add_path
        # fish 3.2.0 or newer
        fish_add_path --prepend --global $new_path
    else
        # older versions of fish
        if not contains $new_path $fish_user_paths
            set --global fish_user_paths $new_path $fish_user_paths
        end
    end
end

# Main configuration

# Set up the per-user profile.

set --local NIX_LINK
if test -n "$NIX_STATE_HOME"
    set NIX_LINK "$NIX_STATE_HOME/.nix-profile"
else
    set NIX_LINK "$HOME/.nix-profile"
    set --local NIX_LINK_NEW
    if test -n "$XDG_STATE_HOME"
        set NIX_LINK_NEW "$XDG_STATE_HOME/nix/profile"
    else
        set NIX_LINK_NEW "$HOME/.local/state/nix/profile"
    end
    if test -e "$NIX_LINK_NEW"
        if test -t 2; and test -e "$NIX_LINK"
            set --local warning "\033[1;35mwarning:\033[0m "
            printf "$warning Both %s and legacy %s exist; using the former.\n" "$NIX_LINK_NEW" "$NIX_LINK" 1>&2

            if test (realpath "$NIX_LINK") = (realpath "$NIX_LINK_NEW")
                printf "         Since the profiles match, you can safely delete either of them.\n" 1>&2
            else
                # This should be an exceptionally rare occasion: the only way to get it would be to
                # 1. Update to newer Nix;
                # 2. Remove .nix-profile;
                # 3. Set the $NIX_LINK_NEW to something other than the default user profile;
                # 4. Roll back to older Nix.
                # If someone did all that, they can probably figure out how to migrate the profile.
                printf "$warning Profiles do not match. You should manually migrate from %s to %s.\n" "$NIX_LINK" "$NIX_LINK_NEW" 1>&2
            end
        end

        set NIX_LINK "$NIX_LINK_NEW"
    end
end

# Set up environment.
# This part should be kept in sync with nixpkgs:nixos/modules/programs/environment.nix
set --export NIX_PROFILES "/nix/var/nix/profiles/default $HOME/.nix-profile"

# Populate bash completions, .desktop files, etc
if test -z "$XDG_DATA_DIRS"
    # According to XDG spec the default is /usr/local/share:/usr/share, don't set something that prevents that default
    set --export XDG_DATA_DIRS "/usr/local/share:/usr/share:$NIX_LINK/share:/nix/var/nix/profiles/default/share"
else
    set --export XDG_DATA_DIRS "$XDG_DATA_DIRS:$NIX_LINK/share:/nix/var/nix/profiles/default/share"
end

# Set $NIX_SSL_CERT_FILE so that Nixpkgs applications like curl work.
if test -n "$NIX_SSL_CERT_FILE"
    : # Allow users to override the NIX_SSL_CERT_FILE
else if test -e /etc/ssl/certs/ca-certificates.crt # NixOS, Ubuntu, Debian, Gentoo, Arch
    set --export NIX_SSL_CERT_FILE /etc/ssl/certs/ca-certificates.crt
else if test -e /etc/ssl/ca-bundle.pem # openSUSE Tumbleweed
    set --export NIX_SSL_CERT_FILE /etc/ssl/ca-bundle.pem
else if test -e /etc/ssl/certs/ca-bundle.crt # Old NixOS
    set --export NIX_SSL_CERT_FILE /etc/ssl/certs/ca-bundle.crt
else if test -e /etc/pki/tls/certs/ca-bundle.crt # Fedora, CentOS
    set --export NIX_SSL_CERT_FILE /etc/pki/tls/certs/ca-bundle.crt
else if test -e "$NIX_LINK/etc/ssl/certs/ca-bundle.crt" # fall back to cacert in Nix profile
    set --export NIX_SSL_CERT_FILE "$NIX_LINK/etc/ssl/certs/ca-bundle.crt"
else if test -e "$NIX_LINK/etc/ca-bundle.crt" # old cacert in Nix profile
    set --export NIX_SSL_CERT_FILE "$NIX_LINK/etc/ca-bundle.crt"
else
    # Fall back to what is in the nix profiles, favouring whatever is defined last.
    for i in (string split ' ' $NIX_PROFILES)
        if test -e "$i/etc/ssl/certs/ca-bundle.crt"
            set --export NIX_SSL_CERT_FILE "$i/etc/ssl/certs/ca-bundle.crt"
        end
    end
end

# Only use MANPATH if it is already set. In general `man` will just simply
# pick up `.nix-profile/share/man` because is it close to `.nix-profile/bin`
# which is in the $PATH. For more info, run `manpath -d`.
if set --query MANPATH
    set --export --prepend --path MANPATH "$NIX_LINK/share/man"
end

add_path "/nix/var/nix/profiles/default/bin"
add_path "$NIX_LINK/bin"

# Cleanup

functions -e add_path

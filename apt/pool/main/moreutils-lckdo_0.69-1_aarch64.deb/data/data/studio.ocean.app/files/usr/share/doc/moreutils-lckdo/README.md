# moreutils-lckdo

execute a program with a lock held on file

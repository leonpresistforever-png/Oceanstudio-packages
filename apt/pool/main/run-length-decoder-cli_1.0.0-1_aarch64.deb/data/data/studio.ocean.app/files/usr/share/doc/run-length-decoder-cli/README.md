# run-length-decoder-cli

Run-Length Encoded byte stream decompressor

## Description
Data stream transformation and ETL pipeline tool providing Run-Length Encoded byte stream decompressor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# ndjson-sort-by-key

streaming newline-delimited JSON sorting by field value

## Description
Data stream transformation and ETL pipeline tool providing streaming newline-delimited JSON sorting by field value for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

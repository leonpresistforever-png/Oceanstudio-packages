# empty-dir-pruner

recursive empty directory finder and cleanup tool

## Description
Filesystem analysis and storage engineering utility providing recursive empty directory finder and cleanup tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

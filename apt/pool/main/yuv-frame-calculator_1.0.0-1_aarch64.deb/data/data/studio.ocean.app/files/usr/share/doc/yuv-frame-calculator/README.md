# yuv-frame-calculator

raw YUV 4:2:0 planar frame buffer size calculator

## Description
Media header parser and audiovisual engineering utility providing raw YUV 4:2:0 planar frame buffer size calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

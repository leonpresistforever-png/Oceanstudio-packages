# db-constraint-audit

database NOT NULL UNIQUE and CHECK constraint linter

## Description
Embedded database and SQL processing engine providing database NOT NULL UNIQUE and CHECK constraint linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

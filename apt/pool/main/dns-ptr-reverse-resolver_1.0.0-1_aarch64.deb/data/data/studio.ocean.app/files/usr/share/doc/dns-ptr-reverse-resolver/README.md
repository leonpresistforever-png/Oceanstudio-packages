# dns-ptr-reverse-resolver

reverse DNS in-addr.arpa pointer record resolver

## Description
Low-level network protocol and socket diagnostics utility providing reverse DNS in-addr.arpa pointer record resolver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

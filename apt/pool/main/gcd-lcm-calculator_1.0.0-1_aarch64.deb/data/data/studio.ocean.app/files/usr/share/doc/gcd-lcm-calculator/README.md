# gcd-lcm-calculator

compute Greatest Common Divisor and Least Common Multiple

# ssl-sni-detector

Server Name Indication detector in TLS ClientHello

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

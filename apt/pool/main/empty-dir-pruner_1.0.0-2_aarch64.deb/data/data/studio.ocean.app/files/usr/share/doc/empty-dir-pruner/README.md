# empty-dir-pruner

recursive empty directory finder and cleanup tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

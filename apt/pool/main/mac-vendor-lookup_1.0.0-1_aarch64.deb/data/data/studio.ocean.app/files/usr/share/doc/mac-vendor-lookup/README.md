# mac-vendor-lookup

lookup hardware manufacturer OUI from MAC address

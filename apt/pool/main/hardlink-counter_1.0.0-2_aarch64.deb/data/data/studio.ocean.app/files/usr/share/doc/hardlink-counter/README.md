# hardlink-counter

inode link count scanner and multiple reference finder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

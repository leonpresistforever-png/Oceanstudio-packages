# metaphone-phonetic-cli

Double Metaphone English phonetic encoding utility

## Description
Text tokenization and natural language processing tool providing Double Metaphone English phonetic encoding utility for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

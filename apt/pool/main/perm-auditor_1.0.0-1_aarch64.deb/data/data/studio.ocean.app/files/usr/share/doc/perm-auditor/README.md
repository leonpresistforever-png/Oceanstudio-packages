# perm-auditor

audit file permission anomalies in Ocean prefix

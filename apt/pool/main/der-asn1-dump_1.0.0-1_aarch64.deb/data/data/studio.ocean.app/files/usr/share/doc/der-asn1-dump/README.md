# der-asn1-dump

DER/BER encoded ASN.1 structure parser and visualizer

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

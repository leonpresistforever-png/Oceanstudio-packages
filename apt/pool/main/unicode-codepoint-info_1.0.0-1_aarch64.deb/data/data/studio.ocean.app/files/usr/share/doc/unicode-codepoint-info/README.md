# unicode-codepoint-info

Unicode character property script and category lookup

## Description
Text tokenization and natural language processing tool providing Unicode character property script and category lookup for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# db-orphan-records-chk

database orphaned child row consistency detector

## Description
Embedded database and SQL processing engine providing database orphaned child row consistency detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

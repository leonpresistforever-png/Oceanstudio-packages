# apparmor-profile-lint

AppArmor security profile rule syntax validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# speed-of-sound-calc

speed of sound in dry air by temperature calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

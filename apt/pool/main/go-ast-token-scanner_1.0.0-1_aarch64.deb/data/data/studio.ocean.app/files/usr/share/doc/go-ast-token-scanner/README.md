# go-ast-token-scanner

Go source file package imports and struct field check

## Description
Static analysis and source code auditing utility providing Go source file package imports and struct field check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

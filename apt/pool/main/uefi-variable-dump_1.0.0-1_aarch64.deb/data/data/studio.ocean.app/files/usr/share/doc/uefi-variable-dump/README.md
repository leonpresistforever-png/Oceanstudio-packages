# uefi-variable-dump

UEFI NVRAM non-volatile variable data parser

## Description
Embedded firmware and hardware diagnostics tool providing UEFI NVRAM non-volatile variable data parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

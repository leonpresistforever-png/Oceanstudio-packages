# acpi-table-parser-dsdt

ACPI Differentiated System Description Table parser

## Description
Embedded firmware and hardware diagnostics tool providing ACPI Differentiated System Description Table parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

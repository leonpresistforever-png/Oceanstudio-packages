# network-interface-stat

network interface rx/tx packets and error counter

## Description
Low-level network protocol and socket diagnostics utility providing network interface rx/tx packets and error counter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

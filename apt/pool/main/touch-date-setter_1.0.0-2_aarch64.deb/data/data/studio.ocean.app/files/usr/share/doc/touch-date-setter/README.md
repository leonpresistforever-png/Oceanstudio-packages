# touch-date-setter

RFC 3339 timestamp setter for file modifications

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

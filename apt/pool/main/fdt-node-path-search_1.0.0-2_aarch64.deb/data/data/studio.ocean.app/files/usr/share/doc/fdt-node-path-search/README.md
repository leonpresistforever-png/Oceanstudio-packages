# fdt-node-path-search

Device Tree node search by phandle and alias path

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

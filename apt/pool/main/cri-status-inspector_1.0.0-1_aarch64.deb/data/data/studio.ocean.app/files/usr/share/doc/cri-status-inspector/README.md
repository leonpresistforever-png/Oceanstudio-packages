# cri-status-inspector

Container Runtime Interface gRPC status checker

## Description
Container runtime and Linux namespace management utility providing Container Runtime Interface gRPC status checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

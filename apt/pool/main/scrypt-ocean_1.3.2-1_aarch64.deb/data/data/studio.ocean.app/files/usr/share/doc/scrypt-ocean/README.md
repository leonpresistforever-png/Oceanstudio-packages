# scrypt-ocean

Password hashing and key derivation using scrypt KDF

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# cgroup-v2-freeze-state

cgroup v2 freezer cgroup.freeze process freezer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

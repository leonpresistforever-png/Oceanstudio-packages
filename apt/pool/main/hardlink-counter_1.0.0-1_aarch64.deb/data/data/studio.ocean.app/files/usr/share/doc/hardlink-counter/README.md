# hardlink-counter

inode link count scanner and multiple reference finder

## Description
Filesystem analysis and storage engineering utility providing inode link count scanner and multiple reference finder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

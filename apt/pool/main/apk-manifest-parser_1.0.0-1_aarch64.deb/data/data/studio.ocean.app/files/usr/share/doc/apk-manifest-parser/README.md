# apk-manifest-parser

decode binary AndroidManifest.xml from Android APK files

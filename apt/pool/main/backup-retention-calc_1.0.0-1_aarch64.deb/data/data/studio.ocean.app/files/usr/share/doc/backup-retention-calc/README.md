# backup-retention-calc

Grandfather-Father-Son backup retention schedule tool

## Description
Archive file format and differential backup utility providing Grandfather-Father-Son backup retention schedule tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# mtr-traceroute

traceroute and ping combined in single CLI

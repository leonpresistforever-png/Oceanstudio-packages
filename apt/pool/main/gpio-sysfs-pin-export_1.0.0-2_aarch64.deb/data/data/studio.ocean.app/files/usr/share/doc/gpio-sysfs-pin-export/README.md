# gpio-sysfs-pin-export

Linux legacy GPIO sysfs pin direction value helper

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

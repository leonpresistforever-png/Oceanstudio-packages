# dumpsys-window-parser

dumpsys window display orientation and bounds parser

## Description
Android Bionic and runtime platform utility providing dumpsys window display orientation and bounds parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# diskstats-parser

raw /proc/diskstats sector read/write metrics parser

## Description
Linux procfs and system diagnostic utility providing raw /proc/diskstats sector read/write metrics parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

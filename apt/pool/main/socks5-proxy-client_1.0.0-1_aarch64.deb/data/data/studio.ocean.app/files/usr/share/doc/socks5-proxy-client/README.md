# socks5-proxy-client

SOCKS5 proxy authentication and CONNECT tunnel client

## Description
Low-level network protocol and socket diagnostics utility providing SOCKS5 proxy authentication and CONNECT tunnel client for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

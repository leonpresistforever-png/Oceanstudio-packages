# chroot-jail-builder

minimalist chroot directory hierarchy staging tool

## Description
Container runtime and Linux namespace management utility providing minimalist chroot directory hierarchy staging tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

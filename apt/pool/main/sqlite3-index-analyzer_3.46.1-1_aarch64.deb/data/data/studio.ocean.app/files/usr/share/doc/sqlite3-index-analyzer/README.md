# sqlite3-index-analyzer

analyze index coverage and query plan performance

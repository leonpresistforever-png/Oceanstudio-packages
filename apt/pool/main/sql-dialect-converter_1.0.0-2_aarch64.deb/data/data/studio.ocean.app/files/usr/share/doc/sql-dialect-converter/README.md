# sql-dialect-converter

SQL dialect transpile helper Postgres SQLite MySQL

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

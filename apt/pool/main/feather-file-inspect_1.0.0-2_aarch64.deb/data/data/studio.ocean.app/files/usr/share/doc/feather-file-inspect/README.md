# feather-file-inspect

Feather V1/V2 binary dataframe format inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

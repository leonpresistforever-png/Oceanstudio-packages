# btf-kernel-type-dump

BPF Type Format v1 header and type record analyzer

## Description
Binary analysis and compilation toolchain helper providing BPF Type Format v1 header and type record analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

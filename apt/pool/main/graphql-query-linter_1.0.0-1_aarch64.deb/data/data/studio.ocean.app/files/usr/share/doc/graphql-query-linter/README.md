# graphql-query-linter

GraphQL query operation field selection and depth linter

## Description
API schema validation and protocol contract engine providing GraphQL query operation field selection and depth linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

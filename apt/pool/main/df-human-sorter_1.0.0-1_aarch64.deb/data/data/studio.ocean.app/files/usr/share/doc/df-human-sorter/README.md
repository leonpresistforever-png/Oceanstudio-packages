# df-human-sorter

disk filesystem usage sorter with percentage thresholds

## Description
Filesystem analysis and storage engineering utility providing disk filesystem usage sorter with percentage thresholds for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

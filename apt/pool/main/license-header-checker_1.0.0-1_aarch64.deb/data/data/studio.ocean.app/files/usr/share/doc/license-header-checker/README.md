# license-header-checker

audit open source license headers across codebase

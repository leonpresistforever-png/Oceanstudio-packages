# epoll-latency-bench

Linux epoll_wait event readiness turnaround benchmark

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

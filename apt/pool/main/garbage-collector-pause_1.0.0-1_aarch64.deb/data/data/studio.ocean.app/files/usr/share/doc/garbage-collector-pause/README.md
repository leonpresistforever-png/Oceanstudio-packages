# garbage-collector-pause

runtime GC stop-the-world pause duration analyzer

## Description
Performance profiling and microbenchmark utility providing runtime GC stop-the-world pause duration analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

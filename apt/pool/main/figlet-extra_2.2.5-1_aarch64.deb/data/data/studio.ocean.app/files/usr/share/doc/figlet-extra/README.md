# figlet-extra

extended ASCII font banner generator

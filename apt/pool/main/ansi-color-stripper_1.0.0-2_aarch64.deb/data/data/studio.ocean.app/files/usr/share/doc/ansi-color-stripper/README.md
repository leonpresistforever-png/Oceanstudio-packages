# ansi-color-stripper

terminal ANSI escape code and color sequence remover

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

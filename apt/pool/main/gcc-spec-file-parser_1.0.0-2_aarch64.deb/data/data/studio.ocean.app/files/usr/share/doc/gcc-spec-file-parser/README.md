# gcc-spec-file-parser

GCC compiler specs file compiler driver rule parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

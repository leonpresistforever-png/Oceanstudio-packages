# elf-dynamic-tags-view

ELF dynamic array DT_NEEDED DT_RPATH DT_RUNPATH viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

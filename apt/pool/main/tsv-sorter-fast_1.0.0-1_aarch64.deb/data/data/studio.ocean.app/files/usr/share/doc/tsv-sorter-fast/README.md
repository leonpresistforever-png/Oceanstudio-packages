# tsv-sorter-fast

sort tab-separated data files by column indices

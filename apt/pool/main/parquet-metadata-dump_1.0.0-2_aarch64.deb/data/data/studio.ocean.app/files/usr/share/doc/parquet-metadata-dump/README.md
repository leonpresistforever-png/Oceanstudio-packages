# parquet-metadata-dump

Parquet row group and column chunk stats analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

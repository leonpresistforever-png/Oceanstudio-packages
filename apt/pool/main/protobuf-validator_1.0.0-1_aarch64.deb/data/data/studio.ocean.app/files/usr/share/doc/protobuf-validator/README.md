# protobuf-validator

validate syntax of Protocol Buffer definition files

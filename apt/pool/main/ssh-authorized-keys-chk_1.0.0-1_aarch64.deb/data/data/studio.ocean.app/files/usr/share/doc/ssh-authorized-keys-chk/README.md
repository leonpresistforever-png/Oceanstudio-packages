# ssh-authorized-keys-chk

SSH authorized_keys command restrictions and key sizes

## Description
Security forensic analysis and incident response tool providing SSH authorized_keys command restrictions and key sizes for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

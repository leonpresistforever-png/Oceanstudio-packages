# netcat-traditional

classic TCP/IP swiss army knife

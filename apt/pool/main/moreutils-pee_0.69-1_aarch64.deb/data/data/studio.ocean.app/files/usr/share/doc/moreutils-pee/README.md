# moreutils-pee

tee standard input to multiple pipeline processes

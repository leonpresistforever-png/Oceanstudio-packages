# elf-relocation-dumper

ELF dynamic and static relocation entry dumper

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# pam-auth-audit-trail

Linux PAM authentication log audit sequence analyzer

## Description
Security forensic analysis and incident response tool providing Linux PAM authentication log audit sequence analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

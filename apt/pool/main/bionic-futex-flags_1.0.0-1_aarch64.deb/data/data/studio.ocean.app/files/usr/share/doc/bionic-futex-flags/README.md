# bionic-futex-flags

Bionic private futex operation flags decode helper

## Description
Android Bionic and runtime platform utility providing Bionic private futex operation flags decode helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

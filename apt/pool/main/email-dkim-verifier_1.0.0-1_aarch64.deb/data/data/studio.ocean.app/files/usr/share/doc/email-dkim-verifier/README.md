# email-dkim-verifier

query DomainKeys Identified Mail DNS records for selectors

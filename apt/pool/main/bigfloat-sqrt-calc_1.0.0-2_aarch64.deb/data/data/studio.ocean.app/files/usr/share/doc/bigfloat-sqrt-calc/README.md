# bigfloat-sqrt-calc

arbitrary-precision square root via Newton-Raphson

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

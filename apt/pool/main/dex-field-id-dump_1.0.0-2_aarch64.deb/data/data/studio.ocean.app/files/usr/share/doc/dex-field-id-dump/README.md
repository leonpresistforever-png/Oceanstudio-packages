# dex-field-id-dump

DEX field_ids class field definition list viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

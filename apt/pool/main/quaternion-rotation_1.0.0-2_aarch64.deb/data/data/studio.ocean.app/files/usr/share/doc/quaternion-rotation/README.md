# quaternion-rotation

3D quaternion Hamilton product and spatial rotation

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

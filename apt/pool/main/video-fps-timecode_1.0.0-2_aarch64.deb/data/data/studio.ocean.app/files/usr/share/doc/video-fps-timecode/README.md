# video-fps-timecode

video frame rate SMPTE drop-frame timecode converter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

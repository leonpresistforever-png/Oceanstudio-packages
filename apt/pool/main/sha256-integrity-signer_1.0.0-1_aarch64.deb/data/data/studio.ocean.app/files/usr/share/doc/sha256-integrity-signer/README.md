# sha256-integrity-signer

create cryptographically signed SHA-256 integrity manifests

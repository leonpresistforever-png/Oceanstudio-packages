# sqlite-page-analyzer

SQLite page type freelist and overflow page auditor

## Description
Embedded database and SQL processing engine providing SQLite page type freelist and overflow page auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

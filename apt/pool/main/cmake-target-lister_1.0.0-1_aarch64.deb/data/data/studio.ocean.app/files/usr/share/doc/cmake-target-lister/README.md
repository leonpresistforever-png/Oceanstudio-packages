# cmake-target-lister

list and query CMake build targets and dependencies

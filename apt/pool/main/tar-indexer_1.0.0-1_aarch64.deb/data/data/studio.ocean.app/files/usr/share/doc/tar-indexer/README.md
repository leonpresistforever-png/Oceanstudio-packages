# tar-indexer

generate fast seekable index for tar archives

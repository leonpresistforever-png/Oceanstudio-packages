# csv-delimiter-detector

automatic tabular CSV TSV semicolon delimiter detector

## Description
Data stream transformation and ETL pipeline tool providing automatic tabular CSV TSV semicolon delimiter detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

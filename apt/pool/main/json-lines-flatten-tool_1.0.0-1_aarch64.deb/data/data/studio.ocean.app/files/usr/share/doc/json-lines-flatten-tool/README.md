# json-lines-flatten-tool

nested JSON object hierarchy to dot-notation flattener

## Description
Data stream transformation and ETL pipeline tool providing nested JSON object hierarchy to dot-notation flattener for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# xxh3-checksum-fast

XXH3-64 fast non-cryptographic checksum utility

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

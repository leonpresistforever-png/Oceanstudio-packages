# xxh3-checksum-fast

extremely fast XXH3 64-bit and 128-bit checksum utility

## Description
Cryptographic engine and secret management utility providing extremely fast XXH3 64-bit and 128-bit checksum utility for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

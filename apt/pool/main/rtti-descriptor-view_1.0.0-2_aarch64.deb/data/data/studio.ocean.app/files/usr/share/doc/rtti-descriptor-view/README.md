# rtti-descriptor-view

C++ Run-Time Type Information type_info reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

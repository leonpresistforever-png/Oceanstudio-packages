# k-means-clustering-cli

K-Means Lloyd clustering centroid classifier

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

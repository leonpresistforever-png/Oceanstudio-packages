# binwalk-extractor

firmware analysis and signature extraction CLI

# whirlpool-tool

Whirlpool cryptographic hash calculator

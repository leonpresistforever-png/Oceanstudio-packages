# sqlite-pragma-dump

SQLite database PRAGMA configuration reporter

## Description
Embedded database and SQL processing engine providing SQLite database PRAGMA configuration reporter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

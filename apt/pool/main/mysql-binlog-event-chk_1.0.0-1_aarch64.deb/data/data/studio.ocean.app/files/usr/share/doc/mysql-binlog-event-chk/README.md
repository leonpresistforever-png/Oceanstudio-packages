# mysql-binlog-event-chk

MySQL binary log replication event header parser

## Description
Embedded database and SQL processing engine providing MySQL binary log replication event header parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

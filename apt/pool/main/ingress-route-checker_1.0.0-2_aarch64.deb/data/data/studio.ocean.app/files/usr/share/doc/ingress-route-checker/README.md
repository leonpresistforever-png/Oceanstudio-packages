# ingress-route-checker

API gateway ingress routing rules conflict detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

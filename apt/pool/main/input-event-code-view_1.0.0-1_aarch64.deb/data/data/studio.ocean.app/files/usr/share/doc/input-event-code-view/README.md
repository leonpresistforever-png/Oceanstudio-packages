# input-event-code-view

Linux /dev/input/event EV_KEY EV_ABS event code parser

## Description
Android Bionic and runtime platform utility providing Linux /dev/input/event EV_KEY EV_ABS event code parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

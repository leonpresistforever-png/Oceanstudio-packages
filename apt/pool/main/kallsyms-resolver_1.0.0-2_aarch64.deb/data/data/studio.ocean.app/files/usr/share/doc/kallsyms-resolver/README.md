# kallsyms-resolver

kernel symbol address lookup and type decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

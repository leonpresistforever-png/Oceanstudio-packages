# apk-align-tester

verify 4-byte and 4KB zip alignment in Android APK archives

# vmdk-descriptor-view

VMware VMDK monolithic sparse descriptor viewer

## Description
Archive file format and differential backup utility providing VMware VMDK monolithic sparse descriptor viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# u-boot-fit-image-view

Flattened Image Tree FIT image configurations parser

## Description
Embedded firmware and hardware diagnostics tool providing Flattened Image Tree FIT image configurations parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

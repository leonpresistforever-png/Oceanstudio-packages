# standard-deviation-calc

sample variance and standard deviation calculator

## Description
Scientific calculation and numerical algorithm engine providing sample variance and standard deviation calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

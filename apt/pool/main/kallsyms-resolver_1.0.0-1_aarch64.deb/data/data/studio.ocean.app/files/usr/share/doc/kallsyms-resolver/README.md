# kallsyms-resolver

kernel symbol address lookup and type decoder

## Description
Linux procfs and system diagnostic utility providing kernel symbol address lookup and type decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

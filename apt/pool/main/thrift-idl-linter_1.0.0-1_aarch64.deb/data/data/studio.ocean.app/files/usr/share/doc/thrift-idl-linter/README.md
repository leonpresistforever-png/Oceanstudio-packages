# thrift-idl-linter

Apache Thrift IDL service and struct definition linter

## Description
DevOps workflow and microservice coordination utility providing Apache Thrift IDL service and struct definition linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dijkstra-shortest-path

Dijkstra weighted graph shortest path algorithm

## Description
Scientific calculation and numerical algorithm engine providing Dijkstra weighted graph shortest path algorithm for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# u-boot-image-header

Das U-Boot legacy image mkimage header verifier

## Description
Embedded firmware and hardware diagnostics tool providing Das U-Boot legacy image mkimage header verifier for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

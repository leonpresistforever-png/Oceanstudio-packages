# xor-cipher-cli

Multi-byte repeating-key XOR cipher encryption and decryption

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

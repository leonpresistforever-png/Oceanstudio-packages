# hash-verifier

verify MD5/SHA1/SHA256 checksum manifests in bulk

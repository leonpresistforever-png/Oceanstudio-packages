# ninja-log-analyzer

parse .ninja_log to identify build time bottlenecks

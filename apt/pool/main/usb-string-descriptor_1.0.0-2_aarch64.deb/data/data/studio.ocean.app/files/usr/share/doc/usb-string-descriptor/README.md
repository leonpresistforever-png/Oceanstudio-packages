# usb-string-descriptor

USB string descriptor UNICODE UTF-16LE extractor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# tsv-to-markdown

convert TSV input into readable Markdown table

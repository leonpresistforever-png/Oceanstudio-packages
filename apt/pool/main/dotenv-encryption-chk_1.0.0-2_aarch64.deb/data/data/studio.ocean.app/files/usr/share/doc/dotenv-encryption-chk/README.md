# dotenv-encryption-chk

.env file secret exposure and encryption status check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# quorum-majority-calc

N-node cluster Byzantine and crash fault quorums

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

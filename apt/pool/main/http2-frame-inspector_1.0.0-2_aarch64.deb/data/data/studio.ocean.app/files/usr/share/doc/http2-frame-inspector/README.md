# http2-frame-inspector

HTTP/2 binary framing layer and settings frame parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

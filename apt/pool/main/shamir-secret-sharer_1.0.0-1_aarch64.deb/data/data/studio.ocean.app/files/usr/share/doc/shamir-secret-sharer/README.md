# shamir-secret-sharer

Shamir secret sharing scheme splitter and combiner

## Description
Cryptographic engine and secret management utility providing Shamir secret sharing scheme splitter and combiner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# grpc-health-probe

command line tool to probe health of gRPC services

# rot13-encoder

ROT13, ROT5, ROT18, and ROT47 stream cipher encoder/decoder

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

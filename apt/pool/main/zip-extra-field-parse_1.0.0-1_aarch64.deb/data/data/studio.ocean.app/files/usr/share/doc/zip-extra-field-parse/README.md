# zip-extra-field-parse

ZIP extra field header IDs and payloads parser

## Description
Archive file format and differential backup utility providing ZIP extra field header IDs and payloads parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

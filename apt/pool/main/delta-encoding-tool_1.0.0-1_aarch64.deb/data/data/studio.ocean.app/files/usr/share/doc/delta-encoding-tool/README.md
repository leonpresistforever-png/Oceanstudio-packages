# delta-encoding-tool

consecutive numerical array delta differential encoder

## Description
Data stream transformation and ETL pipeline tool providing consecutive numerical array delta differential encoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

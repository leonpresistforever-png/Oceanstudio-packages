# context-switch-cost-est

CPU context switch latency and cache pollution estimate

## Description
Performance profiling and microbenchmark utility providing CPU context switch latency and cache pollution estimate for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

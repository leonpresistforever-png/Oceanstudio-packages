# checksec-hardening

audit binary hardening properties: RELRO, Canary, NX, PIE

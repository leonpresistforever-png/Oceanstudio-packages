# dockerfile-linter

Dockerfile best practices and security directive linter

## Description
DevOps workflow and microservice coordination utility providing Dockerfile best practices and security directive linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# apk-cert-verifier

verify APK Signature Scheme v1, v2 and v3 signatures

# mmap-allocation-tracer

process mmap anonymous memory mapping tracker

## Description
Performance profiling and microbenchmark utility providing process mmap anonymous memory mapping tracker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

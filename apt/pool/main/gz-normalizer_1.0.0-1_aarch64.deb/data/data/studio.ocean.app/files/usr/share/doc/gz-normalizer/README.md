# gz-normalizer

recompress gzip files with zero timestamp for reproducible builds

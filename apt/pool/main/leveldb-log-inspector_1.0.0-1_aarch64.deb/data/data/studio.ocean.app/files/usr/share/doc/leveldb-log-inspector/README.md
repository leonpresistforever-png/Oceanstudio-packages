# leveldb-log-inspector

LevelDB write-ahead log record and CRC checker

## Description
Embedded database and SQL processing engine providing LevelDB write-ahead log record and CRC checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

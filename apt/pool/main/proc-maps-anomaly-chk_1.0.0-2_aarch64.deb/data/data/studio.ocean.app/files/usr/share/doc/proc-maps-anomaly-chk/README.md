# proc-maps-anomaly-chk

executable heap and stack memory anomaly detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# sql-injection-tester

SQL query literal parameterization security checker
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard12_database.py
Source SHA256: 8018f5372eadfc4573a69ab28a0e706608d4102efbb8b61917e79ac05266772f
Shared runtime package: ocean-runtime-shard12-database

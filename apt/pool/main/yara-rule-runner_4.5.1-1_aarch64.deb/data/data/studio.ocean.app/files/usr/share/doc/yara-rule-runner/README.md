# yara-rule-runner

pattern matching engine for defensive malware analysis

# elf-got-overwrite-chk

Global Offset Table integrity and overwrite detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# hidden-visibility-chk

ELF symbol default vs hidden visibility auditor

## Description
Binary analysis and compilation toolchain helper providing ELF symbol default vs hidden visibility auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

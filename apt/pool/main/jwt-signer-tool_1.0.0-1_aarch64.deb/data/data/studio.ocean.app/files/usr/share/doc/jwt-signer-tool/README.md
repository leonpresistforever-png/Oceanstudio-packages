# jwt-signer-tool

JSON Web Token HMAC and RSA signature generator

## Description
Cryptographic engine and secret management utility providing JSON Web Token HMAC and RSA signature generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

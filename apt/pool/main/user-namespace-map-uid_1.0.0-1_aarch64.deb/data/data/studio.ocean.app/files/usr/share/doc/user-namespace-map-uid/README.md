# user-namespace-map-uid

user namespace uid_map and gid_map subuid translator

## Description
Container runtime and Linux namespace management utility providing user namespace uid_map and gid_map subuid translator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

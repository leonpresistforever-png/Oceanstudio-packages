# dex-type-id-parser

DEX type_ids type descriptor table decompiler

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

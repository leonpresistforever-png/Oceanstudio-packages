# function-length-linter

excessive function line length and complexity alert

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# moreutils-vipe

edit pipeline in editor between stages

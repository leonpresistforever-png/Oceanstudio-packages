# linker-script-parser

GNU LD linker script SECTIONS and MEMORY parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# package-signing-v3-chk

Android APK Signature Scheme v3 key rotation checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# moreutils-ifne

run command only if standard input is not empty

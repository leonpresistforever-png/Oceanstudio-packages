# tokei-counter

fast code analysis and line counting tool

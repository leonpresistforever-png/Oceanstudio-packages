# bison-graph-viewer

generate DOT visualization of Bison parser states

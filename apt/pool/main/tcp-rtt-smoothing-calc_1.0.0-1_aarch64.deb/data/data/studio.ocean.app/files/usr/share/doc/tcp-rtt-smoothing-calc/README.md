# tcp-rtt-smoothing-calc

TCP Round-Trip Time SRTT variance Jacobson algorithm

## Description
Performance profiling and microbenchmark utility providing TCP Round-Trip Time SRTT variance Jacobson algorithm for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

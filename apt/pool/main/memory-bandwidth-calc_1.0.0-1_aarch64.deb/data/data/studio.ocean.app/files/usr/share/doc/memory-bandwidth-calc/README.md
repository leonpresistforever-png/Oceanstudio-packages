# memory-bandwidth-calc

DRAM memory bus bandwidth saturation estimator

## Description
Performance profiling and microbenchmark utility providing DRAM memory bus bandwidth saturation estimator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# blake3-cli

official BLAKE3 cryptographic hash tool

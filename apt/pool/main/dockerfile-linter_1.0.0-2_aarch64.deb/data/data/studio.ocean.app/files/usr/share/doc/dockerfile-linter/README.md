# dockerfile-linter

Dockerfile best practices and security directive linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

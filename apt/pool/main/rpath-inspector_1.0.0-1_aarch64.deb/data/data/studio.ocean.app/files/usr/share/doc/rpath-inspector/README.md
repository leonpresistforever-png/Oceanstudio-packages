# rpath-inspector

inspect and audit RUNPATH/RPATH in ELF binaries

# enca-analyzer

charset analyzer and language detector

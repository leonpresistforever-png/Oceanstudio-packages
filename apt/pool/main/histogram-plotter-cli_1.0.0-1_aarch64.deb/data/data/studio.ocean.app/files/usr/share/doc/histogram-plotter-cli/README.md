# histogram-plotter-cli

generate ASCII histogram plots in terminal for numeric streams

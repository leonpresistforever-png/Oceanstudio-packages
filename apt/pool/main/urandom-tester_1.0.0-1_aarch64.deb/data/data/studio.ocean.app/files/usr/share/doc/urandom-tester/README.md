# urandom-tester

CSPRNG statistical test suite (entropy, bit distribution)

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

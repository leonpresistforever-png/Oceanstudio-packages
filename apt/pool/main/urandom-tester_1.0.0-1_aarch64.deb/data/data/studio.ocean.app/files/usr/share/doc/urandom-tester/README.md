# urandom-tester

kernel /dev/urandom throughput and randomness tester

## Description
Cryptographic engine and secret management utility providing kernel /dev/urandom throughput and randomness tester for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

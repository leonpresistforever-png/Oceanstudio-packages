# iftop-monitor

display bandwidth usage by host on network interface

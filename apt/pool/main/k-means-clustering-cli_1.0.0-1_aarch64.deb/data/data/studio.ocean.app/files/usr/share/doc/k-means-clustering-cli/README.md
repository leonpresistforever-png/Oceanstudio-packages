# k-means-clustering-cli

K-Means Lloyd clustering centroid classifier

## Description
Scientific calculation and numerical algorithm engine providing K-Means Lloyd clustering centroid classifier for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

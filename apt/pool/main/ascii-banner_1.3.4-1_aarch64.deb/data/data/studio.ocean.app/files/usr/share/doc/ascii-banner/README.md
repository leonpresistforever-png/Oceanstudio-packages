# ascii-banner

display large banner headlines on stdout

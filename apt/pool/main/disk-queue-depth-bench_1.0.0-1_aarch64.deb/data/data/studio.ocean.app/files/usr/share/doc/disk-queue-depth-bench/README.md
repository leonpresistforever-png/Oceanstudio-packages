# disk-queue-depth-bench

storage I/O queue depth concurrency benchmark helper

## Description
Performance profiling and microbenchmark utility providing storage I/O queue depth concurrency benchmark helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

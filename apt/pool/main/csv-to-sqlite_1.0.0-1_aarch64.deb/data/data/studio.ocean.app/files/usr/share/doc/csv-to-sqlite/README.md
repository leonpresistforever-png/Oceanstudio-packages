# csv-to-sqlite

import CSV and TSV tables directly into SQLite database

# package-setting-parser

Android packages.xml permission and package parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

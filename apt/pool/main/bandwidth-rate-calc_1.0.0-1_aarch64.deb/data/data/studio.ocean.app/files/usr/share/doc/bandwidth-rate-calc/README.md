# bandwidth-rate-calc

network throughput bits-to-bytes rate calculator

## Description
Low-level network protocol and socket diagnostics utility providing network throughput bits-to-bytes rate calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

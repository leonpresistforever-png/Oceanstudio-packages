# dns-propagation-chk

query multiple global DNS resolvers for propagation checks

# shred-secure-delete

NIST 800-88 compliant multi-pass secure file shredder

## Description
Filesystem analysis and storage engineering utility providing NIST 800-88 compliant multi-pass secure file shredder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

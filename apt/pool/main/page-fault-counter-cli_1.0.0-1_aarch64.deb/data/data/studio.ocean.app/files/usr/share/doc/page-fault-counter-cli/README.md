# page-fault-counter-cli

minor and major page fault occurrence rate counter

## Description
Performance profiling and microbenchmark utility providing minor and major page fault occurrence rate counter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# scc-code-counter

succinct code counter with complexity estimates

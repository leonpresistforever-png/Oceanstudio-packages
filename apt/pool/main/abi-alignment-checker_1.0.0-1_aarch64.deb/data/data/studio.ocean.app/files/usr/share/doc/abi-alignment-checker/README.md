# abi-alignment-checker

C struct field natural alignment and padding tool

## Description
Binary analysis and compilation toolchain helper providing C struct field natural alignment and padding tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

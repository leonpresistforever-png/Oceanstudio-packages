# chaos-kill-selector

chaos engineering random process termination selector

## Description
DevOps workflow and microservice coordination utility providing chaos engineering random process termination selector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

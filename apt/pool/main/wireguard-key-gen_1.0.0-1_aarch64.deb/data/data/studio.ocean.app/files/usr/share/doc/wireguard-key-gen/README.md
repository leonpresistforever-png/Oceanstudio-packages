# wireguard-key-gen

WireGuard private, public, and preshared key generator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# calling-convention-chk

AAPCS64 calling convention argument register checker

## Description
Binary analysis and compilation toolchain helper providing AAPCS64 calling convention argument register checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

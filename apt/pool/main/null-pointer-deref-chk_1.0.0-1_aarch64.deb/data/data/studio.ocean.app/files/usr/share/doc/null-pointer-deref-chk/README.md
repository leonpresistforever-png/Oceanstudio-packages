# null-pointer-deref-chk

static null pointer dereference potential warning tool

## Description
Static analysis and source code auditing utility providing static null pointer dereference potential warning tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

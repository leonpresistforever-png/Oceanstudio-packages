# zip64-locator-parser

ZIP64 End of Central Directory record locator tool

## Description
Archive file format and differential backup utility providing ZIP64 End of Central Directory record locator tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

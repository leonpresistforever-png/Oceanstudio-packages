# stackcollapse-gdb-tool

GDB thread backtraces to collapsed call stack format

## Description
Performance profiling and microbenchmark utility providing GDB thread backtraces to collapsed call stack format for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

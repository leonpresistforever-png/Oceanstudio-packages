# selinux-mls-level-chk

SELinux Multi-Level Security s0-s15 sensitivity check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

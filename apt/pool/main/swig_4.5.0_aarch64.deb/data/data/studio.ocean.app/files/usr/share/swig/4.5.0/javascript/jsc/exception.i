%include <typemaps/exception.swg>

# spi-flash-jedec-id-chk

SPI NOR flash JEDEC RDID manufacturer ID lookup

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

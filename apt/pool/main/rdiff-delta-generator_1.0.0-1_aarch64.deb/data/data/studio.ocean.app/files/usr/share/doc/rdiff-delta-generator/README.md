# rdiff-delta-generator

binary file delta differential patch generator

## Description
Archive file format and differential backup utility providing binary file delta differential patch generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

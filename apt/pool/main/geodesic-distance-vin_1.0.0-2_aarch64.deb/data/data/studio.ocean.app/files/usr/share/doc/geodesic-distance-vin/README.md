# geodesic-distance-vin

Vincenty inverse geodesic ellipsoid distance tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

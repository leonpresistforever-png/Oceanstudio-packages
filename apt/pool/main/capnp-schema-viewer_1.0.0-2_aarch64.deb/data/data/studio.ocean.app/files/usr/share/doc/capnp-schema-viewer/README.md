# capnp-schema-viewer

Cap'n Proto schema field offset and type inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# power-consumption-model

ARM big.LITTLE core energy consumption model tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dumpsys-meminfo-parse

dumpsys meminfo native dalvik graphics heap analyzer

## Description
Android Bionic and runtime platform utility providing dumpsys meminfo native dalvik graphics heap analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

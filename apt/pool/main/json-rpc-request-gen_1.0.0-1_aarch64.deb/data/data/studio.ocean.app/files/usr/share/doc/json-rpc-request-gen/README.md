# json-rpc-request-gen

JSON-RPC 2.0 request batch and response builder

## Description
DevOps workflow and microservice coordination utility providing JSON-RPC 2.0 request batch and response builder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

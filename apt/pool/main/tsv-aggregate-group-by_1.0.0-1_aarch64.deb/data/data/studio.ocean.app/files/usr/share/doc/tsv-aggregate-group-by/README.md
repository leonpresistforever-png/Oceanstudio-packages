# tsv-aggregate-group-by

TSV stream group-by column aggregator sum min max count

## Description
Data stream transformation and ETL pipeline tool providing TSV stream group-by column aggregator sum min max count for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

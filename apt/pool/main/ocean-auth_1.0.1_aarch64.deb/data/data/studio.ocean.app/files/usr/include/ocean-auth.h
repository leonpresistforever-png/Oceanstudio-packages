#ifndef OCEAN_AUTH_H
#define OCEAN_AUTH_H

#include <stdbool.h>

#define OCEAN_HOME "/data/data/studio.ocean.app/files/home"
#define OCEAN_PREFIX "/data/data/studio.ocean.app/files/usr"
#define AUTH_HASH_FILE_PATH OCEAN_HOME "/.ocean_authinfo"

#ifdef __cplusplus
extern "C" {
#endif

unsigned char *ocean_passwd_hash(const char *password);
bool ocean_change_passwd(const char *new_password);
bool ocean_remove_passwd(void);
bool ocean_auth(const char *user, const char *password);

#ifdef __cplusplus
}
#endif

#endif

# pm-dump-permissions

Android PackageManager permission tree and group dump

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

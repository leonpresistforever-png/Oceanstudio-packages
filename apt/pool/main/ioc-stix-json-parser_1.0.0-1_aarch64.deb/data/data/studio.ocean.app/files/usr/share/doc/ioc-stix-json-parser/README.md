# ioc-stix-json-parser

STIX 2.1 structured threat information expression tool

## Description
Security forensic analysis and incident response tool providing STIX 2.1 structured threat information expression tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

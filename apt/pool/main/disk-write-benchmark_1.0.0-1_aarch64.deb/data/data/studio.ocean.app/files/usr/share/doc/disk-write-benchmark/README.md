# disk-write-benchmark

direct I/O filesystem write throughput benchmark

## Description
Filesystem analysis and storage engineering utility providing direct I/O filesystem write throughput benchmark for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

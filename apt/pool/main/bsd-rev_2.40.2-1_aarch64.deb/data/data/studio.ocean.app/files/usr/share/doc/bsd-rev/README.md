# bsd-rev

reverse the order of characters in every line

# recovery-fstab-parser

Android recovery.fstab block device mount points view

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

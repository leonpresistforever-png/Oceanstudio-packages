# load-balancer-round

weighted round-robin backend server selection simulator

## Description
DevOps workflow and microservice coordination utility providing weighted round-robin backend server selection simulator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

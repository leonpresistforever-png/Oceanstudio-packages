# sync-latency-timer

kernel sync and fsync flush latency benchmark

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# logfmt-parser-cli

key=value structured logfmt parser and JSON converter

## Description
DevOps workflow and microservice coordination utility providing key=value structured logfmt parser and JSON converter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# yaml-schema-validator

validate YAML documents against defined schemas

# clang-ast-dump-filter

Clang AST JSON dump node filtering and search tool

## Description
Binary analysis and compilation toolchain helper providing Clang AST JSON dump node filtering and search tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

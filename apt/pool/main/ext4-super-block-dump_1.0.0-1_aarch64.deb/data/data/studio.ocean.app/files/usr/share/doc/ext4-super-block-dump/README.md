# ext4-super-block-dump

ext4 superblock feature flags and block group view

## Description
Filesystem analysis and storage engineering utility providing ext4 superblock feature flags and block group view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

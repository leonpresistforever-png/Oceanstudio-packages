# matrix-eigen-evaluator

symmetric matrix eigenvalue power iteration estimator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

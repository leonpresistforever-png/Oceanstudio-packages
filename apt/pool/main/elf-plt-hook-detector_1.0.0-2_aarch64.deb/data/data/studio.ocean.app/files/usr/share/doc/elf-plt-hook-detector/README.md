# elf-plt-hook-detector

Procedure Linkage Table redirection hook detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

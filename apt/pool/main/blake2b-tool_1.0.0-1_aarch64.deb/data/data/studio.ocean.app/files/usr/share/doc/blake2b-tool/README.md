# blake2b-tool

BLAKE2b 512-bit high-speed cryptographic hasher

## Description
Cryptographic engine and secret management utility providing BLAKE2b 512-bit high-speed cryptographic hasher for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

<!DOCTYPE html SYSTEM "about:legacy-compat">
<html lang="es"><head><META http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<meta content="width=device-width, initial-scale=1" name="viewport">
<!--
        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
              This file is generated from xml source: DO NOT EDIT
        XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
      -->
<title>Apache HTTP Server Versi&oacute;n 2.4
Documentaci&oacute;n - Servidor HTTP Apache Versi&oacute;n 2.4</title>
<link href="./style/css/manual.css" rel="stylesheet" media="all" type="text/css" title="Main stylesheet">
<link href="./style/css/manual-loose-100pc.css" rel="alternate stylesheet" media="all" type="text/css" title="No Sidebar - Default font size">
<link href="./style/css/manual-print.css" rel="stylesheet" media="print" type="text/css"><link rel="stylesheet" type="text/css" href="./style/css/prettify.css">
<script src="./style/scripts/prettify.min.js">
</script>

<link href="./images/favicon.png" rel="shortcut icon"></head>
<body id="index-page">
<div id="page-header">
<p class="menu"><a href="./mod/">M&oacute;dulos</a> | <a href="./mod/quickreference.html">Directivas</a> | <a href="https://cwiki.apache.org/confluence/display/httpd/FAQ">Preguntas Frecuentes</a> | <a href="./glossary.html">Glosario</a> | <a href="./sitemap.html">Mapa del sitio web</a> | <a href="https://bz.apache.org/bugzilla/enter_bug.cgi?product=Apache%20httpd-2">Reportar un error</a></p>
<p class="apache">Versi&oacute;n 2.4 del Servidor HTTP Apache</p>
<img alt="" src="./images/feather.png"></div>
<div class="up"><a href="http://httpd.apache.org/docs-project/"><img title="<-" alt="<-" src="./images/left.gif"></a></div>
<div id="path">
<a href="https://www.apache.org/">Apache</a> &gt; <a href="https://httpd.apache.org/">Servidor HTTP</a> &gt; <a href="https://httpd.apache.org/docs/">Documentaci&oacute;n</a></div>
<div id="page-content"><h1>Apache HTTP Server Versi&oacute;n 2.4
Documentaci&oacute;n</h1>
<button aria-label="Toggle language list" class="lang-toggle"><svg xmlns="http://www.w3.org/2000/svg" stroke-width="2" stroke="currentColor" fill="none" viewBox="0 0 24 24" height="16" width="16"><circle r="10" cy="12" cx="12"/><line y2="12" x2="22" y1="12" x1="2"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></button>
<div class="toplang">
<p><span>Idiomas disponibles: </span><a href="./da/" hreflang="da" rel="alternate" title="Dansk">&nbsp;da&nbsp;</a> |
<a href="./de/" hreflang="de" rel="alternate" title="Deutsch">&nbsp;de&nbsp;</a> |
<a href="./en/" hreflang="en" rel="alternate" title="English">&nbsp;en&nbsp;</a> |
<a href="./es/" title="Espa&ntilde;ol">&nbsp;es&nbsp;</a> |
<a href="./fr/" hreflang="fr" rel="alternate" title="Fran&ccedil;ais">&nbsp;fr&nbsp;</a> |
<a href="./ja/" hreflang="ja" rel="alternate" title="Japanese">&nbsp;ja&nbsp;</a> |
<a href="./ko/" hreflang="ko" rel="alternate" title="Korean">&nbsp;ko&nbsp;</a> |
<a href="./pt-br/" hreflang="pt-br" rel="alternate" title="Portugu&ecirc;s (Brasil)">&nbsp;pt-br&nbsp;</a> |
<a href="./ru/" hreflang="ru" rel="alternate" title="Russian">&nbsp;ru&nbsp;</a> |
<a href="./tr/" hreflang="tr" rel="alternate" title="T&uuml;rk&ccedil;e">&nbsp;tr&nbsp;</a> |
<a href="./zh-cn/" hreflang="zh-cn" rel="alternate" title="Simplified Chinese">&nbsp;zh-cn&nbsp;</a></p>
</div>
<div class="outofdate">Esta traducci&oacute;n podr&iacute;a estar
            obsoleta. Consulte la versi&oacute;n en ingl&eacute;s de la
            documentaci&oacute;n para comprobar si se han producido cambios
            recientemente.</div>
<form method="get" action="https://www.google.com/search"><p><input name="as_q" value="" type="text"> <input value="Buscar en Google" type="submit"><input value="10" name="num" type="hidden"><input value="es" name="hl" type="hidden"><input value="ISO-8859-1" name="ie" type="hidden"><input value="Google Search" name="btnG" type="hidden"><input name="as_epq" value="Versi&oacute;n 2.4" type="hidden"><input name="as_oq" value="" type="hidden"><input name="as_eq" value="&quot;List-Post&quot;" type="hidden"><input value="" name="lr" type="hidden"><input value="i" name="as_ft" type="hidden"><input value="" name="as_filetype" type="hidden"><input value="all" name="as_qdr" type="hidden"><input value="any" name="as_occt" type="hidden"><input value="i" name="as_dt" type="hidden"><input value="httpd.apache.org" name="as_sitesearch" type="hidden"><input value="off" name="safe" type="hidden"></p></form>
<table id="indextable"><tr><td class="col1"><div class="category"><h2><a name="release" id="release">Notas de la versi&oacute;n</a></h2>
<ul><li><a href="new_features_2_4.html">Nuevas funcionalidades en Apache 2.3/2.4</a></li>
<li><a href="new_features_2_2.html">Nuevas funcionalidades en Apache 2.1/2.2</a></li>
<li><a href="new_features_2_0.html">Nuevas funcionalidades en Apache 2.0</a></li>
<li><a href="upgrading.html">Actualizar a la versi&oacute;n 2.4 desde la 2.2</a></li>
<li><a href="license.html">Licencia Apache </a></li>
</ul>
</div><div class="category"><h2><a name="manual" id="manual">Manual de Referencia</a></h2>
<ul><li><a href="install.html">Compilar e Instalar</a></li>
<li><a href="invoking.html">Ejecutando Apache</a></li>
<li><a href="stopping.html">Parada y Reinicio de Apache</a></li>
<li><a href="mod/quickreference.html">Directivas de configuraci&oacute;n en tiempo de ejecuci&oacute;n</a></li>
<li><a href="mod/">M&oacute;dulos</a></li>
<li><a href="mpm.html">M&oacute;dulos de Procesamiento M&uacute;ltiple (MPM)</a></li>
<li><a href="filter.html">Filtros</a></li>
<li><a href="handler.html">Handlers</a></li>
<li><a href="expr.html">Analizador de Expresiones</a></li>
<li><a href="mod/overrides.html">Sobreescritura de la clase &iacute;ndice .htaccess</a></li>
<li><a href="programs/">Programas de Soporte y Servidor</a></li>
<li><a href="glossary.html">Glosario</a></li>
</ul>
</div></td><td><div class="category"><h2><a name="usersguide" id="usersguide">Gu&iacute;a de Usuario</a></h2>
<ul><li><a href="getting-started.html">Empezando</a></li>
<li><a href="bind.html">Enlazando Direcciones y Puertos</a></li>
<li><a href="configuring.html">Ficheros de Configuraci&oacute;n</a></li>
<li><a href="sections.html">Secciones de Configuraci&oacute;n</a></li>
<li><a href="caching.html">Almacenamiento de Contenido en Cach&eacute;</a></li>
<li><a href="content-negotiation.html">Negociaci&oacute;n de Contenido</a></li>
<li><a href="dso.html">Objetos Compartidos Din&aacute;micamente (DSO)</a></li>
<li><a href="env.html">Variables de Entorno</a></li>
<li><a href="logs.html">Ficheros de Log</a></li>
<li><a href="compliance.html">Cumplimiento del Protocolo HTTP</a></li>
<li><a href="urlmapping.html">Mapeo de URLs al Sistema de Ficheros</a></li>
<li><a href="misc/perf-tuning.html">Optimizaci&oacute;n del Rendimiento</a></li>
<li><a href="misc/security_tips.html">Consejos de seguridad</a></li>
<li><a href="server-wide.html">Configuraci&oacute;n b&aacute;sica del Servidor</a></li>
<li><a href="ssl/">Cifrado SSL/TLS</a></li>
<li><a href="suexec.html">Ejecuci&oacute;n de Suexec para CGI</a></li>
<li><a href="rewrite/">Reescritura de URL con mod_rewrite</a></li>
<li><a href="vhosts/">Servidores Virtuales</a></li>
</ul>
</div></td><td class="col3"><div class="category"><h2><a name="howto" id="howto">How-To / Tutoriales</a></h2>
<ul><li><a href="howto">&Iacute;ndice de Tutoriales </a></li>
<li><a href="howto/auth.html">Autenticaci&oacute;n y Autorizaci&oacute;n</a></li>
<li><a href="howto/access.html">Control de Acceso</a></li>
<li><a href="howto/cgi.html">CGI: Contenido Din&aacute;mico</a></li>
<li><a href="howto/htaccess.html">Ficheros .htaccess</a></li>
<li><a href="howto/ssi.html">Inclusiones del Lado del Servidor (SSI)</a></li>
<li><a href="howto/public_html.html">Directorios Web por Usuario
    (public_html)</a></li>
<li><a href="howto/reverse_proxy.html">Gu&iacute;a de configuraci&oacute;n de Proxy Inverso</a></li>
<li><a href="howto/http2.html">Gu&iacute;a HTTP/2 </a></li>
</ul>
</div><div class="category"><h2><a name="platform" id="platform">Notas Sobre Plataformas Espec&iacute;ficas</a></h2>
<ul><li><a href="platform/windows.html">Microsoft Windows</a></li>
<li><a href="platform/rpm.html">Sistemas Basados en RPM (Redhat / CentOS / Fedora)</a></li>
<li><a href="platform/netware.html">Novell NetWare</a></li>
</ul>
</div><div class="category"><h2><a name="other" id="other">Otros Temas</a></h2>
<ul><li><a href="https://cwiki.apache.org/confluence/display/httpd/FAQ">Preguntas Frecuentes</a></li>
<li><a href="sitemap.html">Mapa del Sitio</a></li>
<li><a href="developer/">Documentaci&oacute;n para Desarrolladores</a></li>
<li><a href="http://httpd.apache.org/docs-project/">Contribuir en la Documentaci&oacute;n</a></li>
<li><a href="misc/">Otras Notas</a></li>
<li><a href="https://cwiki.apache.org/confluence/display/httpd/">Wiki</a></li>
</ul>
</div></td></tr></table></div>
<div class="bottomlang">
<p><span>Idiomas disponibles: </span><a href="./da/" hreflang="da" rel="alternate" title="Dansk">&nbsp;da&nbsp;</a> |
<a href="./de/" hreflang="de" rel="alternate" title="Deutsch">&nbsp;de&nbsp;</a> |
<a href="./en/" hreflang="en" rel="alternate" title="English">&nbsp;en&nbsp;</a> |
<a href="./es/" title="Espa&ntilde;ol">&nbsp;es&nbsp;</a> |
<a href="./fr/" hreflang="fr" rel="alternate" title="Fran&ccedil;ais">&nbsp;fr&nbsp;</a> |
<a href="./ja/" hreflang="ja" rel="alternate" title="Japanese">&nbsp;ja&nbsp;</a> |
<a href="./ko/" hreflang="ko" rel="alternate" title="Korean">&nbsp;ko&nbsp;</a> |
<a href="./pt-br/" hreflang="pt-br" rel="alternate" title="Portugu&ecirc;s (Brasil)">&nbsp;pt-br&nbsp;</a> |
<a href="./ru/" hreflang="ru" rel="alternate" title="Russian">&nbsp;ru&nbsp;</a> |
<a href="./tr/" hreflang="tr" rel="alternate" title="T&uuml;rk&ccedil;e">&nbsp;tr&nbsp;</a> |
<a href="./zh-cn/" hreflang="zh-cn" rel="alternate" title="Simplified Chinese">&nbsp;zh-cn&nbsp;</a></p>
</div><div id="footer">
<p class="apache">Copyright 2026 The Apache Software Foundation.<br>Licencia bajo los t&eacute;rminos de la <a href="https://www.apache.org/licenses/LICENSE-2.0">Apache License, Version 2.0</a>.</p>
<p class="menu"><a href="./mod/">M&oacute;dulos</a> | <a href="./mod/quickreference.html">Directivas</a> | <a href="https://cwiki.apache.org/confluence/display/httpd/FAQ">Preguntas Frecuentes</a> | <a href="./glossary.html">Glosario</a> | <a href="./sitemap.html">Mapa del sitio web</a> | <a href="https://bz.apache.org/bugzilla/enter_bug.cgi?product=Apache%20httpd-2">Reportar un error</a></p></div><script><!--//--><![CDATA[//><!--
if (typeof(prettyPrint) !== 'undefined') {
    prettyPrint();
}
var langToggle = document.querySelector('.lang-toggle');
var topLang = document.querySelector('.toplang');
if (langToggle && topLang) {
    langToggle.addEventListener('click', function() { topLang.classList.toggle('open'); });
}
var qv = document.getElementById('quickview');
if (qv) {
    document.body.appendChild(qv);
    var qvBtn = document.createElement('button');
    qvBtn.className = 'qv-toggle';
    qvBtn.setAttribute('aria-label', 'Toggle page navigation');
    qvBtn.innerHTML = '&#9776;';
    document.body.appendChild(qvBtn);
    qvBtn.addEventListener('click', function() {
        var isOpen = qv.classList.toggle('open');
        if (isOpen) {
            qv.style.top = window.scrollY + 10 + 'px';
        }
    });
    window.addEventListener('scroll', function() { qv.classList.remove('open'); });
}
//--><!]]></script>
</body></html>
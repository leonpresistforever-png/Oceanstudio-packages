# totp-authenticator-cli

time-based one-time password generator for MFA

## Description
Cryptographic engine and secret management utility providing time-based one-time password generator for MFA for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

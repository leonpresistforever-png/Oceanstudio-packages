# totp-authenticator-cli

RFC 6238 Time-Based One-Time Password generator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

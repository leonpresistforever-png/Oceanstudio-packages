# squashfs-inode-table

SquashFS inode lookup table and fragment parser

## Description
Archive file format and differential backup utility providing SquashFS inode lookup table and fragment parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

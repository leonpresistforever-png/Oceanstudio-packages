# net-namespace-bridge

network namespace virtual ethernet pair configuration

## Description
Container runtime and Linux namespace management utility providing network namespace virtual ethernet pair configuration for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# irq-cpu-affinity-view

hardware interrupt CPU affinity smp_affinity viewer

## Description
Performance profiling and microbenchmark utility providing hardware interrupt CPU affinity smp_affinity viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

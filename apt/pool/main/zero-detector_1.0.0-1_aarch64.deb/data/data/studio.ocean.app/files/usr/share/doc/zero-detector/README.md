# zero-detector

detect runs of zero bytes and sparse file candidate

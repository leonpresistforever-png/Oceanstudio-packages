# postgresql-copy-stream

PostgreSQL COPY protocol text/binary stream formatter

## Description
Embedded database and SQL processing engine providing PostgreSQL COPY protocol text/binary stream formatter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

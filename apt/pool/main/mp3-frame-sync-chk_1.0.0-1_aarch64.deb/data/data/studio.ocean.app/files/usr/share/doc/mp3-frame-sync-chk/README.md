# mp3-frame-sync-chk

MPEG audio frame synchronization word and bitrate tool

## Description
Media header parser and audiovisual engineering utility providing MPEG audio frame synchronization word and bitrate tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

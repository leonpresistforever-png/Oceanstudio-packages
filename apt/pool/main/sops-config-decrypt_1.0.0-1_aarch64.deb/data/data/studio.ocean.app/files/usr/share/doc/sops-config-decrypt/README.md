# sops-config-decrypt

SOPS / age encrypted config inspector and decryptor

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

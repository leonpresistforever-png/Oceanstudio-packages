# redis-resp-decoder

Redis RESP protocol parser and JSON translator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# cidr-overlap-checker

IP route CIDR prefix overlap and containment detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# tsv-unique-counter

count unique values per column in tab-separated data

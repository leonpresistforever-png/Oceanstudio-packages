# bigint-extended-gcd

Extended Euclidean algorithm Bezout identity solver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# sqlite-b-tree-inspector

SQLite database file page header and cell parser

## Description
Embedded database and SQL processing engine providing SQLite database file page header and cell parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

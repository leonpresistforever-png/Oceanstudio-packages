# wipefs-magic-scanner

filesystem signature magic number scanner

## Description
Filesystem analysis and storage engineering utility providing filesystem signature magic number scanner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

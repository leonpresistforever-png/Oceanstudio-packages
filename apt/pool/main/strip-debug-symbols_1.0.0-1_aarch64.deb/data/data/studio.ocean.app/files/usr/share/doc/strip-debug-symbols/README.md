# strip-debug-symbols

DWARF debug sections identifier and stripper tool

## Description
Binary analysis and compilation toolchain helper providing DWARF debug sections identifier and stripper tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

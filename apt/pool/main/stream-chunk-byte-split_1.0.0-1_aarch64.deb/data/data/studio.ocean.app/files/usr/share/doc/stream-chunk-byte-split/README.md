# stream-chunk-byte-split

stream chunking by byte count without creating files

## Description
Data stream transformation and ETL pipeline tool providing stream chunking by byte count without creating files for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# icmp-timestamp-chk

query ICMP timestamp requests for time synchronization

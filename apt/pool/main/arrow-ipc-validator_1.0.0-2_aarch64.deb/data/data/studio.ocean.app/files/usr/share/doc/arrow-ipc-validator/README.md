# arrow-ipc-validator

Apache Arrow IPC stream and record batch validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# typst-document-linter

Typst typesetting markup syntax and layout linter

## Description
Text tokenization and natural language processing tool providing Typst typesetting markup syntax and layout linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

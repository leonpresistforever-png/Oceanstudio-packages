# meson-build-validator

meson.build project and dependency syntax linter

## Description
Static analysis and source code auditing utility providing meson.build project and dependency syntax linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# ragel-state-machine

finite state machine compiler and code generator

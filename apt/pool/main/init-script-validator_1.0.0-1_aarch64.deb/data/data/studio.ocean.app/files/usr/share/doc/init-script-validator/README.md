# init-script-validator

SysV init script LSB header and runlevel validator

## Description
DevOps workflow and microservice coordination utility providing SysV init script LSB header and runlevel validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

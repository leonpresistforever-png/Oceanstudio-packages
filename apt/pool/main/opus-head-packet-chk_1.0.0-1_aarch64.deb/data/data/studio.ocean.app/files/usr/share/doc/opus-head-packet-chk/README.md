# opus-head-packet-chk

OpusHead identification header and preskip calculator

## Description
Media header parser and audiovisual engineering utility providing OpusHead identification header and preskip calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

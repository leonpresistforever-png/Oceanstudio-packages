# sched-wakeup-latency

scheduler wakeup-to-execution latency distribution

## Description
Performance profiling and microbenchmark utility providing scheduler wakeup-to-execution latency distribution for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# sepolicy-rule-search

Android compiled sepolicy TE allow rule search engine

## Description
Android Bionic and runtime platform utility providing Android compiled sepolicy TE allow rule search engine for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# line-numberer

line numbering filter with configurable format

# llvm-bitcode-header

LLVM bitcode wrapper header and block parser

## Description
Binary analysis and compilation toolchain helper providing LLVM bitcode wrapper header and block parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# statistics-cli-tool

calculate standard deviation, variance and median of numbers

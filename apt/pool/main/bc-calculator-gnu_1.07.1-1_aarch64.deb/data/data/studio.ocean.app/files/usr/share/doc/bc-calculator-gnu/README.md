# bc-calculator-gnu

GNU arbitrary precision calculator language

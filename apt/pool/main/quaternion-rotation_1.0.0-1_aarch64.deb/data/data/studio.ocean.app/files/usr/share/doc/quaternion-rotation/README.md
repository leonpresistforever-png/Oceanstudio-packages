# quaternion-rotation

3D quaternion Hamilton product and spatial rotation

## Description
Scientific calculation and numerical algorithm engine providing 3D quaternion Hamilton product and spatial rotation for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

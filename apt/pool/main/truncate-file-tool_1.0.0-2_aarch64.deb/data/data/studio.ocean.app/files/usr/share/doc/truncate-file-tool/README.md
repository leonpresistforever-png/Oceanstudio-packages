# truncate-file-tool

fast file length expansion and truncation utility

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

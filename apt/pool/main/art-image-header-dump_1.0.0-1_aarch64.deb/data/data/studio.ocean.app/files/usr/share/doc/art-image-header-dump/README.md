# art-image-header-dump

Android ART boot.art image header and object space view

## Description
Android Bionic and runtime platform utility providing Android ART boot.art image header and object space view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

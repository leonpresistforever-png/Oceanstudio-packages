# astronomical-julian

Julian Day and Modified Julian Date astronomical calc

## Description
Scientific calculation and numerical algorithm engine providing Julian Day and Modified Julian Date astronomical calc for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

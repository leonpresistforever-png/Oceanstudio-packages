# porter-stemmer-cli

Porter Stemming Algorithm morphological word stemmer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

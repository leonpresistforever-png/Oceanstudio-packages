# udp-socket-inspector

UDP socket receive buffer and packet drop auditor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

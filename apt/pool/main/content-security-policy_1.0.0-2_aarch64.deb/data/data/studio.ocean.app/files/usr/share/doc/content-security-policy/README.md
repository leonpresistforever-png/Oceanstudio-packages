# content-security-policy

W3C Content Security Policy CSP directive linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# b3-trace-header-inject

Zipkin B3 propagation traceId spanId injector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

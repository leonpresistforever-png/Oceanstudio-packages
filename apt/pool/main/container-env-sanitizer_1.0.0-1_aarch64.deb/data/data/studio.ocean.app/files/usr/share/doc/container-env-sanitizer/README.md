# container-env-sanitizer

container environment variable secret leak checker

## Description
Container runtime and Linux namespace management utility providing container environment variable secret leak checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# macaroon-token-cli

Macaroon decentralized authorization token generator with caveats

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

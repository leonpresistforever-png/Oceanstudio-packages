# dns-srv-balancer

DNS Service Location port weight and priority parser

## Description
Low-level network protocol and socket diagnostics utility providing DNS Service Location port weight and priority parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

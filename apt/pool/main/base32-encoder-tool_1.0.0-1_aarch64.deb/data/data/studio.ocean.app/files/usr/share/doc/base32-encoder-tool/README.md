# base32-encoder-tool

RFC 4648 Base32 encoding and decoding CLI

# scsi-inquiry-vpd-dump

SCSI Vital Product Data VPD unit serial number reader

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

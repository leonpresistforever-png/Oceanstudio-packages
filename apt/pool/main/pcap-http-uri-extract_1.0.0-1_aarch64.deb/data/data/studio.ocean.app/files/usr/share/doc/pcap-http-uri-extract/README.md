# pcap-http-uri-extract

extract HTTP requests URLs User-Agents from PCAP

## Description
Security forensic analysis and incident response tool providing extract HTTP requests URLs User-Agents from PCAP for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

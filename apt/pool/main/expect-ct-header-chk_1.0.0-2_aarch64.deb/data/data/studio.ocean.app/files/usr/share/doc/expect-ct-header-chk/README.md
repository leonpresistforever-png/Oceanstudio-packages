# expect-ct-header-chk

Expect-CT Certificate Transparency enforcement checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

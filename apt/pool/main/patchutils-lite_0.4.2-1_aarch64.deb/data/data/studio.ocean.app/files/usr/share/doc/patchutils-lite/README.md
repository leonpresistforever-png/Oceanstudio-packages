# patchutils-lite

utilities to work with diff and patch files

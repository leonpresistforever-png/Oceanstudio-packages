# http-cache-validator

validate Cache-Control, ETag and 304 responses

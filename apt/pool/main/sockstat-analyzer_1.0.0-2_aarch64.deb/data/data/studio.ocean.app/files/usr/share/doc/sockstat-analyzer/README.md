# sockstat-analyzer

kernel socket allocation statistics summarizer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

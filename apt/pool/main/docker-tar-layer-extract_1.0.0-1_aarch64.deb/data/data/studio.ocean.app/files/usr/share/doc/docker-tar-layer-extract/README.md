# docker-tar-layer-extract

Docker image save tarball manifest and layer reader

## Description
Container runtime and Linux namespace management utility providing Docker image save tarball manifest and layer reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

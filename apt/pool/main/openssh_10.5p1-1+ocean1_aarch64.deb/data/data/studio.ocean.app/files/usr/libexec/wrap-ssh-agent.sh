#!/data/data/studio.ocean.app/files/usr/bin/sh

. "${OCEAN__PREFIX:-"${PREFIX}"}"/libexec/source-ssh-agent.sh
"${wrapped_cmd}" "$@"

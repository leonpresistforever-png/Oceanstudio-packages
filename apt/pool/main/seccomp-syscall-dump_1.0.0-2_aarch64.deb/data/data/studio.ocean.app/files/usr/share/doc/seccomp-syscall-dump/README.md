# seccomp-syscall-dump

Linux system call number table for AArch64 seccomp

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

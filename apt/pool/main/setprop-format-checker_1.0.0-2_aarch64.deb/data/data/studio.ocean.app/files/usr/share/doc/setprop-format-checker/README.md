# setprop-format-checker

Android system property key name and value syntax linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

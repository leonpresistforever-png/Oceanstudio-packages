# android-property-parser

Android __system_property_get memory structure parser

## Description
Android Bionic and runtime platform utility providing Android __system_property_get memory structure parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

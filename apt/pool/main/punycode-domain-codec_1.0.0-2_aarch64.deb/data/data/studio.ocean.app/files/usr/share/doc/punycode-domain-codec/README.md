# punycode-domain-codec

internationalized domain name IDNA Punycode encoder and decoder

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

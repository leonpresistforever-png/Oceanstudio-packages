# smbios-dmi-table-view

SMBIOS/DMI system bios baseboard chassis parser

## Description
Embedded firmware and hardware diagnostics tool providing SMBIOS/DMI system bios baseboard chassis parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# cmatrix-rain

matrix digital rain screen simulation in terminal

# ripemd320-hasher

RACE Integrity Primitives Evaluation 320-bit double-width hasher

## Description
Cryptographic engine and secret management utility providing RACE Integrity Primitives Evaluation 320-bit double-width hasher for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

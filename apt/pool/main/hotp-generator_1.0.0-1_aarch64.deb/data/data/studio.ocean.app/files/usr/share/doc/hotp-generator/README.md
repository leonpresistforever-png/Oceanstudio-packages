# hotp-generator

RFC 4226 HMAC-Based One-Time Password generator

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

# oidc-discovery-parser

OpenID Connect .well-known/openid-configuration tool

## Description
API schema validation and protocol contract engine providing OpenID Connect .well-known/openid-configuration tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# etag-if-none-match-chk

HTTP conditional requests ETag and 304 response logic

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# sql-injection-tester

SQL query literal parameterization security checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

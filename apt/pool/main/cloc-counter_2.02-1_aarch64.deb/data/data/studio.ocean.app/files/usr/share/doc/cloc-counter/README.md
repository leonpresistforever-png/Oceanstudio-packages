# cloc-counter

count lines of code in hundreds of languages

# re2c-lexer

fast lexical analyzer generator for C/C++

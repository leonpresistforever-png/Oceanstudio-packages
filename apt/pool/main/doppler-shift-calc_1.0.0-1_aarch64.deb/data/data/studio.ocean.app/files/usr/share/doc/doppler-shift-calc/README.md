# doppler-shift-calc

Doppler frequency shift acoustic and RF calculator

## Description
Scientific calculation and numerical algorithm engine providing Doppler frequency shift acoustic and RF calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

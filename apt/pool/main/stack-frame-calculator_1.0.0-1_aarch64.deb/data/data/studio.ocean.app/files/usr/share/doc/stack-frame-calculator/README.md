# stack-frame-calculator

ARM64 stack frame layout and alignment calculator

## Description
Binary analysis and compilation toolchain helper providing ARM64 stack frame layout and alignment calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

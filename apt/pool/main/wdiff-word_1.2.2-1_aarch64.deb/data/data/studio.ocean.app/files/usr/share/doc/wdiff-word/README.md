# wdiff-word

word-by-word difference comparison tool

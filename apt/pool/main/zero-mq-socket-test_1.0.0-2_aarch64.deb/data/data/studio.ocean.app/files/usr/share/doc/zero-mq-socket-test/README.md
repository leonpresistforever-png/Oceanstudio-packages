# zero-mq-socket-test

ZeroMQ framing and multipart message delimiter check

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

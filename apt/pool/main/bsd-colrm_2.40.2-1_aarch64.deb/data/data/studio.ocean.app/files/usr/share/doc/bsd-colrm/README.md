# bsd-colrm

remove selected columns from input stream

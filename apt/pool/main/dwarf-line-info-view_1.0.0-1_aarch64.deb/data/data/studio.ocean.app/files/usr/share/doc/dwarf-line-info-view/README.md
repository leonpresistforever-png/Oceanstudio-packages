# dwarf-line-info-view

DWARF .debug_line source code file and line viewer

## Description
Binary analysis and compilation toolchain helper providing DWARF .debug_line source code file and line viewer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

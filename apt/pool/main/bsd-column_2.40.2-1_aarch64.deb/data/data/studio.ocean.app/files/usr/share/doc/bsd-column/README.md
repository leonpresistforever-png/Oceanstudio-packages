# bsd-column

columnate lists into formatted terminal tables

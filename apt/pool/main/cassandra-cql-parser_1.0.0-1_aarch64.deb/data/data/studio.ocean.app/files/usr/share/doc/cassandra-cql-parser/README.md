# cassandra-cql-parser

Cassandra CQL schema and keyspace syntax validator

## Description
Embedded database and SQL processing engine providing Cassandra CQL schema and keyspace syntax validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

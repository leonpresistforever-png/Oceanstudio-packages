# flex-fast-lexer

fast lexical analyzer generator

# can-j1939-pgn-parser

SAE J1939 Parameter Group Number PGN ID decoder

## Description
Embedded firmware and hardware diagnostics tool providing SAE J1939 Parameter Group Number PGN ID decoder for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

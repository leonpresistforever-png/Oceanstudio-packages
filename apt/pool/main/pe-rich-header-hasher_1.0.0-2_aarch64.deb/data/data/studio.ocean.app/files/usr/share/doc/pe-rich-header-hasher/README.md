# pe-rich-header-hasher

PE executable Rich header compiler checksum hasher

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

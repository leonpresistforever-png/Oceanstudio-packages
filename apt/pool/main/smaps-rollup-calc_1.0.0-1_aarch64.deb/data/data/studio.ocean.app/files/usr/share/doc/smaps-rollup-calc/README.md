# smaps-rollup-calc

process PSS USS and dirty page memory rollup calculator

## Description
Linux procfs and system diagnostic utility providing process PSS USS and dirty page memory rollup calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# b2sum-lite

calculate and check BLAKE2b/BLAKE2s hashes

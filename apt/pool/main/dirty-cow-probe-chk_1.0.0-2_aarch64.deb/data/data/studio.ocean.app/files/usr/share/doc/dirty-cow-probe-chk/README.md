# dirty-cow-probe-chk

Linux kernel copy-on-write race condition probe

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

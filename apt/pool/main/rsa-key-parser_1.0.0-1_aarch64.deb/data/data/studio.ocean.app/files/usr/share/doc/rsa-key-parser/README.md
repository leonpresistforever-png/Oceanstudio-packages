# rsa-key-parser

RSA public and private key PEM structure inspector

Part of OceanStudio official package ecosystem on Android AArch64.
Prefix: `/data/data/studio.ocean.app/files/usr`

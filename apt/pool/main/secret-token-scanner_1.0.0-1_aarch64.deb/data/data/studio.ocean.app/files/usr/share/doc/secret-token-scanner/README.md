# secret-token-scanner

detect exposed API keys and OAuth tokens with regex heuristics

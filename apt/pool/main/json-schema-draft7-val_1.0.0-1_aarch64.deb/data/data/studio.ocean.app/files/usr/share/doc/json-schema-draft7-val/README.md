# json-schema-draft7-val

JSON Schema draft-07 specification compatibility check

## Description
API schema validation and protocol contract engine providing JSON Schema draft-07 specification compatibility check for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

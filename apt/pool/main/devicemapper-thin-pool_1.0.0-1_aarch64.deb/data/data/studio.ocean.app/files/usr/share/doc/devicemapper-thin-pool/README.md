# devicemapper-thin-pool

Device Mapper thin provisioning pool metadata checker

## Description
Container runtime and Linux namespace management utility providing Device Mapper thin provisioning pool metadata checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

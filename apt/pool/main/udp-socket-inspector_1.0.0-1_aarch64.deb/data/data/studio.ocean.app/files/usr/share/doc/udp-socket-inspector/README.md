# udp-socket-inspector

UDP socket receive buffer and packet drop auditor

## Description
Linux procfs and system diagnostic utility providing UDP socket receive buffer and packet drop auditor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

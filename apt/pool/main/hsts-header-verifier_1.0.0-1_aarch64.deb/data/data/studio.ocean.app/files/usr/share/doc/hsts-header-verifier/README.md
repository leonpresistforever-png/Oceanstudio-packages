# hsts-header-verifier

verify Strict-Transport-Security preload and max-age settings

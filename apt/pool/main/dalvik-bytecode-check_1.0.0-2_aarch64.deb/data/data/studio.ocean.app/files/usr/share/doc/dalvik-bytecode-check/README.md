# dalvik-bytecode-check

Dalvik bytecode opcode table and register count linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

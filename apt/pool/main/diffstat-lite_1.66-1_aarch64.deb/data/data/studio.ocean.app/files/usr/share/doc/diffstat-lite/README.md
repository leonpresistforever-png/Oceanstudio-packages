# diffstat-lite

generate histogram statistics from diff output

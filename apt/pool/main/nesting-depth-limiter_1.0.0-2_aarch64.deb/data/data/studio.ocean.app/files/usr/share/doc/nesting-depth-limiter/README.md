# nesting-depth-limiter

excessive block nesting level threshold analyzer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# sparkline-generator

generate unicode sparkline graphs for terminal logs

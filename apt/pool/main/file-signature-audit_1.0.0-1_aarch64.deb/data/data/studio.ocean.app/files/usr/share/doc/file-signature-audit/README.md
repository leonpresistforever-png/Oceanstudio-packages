# file-signature-audit

detect file type by magic byte signatures without extension

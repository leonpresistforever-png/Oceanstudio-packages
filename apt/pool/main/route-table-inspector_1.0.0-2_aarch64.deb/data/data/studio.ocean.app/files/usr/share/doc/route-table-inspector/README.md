# route-table-inspector

Linux kernel IP routing table metric and gateway viewer

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

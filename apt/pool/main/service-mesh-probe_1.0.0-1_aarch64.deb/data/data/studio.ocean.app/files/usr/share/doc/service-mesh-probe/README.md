# service-mesh-probe

sidecar proxy traffic interception status probe

## Description
DevOps workflow and microservice coordination utility providing sidecar proxy traffic interception status probe for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

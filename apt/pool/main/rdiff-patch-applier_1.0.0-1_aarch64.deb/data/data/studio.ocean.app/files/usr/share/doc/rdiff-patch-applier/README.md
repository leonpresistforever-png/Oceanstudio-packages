# rdiff-patch-applier

binary differential delta patch application tool

## Description
Archive file format and differential backup utility providing binary differential delta patch application tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

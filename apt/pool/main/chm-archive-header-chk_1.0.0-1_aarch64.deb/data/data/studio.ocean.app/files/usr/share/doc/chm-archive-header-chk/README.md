# chm-archive-header-chk

Compiled HTML Help ITSF file header and directory tool

## Description
Archive file format and differential backup utility providing Compiled HTML Help ITSF file header and directory tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

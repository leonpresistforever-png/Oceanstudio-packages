# heif-item-parser

High Efficiency Image File meta iref iprp box reader

## Description
Media header parser and audiovisual engineering utility providing High Efficiency Image File meta iref iprp box reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# thrift-idl-linter

Apache Thrift IDL service and struct definition linter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

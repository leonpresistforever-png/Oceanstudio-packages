# sysctl-rule-validator

Linux kernel sysctl parameters syntax and range checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

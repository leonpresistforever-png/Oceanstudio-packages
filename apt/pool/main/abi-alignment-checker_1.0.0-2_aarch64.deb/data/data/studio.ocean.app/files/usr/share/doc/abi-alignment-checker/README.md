# abi-alignment-checker

C struct field natural alignment and padding tool

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# allocator-fragmentation

memory allocator internal and external fragmentation

## Description
Performance profiling and microbenchmark utility providing memory allocator internal and external fragmentation for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

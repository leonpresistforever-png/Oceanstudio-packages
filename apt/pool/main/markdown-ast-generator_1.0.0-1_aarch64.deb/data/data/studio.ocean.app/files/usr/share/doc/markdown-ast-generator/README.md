# markdown-ast-generator

CommonMark markdown abstract syntax tree generator

## Description
Text tokenization and natural language processing tool providing CommonMark markdown abstract syntax tree generator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

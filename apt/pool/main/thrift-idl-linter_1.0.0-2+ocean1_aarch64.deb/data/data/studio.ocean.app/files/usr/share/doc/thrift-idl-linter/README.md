# thrift-idl-linter

Apache Thrift IDL service and struct definition linter
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard10_devops.py
Source SHA256: a8b26a1d458fd51c5449d080608226a5777c136f7b047537bba53ab1bb2d388d
Shared runtime package: ocean-runtime-shard10-devops

# can-bus-frame-dumper

Controller Area Network CAN 2.0A/B standard frame dump

## Description
Embedded firmware and hardware diagnostics tool providing Controller Area Network CAN 2.0A/B standard frame dump for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

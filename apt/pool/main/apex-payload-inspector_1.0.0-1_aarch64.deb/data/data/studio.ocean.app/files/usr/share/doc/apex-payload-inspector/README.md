# apex-payload-inspector

Android APEX ext4/erofs loopback payload inspector

## Description
Android Bionic and runtime platform utility providing Android APEX ext4/erofs loopback payload inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

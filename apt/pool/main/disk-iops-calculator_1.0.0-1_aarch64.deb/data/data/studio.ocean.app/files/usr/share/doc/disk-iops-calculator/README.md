# disk-iops-calculator

storage Input/Output Operations Per Second calculator

## Description
Performance profiling and microbenchmark utility providing storage Input/Output Operations Per Second calculator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

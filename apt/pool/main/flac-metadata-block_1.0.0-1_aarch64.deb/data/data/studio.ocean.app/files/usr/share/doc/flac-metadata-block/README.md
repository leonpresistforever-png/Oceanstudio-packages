# flac-metadata-block

Free Lossless Audio Codec METADATA_BLOCK_STREAMINFO view

## Description
Media header parser and audiovisual engineering utility providing Free Lossless Audio Codec METADATA_BLOCK_STREAMINFO view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# oci-hooks-config-tool

OCI runtime lifecycle hooks prestart poststop linter

## Description
Container runtime and Linux namespace management utility providing OCI runtime lifecycle hooks prestart poststop linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# kernel-kptr-restrict-chk

kernel kptr_restrict and dmesg_restrict setting audit

## Description
Security forensic analysis and incident response tool providing kernel kptr_restrict and dmesg_restrict setting audit for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

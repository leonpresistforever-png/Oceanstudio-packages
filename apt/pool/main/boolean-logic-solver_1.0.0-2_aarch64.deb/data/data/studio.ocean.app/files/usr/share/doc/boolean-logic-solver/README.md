# boolean-logic-solver

boolean logic expression truth table and SAT solver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# automake-helpers

helper scripts and macros for Automake

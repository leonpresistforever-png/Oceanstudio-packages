# ext4-dump-restore-chk

ext4 dump/restore tape archive format inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

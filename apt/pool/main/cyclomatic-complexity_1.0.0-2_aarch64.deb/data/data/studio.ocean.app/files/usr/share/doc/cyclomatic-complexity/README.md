# cyclomatic-complexity

McCabe cyclomatic complexity metric calculator for code

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

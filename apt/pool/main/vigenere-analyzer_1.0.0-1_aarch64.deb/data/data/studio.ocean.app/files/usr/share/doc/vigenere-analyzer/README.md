# vigenere-analyzer

Vigenere cipher index of coincidence analyzer

## Description
Cryptographic engine and secret management utility providing Vigenere cipher index of coincidence analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

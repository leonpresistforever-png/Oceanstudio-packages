# macho-header-checker

parse and inspect Mach-O macOS/iOS binaries safely

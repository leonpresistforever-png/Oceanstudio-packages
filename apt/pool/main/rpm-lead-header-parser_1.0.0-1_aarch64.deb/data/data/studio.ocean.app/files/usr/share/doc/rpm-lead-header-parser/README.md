# rpm-lead-header-parser

RPM package lead and header structure inspector

## Description
Archive file format and differential backup utility providing RPM package lead and header structure inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

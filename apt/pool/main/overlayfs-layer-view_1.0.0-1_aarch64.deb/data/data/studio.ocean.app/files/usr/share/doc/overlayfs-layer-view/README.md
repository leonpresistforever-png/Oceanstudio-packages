# overlayfs-layer-view

container image layer diff and whiteout file analyzer

## Description
DevOps workflow and microservice coordination utility providing container image layer diff and whiteout file analyzer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

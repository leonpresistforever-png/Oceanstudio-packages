# io-uring-probe-support

Linux io_uring opcode support and ring buffer probe

## Description
Performance profiling and microbenchmark utility providing Linux io_uring opcode support and ring buffer probe for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

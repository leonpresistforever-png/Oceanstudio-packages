# svg-xml-sanitizer

SVG XML malicious script and entity reference cleaner

## Description
Media header parser and audiovisual engineering utility providing SVG XML malicious script and entity reference cleaner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

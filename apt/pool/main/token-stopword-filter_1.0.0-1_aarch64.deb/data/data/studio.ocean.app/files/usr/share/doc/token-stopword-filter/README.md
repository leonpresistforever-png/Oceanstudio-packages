# token-stopword-filter

multilingual natural language stopword removal tool

## Description
Text tokenization and natural language processing tool providing multilingual natural language stopword removal tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

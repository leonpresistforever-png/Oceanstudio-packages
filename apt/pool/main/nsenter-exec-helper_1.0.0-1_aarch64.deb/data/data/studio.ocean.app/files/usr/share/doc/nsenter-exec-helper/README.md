# nsenter-exec-helper

join and execute in existing Linux namespace helper

## Description
Container runtime and Linux namespace management utility providing join and execute in existing Linux namespace helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# usb-string-descriptor

USB string descriptor UNICODE UTF-16LE extractor

## Description
Embedded firmware and hardware diagnostics tool providing USB string descriptor UNICODE UTF-16LE extractor for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

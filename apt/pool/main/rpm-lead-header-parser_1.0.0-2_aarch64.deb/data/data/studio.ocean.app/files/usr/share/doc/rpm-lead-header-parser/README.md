# rpm-lead-header-parser

RPM package lead and header structure inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

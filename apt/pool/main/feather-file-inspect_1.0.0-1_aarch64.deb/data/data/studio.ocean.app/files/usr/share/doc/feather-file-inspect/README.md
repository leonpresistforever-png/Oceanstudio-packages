# feather-file-inspect

Feather V1/V2 binary dataframe format inspector

## Description
Embedded database and SQL processing engine providing Feather V1/V2 binary dataframe format inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# intel-hex-ihex-converter

Intel HEX format record parser and binary converter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# student-t-distribution

Student t-distribution two-tailed p-value evaluator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

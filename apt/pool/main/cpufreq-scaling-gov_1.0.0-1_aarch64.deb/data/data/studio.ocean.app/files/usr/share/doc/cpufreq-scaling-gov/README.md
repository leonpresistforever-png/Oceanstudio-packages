# cpufreq-scaling-gov

CPU frequency scaling governors and transition table

## Description
Embedded firmware and hardware diagnostics tool providing CPU frequency scaling governors and transition table for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

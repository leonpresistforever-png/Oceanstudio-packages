# matrix-determinant-2d

2x2 and NxN matrix determinant algebraic solver

## Description
Scientific calculation and numerical algorithm engine providing 2x2 and NxN matrix determinant algebraic solver for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

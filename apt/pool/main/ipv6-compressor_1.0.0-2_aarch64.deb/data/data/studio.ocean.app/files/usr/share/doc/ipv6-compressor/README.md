# ipv6-compressor

IPv6 zero-compression and canonical RFC 5952 formatter

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# selinux-context-check

SELinux file security context u:r:s0 syntax checker

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

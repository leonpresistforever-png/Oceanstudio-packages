# lut-color-cube-parser

3D Look-Up Table .cube file format validator

## Description
Media header parser and audiovisual engineering utility providing 3D Look-Up Table .cube file format validator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

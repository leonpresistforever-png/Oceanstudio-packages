# c-symbol-coverage

C header function declaration vs implementation diff

## Description
Static analysis and source code auditing utility providing C header function declaration vs implementation diff for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

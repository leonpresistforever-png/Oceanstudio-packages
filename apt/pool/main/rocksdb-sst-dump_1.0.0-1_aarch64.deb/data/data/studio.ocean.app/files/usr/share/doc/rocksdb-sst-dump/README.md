# rocksdb-sst-dump

RocksDB SSTable block format and index reader

## Description
Embedded database and SQL processing engine providing RocksDB SSTable block format and index reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

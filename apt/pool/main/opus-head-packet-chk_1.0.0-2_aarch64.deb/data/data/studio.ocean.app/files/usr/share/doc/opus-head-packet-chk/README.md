# opus-head-packet-chk

OpusHead identification header and preskip calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

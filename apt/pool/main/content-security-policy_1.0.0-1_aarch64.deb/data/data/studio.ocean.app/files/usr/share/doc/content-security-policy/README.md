# content-security-policy

W3C Content Security Policy CSP directive linter

## Description
API schema validation and protocol contract engine providing W3C Content Security Policy CSP directive linter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

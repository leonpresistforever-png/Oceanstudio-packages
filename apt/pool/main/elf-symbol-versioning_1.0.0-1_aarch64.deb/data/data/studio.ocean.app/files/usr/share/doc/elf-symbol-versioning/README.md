# elf-symbol-versioning

GNU ELF symbol version definitions and requirements view

## Description
Binary analysis and compilation toolchain helper providing GNU ELF symbol version definitions and requirements view for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

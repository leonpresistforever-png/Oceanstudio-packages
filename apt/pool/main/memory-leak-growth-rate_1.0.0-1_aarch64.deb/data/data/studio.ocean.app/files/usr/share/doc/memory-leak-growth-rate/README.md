# memory-leak-growth-rate

linear regression heap memory slope leak estimator

## Description
Performance profiling and microbenchmark utility providing linear regression heap memory slope leak estimator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# usb-descriptor-parser

USB 2.0/3.0 device configuration interface descriptor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

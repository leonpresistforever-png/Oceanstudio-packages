# coordinate-proj-proj4

cartographic coordinate transformation helper

## Description
Scientific calculation and numerical algorithm engine providing cartographic coordinate transformation helper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# dmesg-boot-filter

kernel ring buffer initialization and boot log filter

## Description
Linux procfs and system diagnostic utility providing kernel ring buffer initialization and boot log filter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# jpeg-exif-stripper

JPEG Exchangeable Image File metadata remover

## Description
Media header parser and audiovisual engineering utility providing JPEG Exchangeable Image File metadata remover for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

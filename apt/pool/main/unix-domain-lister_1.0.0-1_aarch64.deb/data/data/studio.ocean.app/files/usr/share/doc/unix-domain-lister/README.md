# unix-domain-lister

UNIX domain socket endpoint and inode mapper

## Description
Linux procfs and system diagnostic utility providing UNIX domain socket endpoint and inode mapper for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

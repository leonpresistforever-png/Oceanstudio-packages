# c-amalgamation-tool

bundle multi-file C library into single amalgamated C file

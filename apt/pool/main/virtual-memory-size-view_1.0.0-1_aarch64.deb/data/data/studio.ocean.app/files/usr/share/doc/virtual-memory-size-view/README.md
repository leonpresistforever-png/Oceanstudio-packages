# virtual-memory-size-view

virtual memory size VmSize vs resident ratio checker

## Description
Performance profiling and microbenchmark utility providing virtual memory size VmSize vs resident ratio checker for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

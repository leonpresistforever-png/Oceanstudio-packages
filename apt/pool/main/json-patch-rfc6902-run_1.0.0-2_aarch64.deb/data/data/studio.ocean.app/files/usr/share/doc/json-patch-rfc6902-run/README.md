# json-patch-rfc6902-run

RFC 6902 JavaScript Object Notation Patch evaluator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

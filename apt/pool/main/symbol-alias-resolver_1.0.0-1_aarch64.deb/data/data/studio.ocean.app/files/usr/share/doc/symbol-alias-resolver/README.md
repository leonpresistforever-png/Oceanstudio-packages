# symbol-alias-resolver

compiler symbol alias and strong/weak pairing tool

## Description
Binary analysis and compilation toolchain helper providing compiler symbol alias and strong/weak pairing tool for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

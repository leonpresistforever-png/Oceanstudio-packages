# suid-binary-matrix

setuid and setgid binary GTFOBins capability matrix

## Description
Security forensic analysis and incident response tool providing setuid and setgid binary GTFOBins capability matrix for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

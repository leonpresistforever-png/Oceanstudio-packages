# quic-congestion-cubic

TCP/QUIC CUBIC congestion window growth simulator

## Description
Distributed systems consensus and P2P protocol utility providing TCP/QUIC CUBIC congestion window growth simulator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

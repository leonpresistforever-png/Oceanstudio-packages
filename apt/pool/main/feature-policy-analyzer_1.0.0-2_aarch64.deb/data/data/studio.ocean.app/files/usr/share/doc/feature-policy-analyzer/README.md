# feature-policy-analyzer

W3C Feature Policy and Permissions Policy validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# ascii-box-drawing

Unicode box drawing border and panel generator
 Functional OceanStudio implementation replacing the earlier generic passthrough placeholder.

Version: 1.0.0-2+ocean1
Source: sources/functional-shards/shard13_text.py
Source SHA256: 2bd0ab93bcb787675068bb64980f78f0f8fc01aa479f77f8d9edc9874076ce70
Shared runtime package: ocean-runtime-shard13-text

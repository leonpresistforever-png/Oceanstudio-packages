# calc-precision-cli

arbitrary precision C-like calculator utility

# sparse-file-creator

POSIX sparse file generator with arbitrary hole sizes

## Description
Filesystem analysis and storage engineering utility providing POSIX sparse file generator with arbitrary hole sizes for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

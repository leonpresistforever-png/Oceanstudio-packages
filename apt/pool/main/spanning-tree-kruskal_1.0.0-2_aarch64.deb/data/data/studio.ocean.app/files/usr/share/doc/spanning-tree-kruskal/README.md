# spanning-tree-kruskal

Kruskal Minimum Spanning Tree disjoint-set solver

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

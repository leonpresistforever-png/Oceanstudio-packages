# wasm-header-parser

WebAssembly binary magic number and version parser

## Description
Binary analysis and compilation toolchain helper providing WebAssembly binary magic number and version parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

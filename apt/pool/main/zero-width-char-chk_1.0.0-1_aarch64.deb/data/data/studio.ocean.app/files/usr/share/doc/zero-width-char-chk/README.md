# zero-width-char-chk

invisible zero-width space and homoglyph scanner

## Description
Text tokenization and natural language processing tool providing invisible zero-width space and homoglyph scanner for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

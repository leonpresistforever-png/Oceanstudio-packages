# elf-string-table-cat

ELF .strtab and .dynstr string table extractor

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

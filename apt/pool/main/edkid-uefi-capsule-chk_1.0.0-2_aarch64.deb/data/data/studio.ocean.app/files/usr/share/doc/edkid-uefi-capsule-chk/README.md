# edkid-uefi-capsule-chk

UEFI capsule update header and GUID authenticator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# apex-payload-inspector

Android APEX ext4/erofs loopback payload inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# dex-method-id-dump

DEX method_ids method table and signature inspector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

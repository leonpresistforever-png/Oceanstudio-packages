# vdex-verifier-header

Android VDEX verified DEX container header inspector

## Description
Android Bionic and runtime platform utility providing Android VDEX verified DEX container header inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

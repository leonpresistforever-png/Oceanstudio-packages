# csv-stat-analyzer

compute min, max, mean and quantiles for CSV columns

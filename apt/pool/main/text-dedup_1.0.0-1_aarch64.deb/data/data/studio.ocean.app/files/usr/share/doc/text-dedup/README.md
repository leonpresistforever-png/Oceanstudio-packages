# text-dedup

fast stream deduplicator preserving first occurrence

# network-listening-ports

audit active TCP and UDP listening sockets in Android sandbox

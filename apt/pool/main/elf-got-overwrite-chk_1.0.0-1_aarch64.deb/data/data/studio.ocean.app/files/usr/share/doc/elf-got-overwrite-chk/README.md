# elf-got-overwrite-chk

Global Offset Table integrity and overwrite detector

## Description
Security forensic analysis and incident response tool providing Global Offset Table integrity and overwrite detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

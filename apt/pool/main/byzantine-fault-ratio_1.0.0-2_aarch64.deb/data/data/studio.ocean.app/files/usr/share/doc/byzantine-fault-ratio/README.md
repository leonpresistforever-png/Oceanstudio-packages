# byzantine-fault-ratio

3f+1 Byzantine fault tolerance threshold calculator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

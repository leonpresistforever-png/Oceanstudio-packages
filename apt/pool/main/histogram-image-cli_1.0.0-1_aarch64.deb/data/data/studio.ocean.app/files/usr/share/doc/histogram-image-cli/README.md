# histogram-image-cli

image red green blue channel luminance histogram

## Description
Media header parser and audiovisual engineering utility providing image red green blue channel luminance histogram for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

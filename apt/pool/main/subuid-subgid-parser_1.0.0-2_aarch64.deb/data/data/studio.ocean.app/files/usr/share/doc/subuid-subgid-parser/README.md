# subuid-subgid-parser

/etc/subuid and /etc/subgid range collision detector

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

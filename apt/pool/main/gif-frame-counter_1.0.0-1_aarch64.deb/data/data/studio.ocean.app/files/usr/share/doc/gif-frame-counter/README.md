# gif-frame-counter

GIF89a graphics control extension animated frame counter

## Description
Media header parser and audiovisual engineering utility providing GIF89a graphics control extension animated frame counter for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

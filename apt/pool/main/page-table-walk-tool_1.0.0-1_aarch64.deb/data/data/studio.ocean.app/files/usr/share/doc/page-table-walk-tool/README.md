# page-table-walk-tool

virtual memory page table descriptor walk simulator

## Description
Security forensic analysis and incident response tool providing virtual memory page table descriptor walk simulator for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

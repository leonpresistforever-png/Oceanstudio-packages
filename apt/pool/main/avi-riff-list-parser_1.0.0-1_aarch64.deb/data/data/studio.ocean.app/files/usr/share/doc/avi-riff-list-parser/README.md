# avi-riff-list-parser

Audio Video Interleave RIFF LIST hdrl movi parser

## Description
Media header parser and audiovisual engineering utility providing Audio Video Interleave RIFF LIST hdrl movi parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

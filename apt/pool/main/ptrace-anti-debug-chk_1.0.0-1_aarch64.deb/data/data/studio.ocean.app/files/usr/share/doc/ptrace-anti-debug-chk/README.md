# ptrace-anti-debug-chk

ptrace PTRACE_TRACEME anti-debugging pattern detector

## Description
Security forensic analysis and incident response tool providing ptrace PTRACE_TRACEME anti-debugging pattern detector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

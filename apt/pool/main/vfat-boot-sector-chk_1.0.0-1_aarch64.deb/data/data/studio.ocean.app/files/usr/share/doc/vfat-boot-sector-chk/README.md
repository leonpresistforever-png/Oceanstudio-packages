# vfat-boot-sector-chk

FAT32/VFAT BPB BIOS parameter block inspector

## Description
Filesystem analysis and storage engineering utility providing FAT32/VFAT BPB BIOS parameter block inspector for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

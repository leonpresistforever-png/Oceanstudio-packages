# uchardet-cli

universal charset detection utility

# mem-injection-scanner

process memory injection and shellcode pattern scanner

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

# fakechroot-config-chk

fakechroot library interception path translator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

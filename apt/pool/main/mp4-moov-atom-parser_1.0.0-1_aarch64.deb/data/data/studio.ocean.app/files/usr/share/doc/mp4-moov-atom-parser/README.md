# mp4-moov-atom-parser

MPEG-4 Part 14 ftyp moov mvhd trak atom parser

## Description
Media header parser and audiovisual engineering utility providing MPEG-4 Part 14 ftyp moov mvhd trak atom parser for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

# helm-values-differ

Helm chart values.yaml override inheritance differ

## Description
DevOps workflow and microservice coordination utility providing Helm chart values.yaml override inheritance differ for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

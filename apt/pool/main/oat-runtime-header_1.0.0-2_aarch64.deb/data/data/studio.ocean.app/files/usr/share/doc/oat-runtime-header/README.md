# oat-runtime-header

Android OAT ahead-of-time compiled ELF header parser

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

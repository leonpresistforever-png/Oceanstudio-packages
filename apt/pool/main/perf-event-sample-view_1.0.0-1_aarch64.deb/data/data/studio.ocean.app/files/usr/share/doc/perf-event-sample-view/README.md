# perf-event-sample-view

Linux perf_event_open sample packet header reader

## Description
Performance profiling and microbenchmark utility providing Linux perf_event_open sample packet header reader for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

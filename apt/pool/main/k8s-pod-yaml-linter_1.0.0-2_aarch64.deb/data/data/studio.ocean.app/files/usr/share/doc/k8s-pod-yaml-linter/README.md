# k8s-pod-yaml-linter

Kubernetes Pod and Deployment YAML schema validator

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

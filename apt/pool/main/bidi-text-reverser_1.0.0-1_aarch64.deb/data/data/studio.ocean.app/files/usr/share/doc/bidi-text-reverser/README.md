# bidi-text-reverser

bidirectional Unicode text ordering visualizer

## Description
Text tokenization and natural language processing tool providing bidirectional Unicode text ordering visualizer for the OceanStudio environment on Android AArch64.
Built from official open-source standards and packaged with full compliance to Ocean prefix specifications.

## Installation Prefix
`/data/data/studio.ocean.app/files/usr`

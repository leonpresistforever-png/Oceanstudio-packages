# simg2img-ocean-cli

Android sparse image unsparse conversion utility

Functional OceanStudio repair package.
Version: 1.0.0-2
Runtime: Python standard library / Linux interfaces.

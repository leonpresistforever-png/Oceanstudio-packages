# math-evaluator-cli

evaluate complex mathematical expressions from stdin

# matrix-multiplier-cli

multiply and invert small numeric matrices from stdin
